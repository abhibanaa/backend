# Login API - User ID & API Key Generation

## API Endpoint
```
POST /api/auth/login
```

## Request
```json
{
  "phone": "+918107804990",
  "otp": "333661"
}
```

## Response
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "needsRegistration": false,
  "user": {
    "id": "68788a737a98679b78228d93",
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "+918107804990",
    "isProfileComplete": true,
    "role": "user",
    "dateOfBirth": "1990-01-01T00:00:00.000Z",
    "timeOfBirth": "12:00 PM",
    "placeOfBirth": "Mumbai",
    "profileImage": "/uploads/profile.jpg"
  },
  "apiCredentials": {
    "userId": "U1234567",
    "apiKey": "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6"
  }
}
```

## How it Works

1. **User sends login request** with phone and OTP
2. **System validates OTP**
3. **If OTP is valid:**
   - Check if user has User ID and API Key
   - If missing, generate them automatically
   - Save to database
   - Return in response
4. **User gets credentials immediately**

## Console Logs
```
Login attempt: { phone: '+918107804990', otp: '333661' }
Found user: Yes
Generating User ID during login
Generating API Key during login
Login: Generated User ID: U1234567
Login: Generated API Key: a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6
OTP validation result: true
POST /api/auth/login 200 82.310 ms - 497
```

## Usage Examples

### 1. Get User by User ID
```bash
curl -X GET "http://localhost:5000/api/auth/user/U1234567"
```

### 2. Get User by API Key
```bash
curl -X GET "http://localhost:5000/api/auth/api-key/a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6"
```

### 3. API Authentication with API Key
```bash
curl -X GET "http://localhost:5000/api/auth/me" \
  -H "X-API-Key: a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6"
```

### 4. JWT Authentication
```bash
curl -X GET "http://localhost:5000/api/auth/me" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

## Test the API

1. **Open browser:** `http://localhost:5000/login-demo.html`
2. **Enter phone:** `+918107804990`
3. **Enter OTP:** `333661`
4. **Click Login**
5. **See generated User ID and API Key**

## Flutter Integration

```dart
// Login request
final response = await http.post(
  Uri.parse('http://localhost:5000/api/auth/login'),
  headers: {'Content-Type': 'application/json'},
  body: jsonEncode({
    'phone': '+918107804990',
    'otp': '333661'
  }),
);

final data = jsonDecode(response.body);

// Get credentials
final userId = data['apiCredentials']['userId'];
final apiKey = data['apiCredentials']['apiKey'];
final token = data['token'];

// Use for API calls
final apiResponse = await http.get(
  Uri.parse('http://localhost:5000/api/horoscope/daily'),
  headers: {
    'X-API-Key': apiKey,
    // or
    'Authorization': 'Bearer $token'
  },
);
```

## Key Features

✅ **Automatic Generation:** User ID and API Key generated during login
✅ **Immediate Response:** Credentials returned in login response
✅ **Multiple Auth Methods:** JWT Token and API Key support
✅ **Unique Identifiers:** Each user gets unique User ID and API Key
✅ **Secure:** API Key is 32-character hexadecimal string
✅ **User-Friendly:** No separate step needed to get credentials 