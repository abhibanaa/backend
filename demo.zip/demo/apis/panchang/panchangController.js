const Panchang = require('../../models/Panchang');
const ErrorResponse = require('../../utils/errorResponse');

// @desc    Create new panchang
// @route   POST /api/panchang
// @access  Private (Admin only)
exports.createPanchang = async (req, res, next) => {
  try {
    const panchang = await Panchang.create(req.body);

    res.status(201).json({
      success: true,
      data: panchang
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all panchangs
// @route   GET /api/panchang
// @access  Public
exports.getPanchangs = async (req, res, next) => {
  try {
    let query;

    // Copy req.query
    const reqQuery = { ...req.query };

    // Fields to exclude
    const removeFields = ['select', 'sort', 'page', 'limit'];

    // Loop over removeFields and delete them from reqQuery
    removeFields.forEach(param => delete reqQuery[param]);

    // Create query string
    let queryStr = JSON.stringify(reqQuery);

    // Create operators ($gt, $gte, etc)
    queryStr = queryStr.replace(/\b(gt|gte|lt|lte|in)\b/g, match => `$${match}`);

    // Finding resource
    query = Panchang.find(JSON.parse(queryStr));

    // Select Fields
    if (req.query.select) {
      const fields = req.query.select.split(',').join(' ');
      query = query.select(fields);
    }

    // Sort
    if (req.query.sort) {
      const sortBy = req.query.sort.split(',').join(' ');
      query = query.sort(sortBy);
    } else {
      query = query.sort('date');
    }

    // Pagination
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 25;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const total = await Panchang.countDocuments();

    query = query.skip(startIndex).limit(limit);

    // Executing query
    const panchangs = await query;

    // Pagination result
    const pagination = {};

    if (endIndex < total) {
      pagination.next = {
        page: page + 1,
        limit
      };
    }

    if (startIndex > 0) {
      pagination.prev = {
        page: page - 1,
        limit
      };
    }

    res.status(200).json({
      success: true,
      count: panchangs.length,
      pagination,
      data: panchangs
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single panchang
// @route   GET /api/panchang/:id
// @access  Public
exports.getPanchang = async (req, res, next) => {
  try {
    const panchang = await Panchang.findById(req.params.id);

    if (!panchang) {
      return next(new ErrorResponse(`Panchang not found with id of ${req.params.id}`, 404));
    }

    res.status(200).json({
      success: true,
      data: panchang
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update panchang
// @route   PUT /api/panchang/:id
// @access  Private (Admin only)
exports.updatePanchang = async (req, res, next) => {
  try {
    let panchang = await Panchang.findById(req.params.id);

    if (!panchang) {
      return next(new ErrorResponse(`Panchang not found with id of ${req.params.id}`, 404));
    }

    panchang = await Panchang.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    res.status(200).json({
      success: true,
      data: panchang
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete panchang
// @route   DELETE /api/panchang/:id
// @access  Private (Admin only)
exports.deletePanchang = async (req, res, next) => {
  try {
    const panchang = await Panchang.findById(req.params.id);

    if (!panchang) {
      return next(new ErrorResponse(`Panchang not found with id of ${req.params.id}`, 404));
    }

    await panchang.remove();

    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get panchang by date
// @route   GET /api/panchang/date/:date
// @access  Public
exports.getPanchangByDate = async (req, res, next) => {
  try {
    const { date } = req.params;
    const { location } = req.query;

    let query = {
      date: new Date(date)
    };

    if (location) {
      query['location.name'] = location;
    }

    const panchang = await Panchang.findOne(query);

    if (!panchang) {
      return res.status(404).json({
        success: false,
        message: `No panchang found for date ${date}`
      });
    }

    res.status(200).json({
      success: true,
      data: panchang
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get panchang by location
// @route   GET /api/panchang/location/:location
// @access  Public
exports.getPanchangByLocation = async (req, res, next) => {
  try {
    const { location } = req.params;
    const { date, limit = 10 } = req.query;

    let query = {
      'location.name': location
    };

    if (date) {
      query.date = new Date(date);
    }

    const panchangs = await Panchang.find(query)
      .limit(parseInt(limit))
      .sort('date');

    res.status(200).json({
      success: true,
      count: panchangs.length,
      data: panchangs
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get auspicious timings (Muhurat)
// @route   GET /api/panchang/muhurat/:date
// @access  Public
exports.getMuhurat = async (req, res, next) => {
  try {
    const { date } = req.params;
    const { location } = req.query;

    let query = {
      date: new Date(date)
    };

    if (location) {
      query['location.name'] = location;
    }

    const panchang = await Panchang.findOne(query).select('muhurat location date');

    if (!panchang) {
      return res.status(404).json({
        success: false,
        message: `No muhurat found for date ${date}`
      });
    }

    res.status(200).json({
      success: true,
      data: panchang
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get festivals for a date range
// @route   GET /api/panchang/festivals
// @access  Public
exports.getFestivals = async (req, res, next) => {
  try {
    const { startDate, endDate, location } = req.query;

    let query = {};

    if (startDate && endDate) {
      query.date = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    }

    if (location) {
      query['location.name'] = location;
    }

    const panchangs = await Panchang.find(query)
      .select('date festivals location')
      .sort('date');

    // Extract festivals
    const festivals = [];
    panchangs.forEach(panchang => {
      if (panchang.festivals && panchang.festivals.length > 0) {
        panchang.festivals.forEach(festival => {
          festivals.push({
            name: festival.name,
            description: festival.description,
            isAuspicious: festival.isAuspicious,
            date: panchang.date,
            location: panchang.location.name
          });
        });
      }
    });

    res.status(200).json({
      success: true,
      count: festivals.length,
      data: festivals
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get panchang summary for today
// @route   GET /api/panchang/today
// @access  Public
exports.getTodayPanchang = async (req, res, next) => {
  try {
    const { location } = req.query;
    const today = new Date();

    let query = {
      date: {
        $gte: new Date(today.setHours(0, 0, 0, 0)),
        $lt: new Date(today.setHours(23, 59, 59, 999))
      }
    };

    if (location) {
      query['location.name'] = location;
    }

    const panchang = await Panchang.findOne(query);

    if (!panchang) {
      return res.status(404).json({
        success: false,
        message: 'No panchang found for today'
      });
    }

    // Create summary
    const summary = {
      date: panchang.date,
      location: panchang.location.name,
      tithi: panchang.tithi.name,
      vara: panchang.vara,
      nakshatra: panchang.nakshatra.name,
      yoga: panchang.yoga.name,
      karana: panchang.karana.name,
      sunrise: panchang.muhurat.sunrise,
      sunset: panchang.muhurat.sunset,
      festivals: panchang.festivals,
      recommendations: panchang.recommendations
    };

    res.status(200).json({
      success: true,
      data: summary
    });
  } catch (error) {
    next(error);
  }
}; 