const express = require('express');
const {
  createPanchang,
  getPanchangs,
  getPanchang,
  updatePanchang,
  deletePanchang,
  getTodayPanchang,
  getPanchangByDate
} = require('./panchangController');

const { protect, authorize } = require('../../middlewares/authMiddleware');

const router = express.Router();

// Public routes
router.route('/today')
  .get(getTodayPanchang);

router.route('/date/:date')
  .get(getPanchangByDate);

// Protected routes
router.use(protect);

router.route('/')
  .post(createPanchang)
  .get(getPanchangs);

router.route('/:id')
  .get(getPanchang)
  .put(updatePanchang)
  .delete(deletePanchang);

module.exports = router; 