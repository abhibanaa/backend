const express = require('express');
const {
  createCalculation,
  getUserCalculations,
  getOrderList,
  updateCalculation,
  deleteCalculation,
  updatePaymentStatus,
  getPricing,
  getAllPricing,
  getPdfPricing,
  updatePricing,
  getStats
} = require('./paidKundliController');
const { protect, authorize } = require('../../middlewares/authMiddleware');

const router = express.Router();

// Public routes
router.get('/pricing', getPricing);
router.get('/getAllPricing', getAllPricing);
router.get('/pdfPricing', getPdfPricing);

// Debug route to check if routes are working
router.get('/debug', (req, res) => {
  res.json({
    success: true,
    message: 'PaidKundli routes are working',
    path: req.path,
    method: req.method
  });
});

// Private routes (require user_uni_id and api_key)
router.post('/createCalculation', createCalculation);
router.get('/userCalculations', getUserCalculations);
router.get('/order-list', getOrderList);
router.put('/updateCalculation/:id', updateCalculation);
router.put('/updatePaymentStatus/:id', updatePaymentStatus);
router.delete('/deleteCalculation/:id', deleteCalculation);

// Admin routes (require admin privileges) - must come before parameterized routes
router.get('/stats', protect, authorize('admin'), getStats);
router.put('/updatePricing', protect, authorize('admin'), updatePricing);

// Handle invalid routes
router.use('*', (req, res) => {
  res.status(404).json({
    success: false,
    error: 'Route not found'
  });
});

module.exports = router; 