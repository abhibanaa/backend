const asyncHandler = require('../../middlewares/async');
const ErrorResponse = require('../../utils/errorResponse');
const PaidKundli = require('../../models/PaidKundli');
const PricingConfig = require('../../models/PricingConfig');
const User = require('../../models/User');

// Helper function to get current pricing configuration
const getCurrentPricing = async () => {
  let pricingConfig = await PricingConfig.findOne({ serviceName: 'Paid Kundli Calculation', isActive: true });
  
  if (!pricingConfig) {
    // Create default pricing if not exists
    pricingConfig = await PricingConfig.create({
      serviceName: 'Paid Kundli Calculation',
      basePrice: 299,
      gstPercentage: 18,
      description: 'Professional Kundli calculation with detailed analysis',
      pdfTypes: {
        small: { price: 199, description: 'Basic PDF Report' },
        medium: { price: 399, description: 'Standard PDF Report' },
        large: { price: 599, description: 'Premium PDF Report' }
      }
    });
  }
  
  return pricingConfig;
};

// Helper function to perform Kundli calculation (placeholder)
const performKundliCalculation = (data) => {
  const { order_for } = data;
  
  if (order_for === 'horoscope') {
    return {
      rashi: 'Aries',
      nakshatra: 'Ashwini',
      ascendant: 'Aries',
      moonSign: 'Aries',
      sunSign: 'Aries',
      detailedAnalysis: {
        personality: 'Dynamic and energetic personality',
        career: 'Suitable for leadership roles',
        health: 'Generally good health',
        relationships: 'Passionate and loyal',
        compatibility: 'Best with Leo and Sagittarius'
      },
      planetaryPositions: {
        sun: 'Aries',
        moon: 'Aries',
        mars: 'Aries',
        mercury: 'Pisces',
        jupiter: 'Taurus',
        venus: 'Pisces',
        saturn: 'Capricorn',
        rahu: 'Cancer',
        ketu: 'Capricorn'
      },
      dashaPeriods: {
        current: 'Mars Dasha',
        next: 'Rahu Dasha',
        startDate: new Date().toISOString(),
        endDate: new Date(Date.now() + 7 * 365 * 24 * 60 * 60 * 1000).toISOString()
      }
    };
  } else if (order_for === 'matching') {
    return {
      compatibility: {
        overall: 85,
        mental: 80,
        physical: 90,
        spiritual: 85
      },
      gunMilan: {
        total: 36,
        varna: 1,
        vashya: 1,
        tara: 3,
        yoni: 4,
        grahaMaitri: 5,
        gana: 3,
        bhakoot: 7,
        nadi: 8
      },
      analysis: {
        summary: 'Excellent compatibility between the couple',
        strengths: 'Strong mental and spiritual connection',
        challenges: 'Minor differences in communication style',
        recommendations: 'Focus on open communication and understanding'
      },
      planetaryPositions: {
        boy: {
          sun: 'Aries',
          moon: 'Taurus',
          mars: 'Leo'
        },
        girl: {
          sun: 'Libra',
          moon: 'Scorpio',
          mars: 'Aquarius'
        }
      }
    };
  }
  
  return {
    message: 'Calculation completed successfully',
    orderType: order_for,
    timestamp: new Date().toISOString()
  };
};

// @desc    Create paid Kundli calculation
// @route   POST /api/paidKundli/createCalculation
// @access  Private
exports.createCalculation = asyncHandler(async (req, res, next) => {
  try {
    const { 
      user_uni_id, 
      api_key, 
      order_for,
      pdf_type = 'medium',
      payment_method = 'razorpay',
      orderUrl,
      payment_status = 'Pending',
      payment_id = null // New parameter for payment ID
    } = req.body;

    // Validate required fields
    if (!user_uni_id || !api_key) {
      return next(new ErrorResponse('user_uni_id and api_key are required', 400));
    }

    if (!order_for || !['horoscope', 'matching'].includes(order_for)) {
      return next(new ErrorResponse('order_for must be either "horoscope" or "matching"', 400));
    }

    if (!pdf_type || !['small', 'medium', 'large'].includes(pdf_type)) {
      return next(new ErrorResponse('pdf_type must be either "small", "medium", or "large"', 400));
    }

    // Verify user
    const user = await User.findOne({ user_uni_id: user_uni_id, api_key, isActive: true });
    if (!user) {
      return next(new ErrorResponse('Invalid user_uni_id or api_key', 401));
    }

    // Get current pricing
    const pricingConfig = await getCurrentPricing();

    // Get PDF type pricing
    const pdfTypePricing = pricingConfig.pdfTypes[pdf_type];
    if (!pdfTypePricing) {
      return next(new ErrorResponse(`Invalid PDF type: ${pdf_type}`, 400));
    }

    const pdfTypePrice = pdfTypePricing.price;
    const gstAmount = Math.round((pdfTypePrice * pricingConfig.gstPercentage) / 100);
    const totalAmount = pdfTypePrice + gstAmount;

    // Create new paid Kundli record without orderId initially
    const paidKundliData = {
      user: user._id,
      name: 'User Calculation', // Default name
      dateOfBirth: new Date(), // Current date as default
      timeOfBirth: '00:00', // Default time
      placeOfBirth: 'Not specified', // Default place
      gender: 'Other', // Default gender
      order_for,
      pdf_type,
      payment_method,
      orderUrl: orderUrl || null,
      basePrice: pricingConfig.basePrice,
      pdfTypePrice: pdfTypePrice,
      gstPercentage: pricingConfig.gstPercentage,
      gstAmount: gstAmount,
      totalAmount: totalAmount,
      status: 'Pending',
      paymentStatus: payment_status
    };

    const paidKundli = await PaidKundli.create(paidKundliData);

    // Only generate orderId if payment_id is provided AND payment_status is 'Completed'
    let orderId = null;
    if (payment_id && payment_status === 'Completed') {
      let isUnique = false;
      let attempts = 0;
      const maxAttempts = 10;

      // Keep trying until we get a unique orderId
      while (!isUnique && attempts < maxAttempts) {
        const now = new Date();
        const datePrefix = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
        const sequenceNumber = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
        const randomSuffix = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
        const extraRandom = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
        
        orderId = `ORD${datePrefix}${sequenceNumber}${randomSuffix}${extraRandom}`;
        
        // Check if orderId already exists
        const existingOrder = await PaidKundli.findOne({ orderId: orderId });
        if (!existingOrder) {
          isUnique = true;
        }
        attempts++;
      }

      if (!isUnique) {
        return next(new ErrorResponse('Failed to generate unique order ID after multiple attempts', 500));
      }
      
      // Update the record with orderId
      paidKundli.orderId = orderId;
      await paidKundli.save();
    }

    res.status(201).json({
      success: true,
      message: payment_status === 'Completed' && payment_id ? 'Order created successfully' : 'Payment intent created successfully',
      data: {
        order_id: orderId,
        payment_id: payment_id,
        orderUrl: paidKundli.orderUrl,
        pdf_type: paidKundli.pdf_type,
        paymentStatus: paidKundli.paymentStatus,
        totalAmount: paidKundli.totalAmount
      }
    });
  } catch (error) {
    next(error);
  }
});





// @desc    Get user's paid Kundli calculations
// @route   GET /api/paidKundli/userCalculations
// @access  Private
exports.getUserCalculations = asyncHandler(async (req, res, next) => {
  try {
    const { user_uni_id, api_key, paymentStatus, status } = req.query;

    // Validate required fields
    if (!user_uni_id || !api_key) {
      return next(new ErrorResponse('user_uni_id and api_key are required', 400));
    }

    // Verify user
    const user = await User.findOne({ user_uni_id: user_uni_id, api_key, isActive: true });
    if (!user) {
      return next(new ErrorResponse('Invalid user_uni_id or api_key', 401));
    }

    // Build query
    const query = { user: user._id };
    if (paymentStatus) query.paymentStatus = paymentStatus;
    if (status) query.status = status;

    const calculations = await PaidKundli.find(query)
      .sort({ createdAt: -1 })
      .exec();

    const total = await PaidKundli.countDocuments(query);

    res.status(200).json({
      success: true,
      count: calculations.length,
      total,
      data: calculations.map(calc => calc.getFormattedData())
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Get order list by user credentials (with optional URL update)
// @route   GET /api/paidKundli/orders
// @access  Private
exports.getOrderList = asyncHandler(async (req, res, next) => {
  try {
    const { user_uni_id, api_key, orderUrl, order_id } = req.query;

    // Validate required fields
    if (!user_uni_id || !api_key) {
      return next(new ErrorResponse('user_uni_id and api_key are required', 400));
    }

    // Verify user
    const user = await User.findOne({ user_uni_id: user_uni_id, api_key, isActive: true });
    if (!user) {
      return next(new ErrorResponse('Invalid user_uni_id or api_key', 401));
    }

    // Get all orders for this user
    const allOrders = await PaidKundli.find({ user: user._id })
      .sort({ createdAt: -1 })
      .exec();

    const total = await PaidKundli.countDocuments({ user: user._id });

    // If order_id is provided, find specific order (no URL update)
    let currentOrder = null;
    if (order_id) {
      currentOrder = await PaidKundli.findOne({ orderId: order_id, user: user._id });
    }

    res.status(200).json({
      success: true,
      currentOrder: currentOrder ? currentOrder.getFormattedData() : null,
      orderList: {
        count: allOrders.length,
        total: total,
        data: allOrders.map(order => order.getFormattedData())
      }
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Update paid Kundli calculation
// @route   PUT /api/paidKundli/updateCalculation/:id
// @access  Private
exports.updateCalculation = asyncHandler(async (req, res, next) => {
  try {
    const { user_uni_id, api_key } = req.query;
    const { id } = req.params;
    const updateData = req.body;

    // Validate required fields
    if (!user_uni_id || !api_key) {
      return next(new ErrorResponse('user_uni_id and api_key are required', 400));
    }

    // Verify user
    const user = await User.findOne({ user_uni_id: user_uni_id, api_key, isActive: true });
    if (!user) {
      return next(new ErrorResponse('Invalid user_uni_id or api_key', 401));
    }

    // Find calculation
    let calculation;
    try {
      // Check if id is a valid MongoDB ObjectId
      if (!id || !/^[0-9a-fA-F]{24}$/.test(id)) {
        return next(new ErrorResponse('Invalid calculation ID format. Please provide a valid ID.', 400));
      }
      calculation = await PaidKundli.findById(id);
    } catch (error) {
      if (error.name === 'CastError') {
        return next(new ErrorResponse('Invalid calculation ID format. Please provide a valid ID.', 400));
      }
      throw error;
    }

    if (!calculation) {
      return next(new ErrorResponse('Calculation not found', 404));
    }

    // Check if user owns this calculation
    if (calculation.user.toString() !== user._id.toString()) {
      return next(new ErrorResponse('Not authorized to update this calculation', 403));
    }

    // Update calculation
    const updatedCalculation = await PaidKundli.findByIdAndUpdate(
      id,
      updateData,
      { new: true, runValidators: true }
    );

    res.status(200).json({
      success: true,
      message: 'Calculation updated successfully',
      data: updatedCalculation.getFormattedData()
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Delete paid Kundli calculation
// @route   DELETE /api/paidKundli/deleteCalculation/:id
// @access  Private
exports.deleteCalculation = asyncHandler(async (req, res, next) => {
  try {
    const { user_uni_id, api_key } = req.query;
    const { id } = req.params;

    // Validate required fields
    if (!user_uni_id || !api_key) {
      return next(new ErrorResponse('user_uni_id and api_key are required', 400));
    }

    // Verify user
    const user = await User.findOne({ user_uni_id: user_uni_id, api_key, isActive: true });
    if (!user) {
      return next(new ErrorResponse('Invalid user_uni_id or api_key', 401));
    }

    // Find calculation
    let calculation;
    try {
      // Check if id is a valid MongoDB ObjectId
      if (!id || !/^[0-9a-fA-F]{24}$/.test(id)) {
        return next(new ErrorResponse('Invalid calculation ID format. Please provide a valid ID.', 400));
      }
      calculation = await PaidKundli.findById(id);
    } catch (error) {
      if (error.name === 'CastError') {
        return next(new ErrorResponse('Invalid calculation ID format. Please provide a valid ID.', 400));
      }
      throw error;
    }

    if (!calculation) {
      return next(new ErrorResponse('Calculation not found', 404));
    }

    // Check if user owns this calculation
    if (calculation.user.toString() !== user._id.toString()) {
      return next(new ErrorResponse('Not authorized to delete this calculation', 403));
    }

    // Delete calculation
    await calculation.deleteOne();

    res.status(200).json({
      success: true,
      message: 'Calculation deleted successfully'
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Update payment status and generate orderId when payment is completed
// @route   PUT /api/paidKundli/updatePaymentStatus/:id
// @access  Private
exports.updatePaymentStatus = asyncHandler(async (req, res, next) => {
  try {
    const { user_uni_id, api_key, payment_status, orderUrl, payment_id } = req.body;
    const { id } = req.params;

    // Validate required fields
    if (!user_uni_id || !api_key) {
      return next(new ErrorResponse('user_uni_id and api_key are required', 400));
    }

    if (!payment_status || !['Pending', 'Completed', 'Failed', 'Refunded'].includes(payment_status)) {
      return next(new ErrorResponse('Invalid payment_status. Must be one of: Pending, Completed, Failed, Refunded', 400));
    }

    // Require payment_id when status is 'Completed'
    if (payment_status === 'Completed' && !payment_id) {
      return next(new ErrorResponse('payment_id is required when payment_status is "Completed"', 400));
    }

    // Verify user
    const user = await User.findOne({ user_uni_id: user_uni_id, api_key, isActive: true });
    if (!user) {
      return next(new ErrorResponse('Invalid user_uni_id or api_key', 401));
    }

    // Find calculation
    let calculation;
    try {
      // Check if id is a valid MongoDB ObjectId
      if (!id || !/^[0-9a-fA-F]{24}$/.test(id)) {
        return next(new ErrorResponse('Invalid calculation ID format. Please provide a valid ID.', 400));
      }
      calculation = await PaidKundli.findById(id);
    } catch (error) {
      if (error.name === 'CastError') {
        return next(new ErrorResponse('Invalid calculation ID format. Please provide a valid ID.', 400));
      }
      throw error;
    }

    if (!calculation) {
      return next(new ErrorResponse('Calculation not found', 404));
    }

    // Check if user owns this calculation
    if (calculation.user.toString() !== user._id.toString()) {
      return next(new ErrorResponse('Not authorized to update this calculation', 403));
    }

    // Update payment status
    calculation.paymentStatus = payment_status;
    
    // Update orderUrl if provided
    if (orderUrl) {
      calculation.orderUrl = orderUrl;
    }

    // Generate orderId if payment is completed, payment_id is provided, and orderId doesn't exist
    if (payment_status === 'Completed' && payment_id && !calculation.orderId) {
      let orderId;
      let isUnique = false;
      let attempts = 0;
      const maxAttempts = 10;

      // Keep trying until we get a unique orderId
      while (!isUnique && attempts < maxAttempts) {
        const now = new Date();
        const datePrefix = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
        const sequenceNumber = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
        const randomSuffix = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
        const extraRandom = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
        
        orderId = `ORD${datePrefix}${sequenceNumber}${randomSuffix}${extraRandom}`;
        
        // Check if orderId already exists
        const existingOrder = await PaidKundli.findOne({ orderId: orderId });
        if (!existingOrder) {
          isUnique = true;
        }
        attempts++;
      }

      if (!isUnique) {
        return next(new ErrorResponse('Failed to generate unique order ID after multiple attempts', 500));
      }

      calculation.orderId = orderId;
    }

    // Update status based on payment status
    if (payment_status === 'Completed') {
      calculation.status = 'Processing';
    } else if (payment_status === 'Failed') {
      calculation.status = 'Failed';
    }

    await calculation.save();

    res.status(200).json({
      success: true,
      message: 'Payment status updated successfully',
      data: {
        order_id: calculation.orderId,
        payment_id: payment_id,
        orderUrl: calculation.orderUrl,
        paymentStatus: calculation.paymentStatus,
        status: calculation.status
      }
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Get PDF type pricing information
// @route   GET /api/paidKundli/pdfPricing
// @access  Public
exports.getPdfPricing = asyncHandler(async (req, res, next) => {
  try {
    const pricingConfig = await getCurrentPricing();

    // Calculate pricing for each PDF type
    const pdfPricing = {};
    Object.keys(pricingConfig.pdfTypes).forEach(pdfType => {
      const typeConfig = pricingConfig.pdfTypes[pdfType];
      const gstAmount = Math.round((typeConfig.price * pricingConfig.gstPercentage) / 100);
      const totalAmount = typeConfig.price + gstAmount;
      
      pdfPricing[pdfType] = {
        price: typeConfig.price,
        description: typeConfig.description,
        gstPercentage: pricingConfig.gstPercentage,
        gstAmount: gstAmount,
        totalAmount: totalAmount
      };
    });

    res.status(200).json({
      success: true,
      data: {
        pdfTypes: pdfPricing,
        gstPercentage: pricingConfig.gstPercentage,
        serviceName: pricingConfig.serviceName,
        description: pricingConfig.description
      }
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Get current pricing configuration
// @route   GET /api/paidKundli/pricing
// @access  Public
exports.getPricing = asyncHandler(async (req, res, next) => {
  try {
    const pricingConfig = await getCurrentPricing();

    res.status(200).json({
      success: true,
      data: pricingConfig.getFormattedData()
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Get comprehensive pricing with all PDF types and calculations
// @route   GET /api/paidKundli/getAllPricing
// @access  Public
exports.getAllPricing = asyncHandler(async (req, res, next) => {
  try {
    const pricingConfig = await getCurrentPricing();

    // Calculate pricing for all PDF types
    const allPdfTypes = {};
    Object.keys(pricingConfig.pdfTypes).forEach(pdfType => {
      const typeConfig = pricingConfig.pdfTypes[pdfType];
      const gstAmount = Math.round((typeConfig.price * pricingConfig.gstPercentage) / 100);
      const totalAmount = typeConfig.price + gstAmount;
      
      allPdfTypes[pdfType] = {
        price: typeConfig.price,
        description: typeConfig.description,
        gstAmount: gstAmount,
        totalAmount: totalAmount
      };
    });

    res.status(200).json({
      success: true,
      data: {
        serviceName: pricingConfig.serviceName,
        basePrice: pricingConfig.basePrice,
        gstPercentage: pricingConfig.gstPercentage,
        description: pricingConfig.description,
        isActive: pricingConfig.isActive,
        allPdfTypes: allPdfTypes,
        lastUpdated: pricingConfig.updatedAt
      }
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Update pricing configuration (Admin only)
// @route   PUT /api/paidKundli/updatePricing
// @access  Private (Admin)
exports.updatePricing = asyncHandler(async (req, res, next) => {
  try {
    const { basePrice, gstPercentage, serviceName, description, pdfTypes, pdf_type } = req.body;

    // Find or create pricing config
    let pricingConfig = await PricingConfig.findOne({ serviceName: 'Paid Kundli Calculation' });
    
    if (!pricingConfig) {
      pricingConfig = new PricingConfig({
        serviceName: 'Paid Kundli Calculation',
        updatedBy: req.user._id
      });
    }

    // Update fields
    if (basePrice !== undefined) pricingConfig.basePrice = basePrice;
    if (gstPercentage !== undefined) pricingConfig.gstPercentage = gstPercentage;
    if (serviceName !== undefined) pricingConfig.serviceName = serviceName;
    if (description !== undefined) pricingConfig.description = description;
    
    // Update PDF types pricing
    if (pdfTypes !== undefined) {
      // Validate PDF types structure
      const validPdfTypes = ['small', 'medium', 'large'];
      const updatedPdfTypes = {};
      
      validPdfTypes.forEach(type => {
        if (pdfTypes[type]) {
          updatedPdfTypes[type] = {
            price: pdfTypes[type].price || 199,
            description: pdfTypes[type].description || `${type.charAt(0).toUpperCase() + type.slice(1)} PDF Report`
          };
        } else {
          // Keep existing values if not provided
          updatedPdfTypes[type] = pricingConfig.pdfTypes[type] || {
            price: type === 'small' ? 199 : type === 'medium' ? 399 : 599,
            description: `${type.charAt(0).toUpperCase() + type.slice(1)} PDF Report`
          };
        }
      });
      
      pricingConfig.pdfTypes = updatedPdfTypes;
    }
    
    // Handle individual pdf_type update (for backward compatibility)
    if (pdf_type && pdfTypes && pdfTypes[pdf_type]) {
      if (!pricingConfig.pdfTypes) {
        pricingConfig.pdfTypes = {
          small: { price: 199, description: 'Basic PDF Report' },
          medium: { price: 399, description: 'Standard PDF Report' },
          large: { price: 599, description: 'Premium PDF Report' }
        };
      }
      
      pricingConfig.pdfTypes[pdf_type] = {
        price: pdfTypes[pdf_type].price || pricingConfig.pdfTypes[pdf_type].price,
        description: pdfTypes[pdf_type].description || pricingConfig.pdfTypes[pdf_type].description
      };
    }
    
    pricingConfig.updatedBy = req.user._id;

    await pricingConfig.save();

    res.status(200).json({
      success: true,
      message: 'Pricing configuration updated successfully',
      data: pricingConfig.getFormattedData()
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Get Paid Kundli statistics (Admin only)
// @route   GET /api/paidKundli/stats
// @access  Private (Admin)
exports.getStats = asyncHandler(async (req, res, next) => {
  try {
    // Get basic statistics
    const totalCalculations = await PaidKundli.countDocuments();
    const completedCalculations = await PaidKundli.countDocuments({ status: 'completed' });
    const pendingCalculations = await PaidKundli.countDocuments({ status: 'pending' });
    const failedCalculations = await PaidKundli.countDocuments({ status: 'failed' });

    // Get revenue statistics
    const revenueStats = await PaidKundli.aggregate([
      { $match: { status: 'completed' } },
      { $group: { _id: null, totalRevenue: { $sum: '$amount' } } }
    ]);

    // Get calculations by type
    const calculationsByType = await PaidKundli.aggregate([
      { $group: { _id: '$order_for', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);

    // Get recent calculations
    const recentCalculations = await PaidKundli.find()
      .sort({ createdAt: -1 })
      .limit(5)
      .select('order_for status amount createdAt')
      .populate('user', 'name email phone')
      .exec();

    // Get monthly statistics
    const lastMonth = new Date();
    lastMonth.setMonth(lastMonth.getMonth() - 1);
    const monthlyStats = await PaidKundli.aggregate([
      { $match: { createdAt: { $gte: lastMonth } } },
      { $group: { _id: null, count: { $sum: 1 }, revenue: { $sum: '$amount' } } }
    ]);

    res.status(200).json({
      success: true,
      message: 'Paid Kundli statistics retrieved successfully',
      data: {
        overview: {
          totalCalculations,
          completedCalculations,
          pendingCalculations,
          failedCalculations,
          totalRevenue: revenueStats[0]?.totalRevenue || 0,
          completionRate: totalCalculations > 0 ? Math.round((completedCalculations / totalCalculations) * 100) : 0
        },
        calculationsByType,
        recentCalculations,
        monthlyStats: {
          count: monthlyStats[0]?.count || 0,
          revenue: monthlyStats[0]?.revenue || 0
        }
      }
    });
  } catch (error) {
    next(error);
  }
}); 