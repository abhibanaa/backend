const express = require('express');
const router = express.Router();

// Import controller
const {
  createRazorpayConfig,
  getAllRazorpayConfigs,
  getRazorpayConfigById,
  updateRazorpayConfig,
  deleteRazorpayConfig,
  toggleRazorpayConfigStatus,
  getRazorpayStats
} = require('./adminRazorpayController');

// Import middleware
const { protect, authorize } = require('../../middlewares/authMiddleware');

// All routes require admin authentication
router.use(protect);
router.use(authorize('admin'));

// Admin routes
router.route('/config')
  .post(createRazorpayConfig)
  .get(getAllRazorpayConfigs);

router.route('/config/:id')
  .get(getRazorpayConfigById)
  .put(updateRazorpayConfig)
  .delete(deleteRazorpayConfig);

router.patch('/config/:id/toggle', toggleRazorpayConfigStatus);
router.get('/stats', getRazorpayStats);

module.exports = router; 