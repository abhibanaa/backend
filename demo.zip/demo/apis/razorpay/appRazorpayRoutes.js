const express = require('express');
const router = express.Router();

// Import controller
const {
  getActiveRazorpayConfig,
  getAllActiveRazorpayConfigs,
  getRazorpayStatus
} = require('./appRazorpayController');

// Public routes (no authentication required)
router.get('/config/:environment', getActiveRazorpayConfig);
router.get('/configs', getAllActiveRazorpayConfigs);
router.get('/status', getRazorpayStatus);

module.exports = router; 