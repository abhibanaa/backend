const express = require('express');
const router = express.Router();

// Import controller
const {
  createRazorpayConfig,
  getAllRazorpayConfigs,
  getRazorpayConfigById,
  updateRazorpayConfig,
  deleteRazorpayConfig,
  getActiveRazorpayConfig,
  toggleRazorpayConfigStatus
} = require('./razorpayController');

// Import middleware
const { protect, authorize } = require('../../middlewares/authMiddleware');

// Public routes (for payment processing)
router.get('/config/active/:environment', getActiveRazorpayConfig);

// Protected routes (Admin only)
router.use(protect);
router.use(authorize('admin'));

// Admin routes
router.route('/config')
  .post(createRazorpayConfig)
  .get(getAllRazorpayConfigs);

router.route('/config/:id')
  .get(getRazorpayConfigById)
  .put(updateRazorpayConfig)
  .delete(deleteRazorpayConfig);

router.patch('/config/:id/toggle', toggleRazorpayConfigStatus);

module.exports = router; 