const RazorpayConfig = require('../../models/RazorpayConfig');
const asyncHandler = require('express-async-handler');
const ErrorResponse = require('../../utils/errorResponse');

// @desc    Get active Razorpay configuration for environment (Public)
// @route   GET /api/app/razorpay/config/:environment
// @access  Public
exports.getActiveRazorpayConfig = asyncHandler(async (req, res, next) => {
  const { environment = 'test' } = req.params;

  const razorpayConfig = await RazorpayConfig.findOne({ 
    environment, 
    isActive: true 
  });

  if (!razorpayConfig) {
    return next(new ErrorResponse(`No active Razorpay configuration found for ${environment} environment`, 404));
  }

  res.status(200).json({
    success: true,
    message: 'Active Razorpay configuration retrieved successfully',
    data: razorpayConfig.getFormattedData() // Don't expose full key
  });
});

// @desc    Get all active Razorpay configurations (Public)
// @route   GET /api/app/razorpay/configs
// @access  Public
exports.getAllActiveRazorpayConfigs = asyncHandler(async (req, res, next) => {
  const razorpayConfigs = await RazorpayConfig.find({ isActive: true });

  const formattedConfigs = razorpayConfigs.map(config => config.getFormattedData());

  res.status(200).json({
    success: true,
    message: 'Active Razorpay configurations retrieved successfully',
    data: formattedConfigs
  });
});

// @desc    Check Razorpay configuration status (Public)
// @route   GET /api/app/razorpay/status
// @access  Public
exports.getRazorpayStatus = asyncHandler(async (req, res, next) => {
  const testConfig = await RazorpayConfig.findOne({ environment: 'test', isActive: true });
  const liveConfig = await RazorpayConfig.findOne({ environment: 'live', isActive: true });

  res.status(200).json({
    success: true,
    message: 'Razorpay configuration status retrieved successfully',
    data: {
      test: {
        available: !!testConfig,
        environment: 'test'
      },
      live: {
        available: !!liveConfig,
        environment: 'live'
      }
    }
  });
}); 