const RazorpayConfig = require('../../models/RazorpayConfig');
const asyncHandler = require('../../middlewares/async');
const ErrorResponse = require('../../utils/errorResponse');

// @desc    Create new Razorpay configuration
// @route   POST /api/razorpay/config
// @access  Private (Admin only)
exports.createRazorpayConfig = asyncHandler(async (req, res, next) => {
  const { razorpayId, razorpayKey, razorpayXAccount, environment, description } = req.body;

  // Check if configuration already exists for the environment
  const existingConfig = await RazorpayConfig.findOne({ environment });
  if (existingConfig) {
    return next(new ErrorResponse(`Configuration for ${environment} environment already exists`, 400));
  }

  const razorpayConfig = await RazorpayConfig.create({
    razorpayId,
    razorpayKey,
    razorpayXAccount,
    environment,
    description,
    updatedBy: req.user ? req.user.id : null
  });

  res.status(201).json({
    success: true,
    message: 'Razorpay configuration created successfully',
    data: razorpayConfig.getFullData()
  });
});

// @desc    Get all Razorpay configurations
// @route   GET /api/razorpay/config
// @access  Private (Admin only)
exports.getAllRazorpayConfigs = asyncHandler(async (req, res, next) => {
  const { page = 1, limit = 10, environment, isActive } = req.query;

  // Build filter object
  const filter = {};
  if (environment) filter.environment = environment;
  if (isActive !== undefined) filter.isActive = isActive === 'true';

  const options = {
    page: parseInt(page, 10),
    limit: parseInt(limit, 10),
    sort: { updatedAt: -1 },
    populate: {
      path: 'updatedBy',
      select: 'name email'
    }
  };

  const configs = await RazorpayConfig.paginate(filter, options);

  // Format the data
  const formattedData = {
    ...configs,
    docs: configs.docs.map(config => config.getFullData())
  };

  res.status(200).json({
    success: true,
    message: 'Razorpay configurations retrieved successfully',
    data: formattedData
  });
});

// @desc    Get single Razorpay configuration by ID
// @route   GET /api/razorpay/config/:id
// @access  Private (Admin only)
exports.getRazorpayConfigById = asyncHandler(async (req, res, next) => {
  const razorpayConfig = await RazorpayConfig.findById(req.params.id)
    .populate('updatedBy', 'name email');

  if (!razorpayConfig) {
    return next(new ErrorResponse('Razorpay configuration not found', 404));
  }

  res.status(200).json({
    success: true,
    message: 'Razorpay configuration retrieved successfully',
    data: razorpayConfig.getFullData()
  });
});

// @desc    Update Razorpay configuration
// @route   PUT /api/razorpay/config/:id
// @access  Private (Admin only)
exports.updateRazorpayConfig = asyncHandler(async (req, res, next) => {
  const { razorpayId, razorpayKey, razorpayXAccount, environment, description, isActive } = req.body;

  let razorpayConfig = await RazorpayConfig.findById(req.params.id);

  if (!razorpayConfig) {
    return next(new ErrorResponse('Razorpay configuration not found', 404));
  }

  // If environment is being changed, check if it conflicts with existing config
  if (environment && environment !== razorpayConfig.environment) {
    const existingConfig = await RazorpayConfig.findOne({ 
      environment, 
      _id: { $ne: req.params.id } 
    });
    if (existingConfig) {
      return next(new ErrorResponse(`Configuration for ${environment} environment already exists`, 400));
    }
  }

  // Update fields
  const updateFields = {};
  if (razorpayId !== undefined) updateFields.razorpayId = razorpayId;
  if (razorpayKey !== undefined) updateFields.razorpayKey = razorpayKey;
  if (razorpayXAccount !== undefined) updateFields.razorpayXAccount = razorpayXAccount;
  if (environment !== undefined) updateFields.environment = environment;
  if (description !== undefined) updateFields.description = description;
  if (isActive !== undefined) updateFields.isActive = isActive;
  
  updateFields.updatedBy = req.user ? req.user.id : null;

  razorpayConfig = await RazorpayConfig.findByIdAndUpdate(
    req.params.id,
    updateFields,
    {
      new: true,
      runValidators: true
    }
  ).populate('updatedBy', 'name email');

  res.status(200).json({
    success: true,
    message: 'Razorpay configuration updated successfully',
    data: razorpayConfig.getFullData()
  });
});

// @desc    Delete Razorpay configuration
// @route   DELETE /api/razorpay/config/:id
// @access  Private (Admin only)
exports.deleteRazorpayConfig = asyncHandler(async (req, res, next) => {
  const razorpayConfig = await RazorpayConfig.findById(req.params.id);

  if (!razorpayConfig) {
    return next(new ErrorResponse('Razorpay configuration not found', 404));
  }

  await razorpayConfig.deleteOne();

  res.status(200).json({
    success: true,
    message: 'Razorpay configuration deleted successfully'
  });
});

// @desc    Get active Razorpay configuration for environment
// @route   GET /api/razorpay/config/active/:environment
// @access  Public (for payment processing)
exports.getActiveRazorpayConfig = asyncHandler(async (req, res, next) => {
  const { environment = 'test' } = req.params;

  const razorpayConfig = await RazorpayConfig.findOne({ 
    environment, 
    isActive: true 
  });

  if (!razorpayConfig) {
    return next(new ErrorResponse(`No active Razorpay configuration found for ${environment} environment`, 404));
  }

  res.status(200).json({
    success: true,
    message: 'Active Razorpay configuration retrieved successfully',
    data: razorpayConfig.getFormattedData() // Don't expose full key
  });
});

// @desc    Toggle Razorpay configuration status
// @route   PATCH /api/razorpay/config/:id/toggle
// @access  Private (Admin only)
exports.toggleRazorpayConfigStatus = asyncHandler(async (req, res, next) => {
  const razorpayConfig = await RazorpayConfig.findById(req.params.id);

  if (!razorpayConfig) {
    return next(new ErrorResponse('Razorpay configuration not found', 404));
  }

  razorpayConfig.isActive = !razorpayConfig.isActive;
  razorpayConfig.updatedBy = req.user ? req.user.id : null;
  await razorpayConfig.save();

  res.status(200).json({
    success: true,
    message: `Razorpay configuration ${razorpayConfig.isActive ? 'activated' : 'deactivated'} successfully`,
    data: razorpayConfig.getFullData()
  });
}); 