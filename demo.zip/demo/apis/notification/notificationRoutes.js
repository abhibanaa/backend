const express = require('express');
const {
  getNotifications,
  getNotification,
  markAsRead,
  markAllAsRead,
  deleteNotification,
  getUnreadCount,
  createNotification,
  broadcastNotification
} = require('./notificationController');

const { protect, authorize } = require('../../middlewares/authMiddleware');

const router = express.Router();

// Apply authentication to all routes
router.use(protect);

// User routes
router.route('/')
  .get(getNotifications);

router.route('/:id')
  .get(getNotification)
  .delete(deleteNotification);

router.route('/:id/read')
  .put(markAsRead);

router.route('/read-all')
  .put(markAllAsRead);

router.route('/unread-count')
  .get(getUnreadCount);

// Admin only routes
router.use(authorize('admin'));

router.route('/')
  .post(createNotification);

router.route('/broadcast')
  .post(broadcastNotification);

module.exports = router; 