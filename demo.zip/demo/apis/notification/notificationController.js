const Notification = require('../../models/Notification');
const ErrorResponse = require('../../utils/errorResponse');

// @desc    Get all notifications for user
// @route   GET /api/notifications
// @access  Private
exports.getNotifications = async (req, res, next) => {
  try {
    const { page = 1, limit = 20, unreadOnly = false } = req.query;
    
    let query = { user: req.user.id };
    
    if (unreadOnly === 'true') {
      query.isRead = false;
    }

    const notifications = await Notification.find(query)
      .sort('-createdAt')
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .populate('user', 'name');

    const total = await Notification.countDocuments(query);

    res.status(200).json({
      success: true,
      count: notifications.length,
      total,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      data: notifications
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single notification
// @route   GET /api/notifications/:id
// @access  Private
exports.getNotification = async (req, res, next) => {
  try {
    const notification = await Notification.findById(req.params.id)
      .populate('user', 'name');

    if (!notification) {
      return next(new ErrorResponse('Notification not found', 404));
    }

    // Check if user owns notification
    if (notification.user._id.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new ErrorResponse('Not authorized to access this notification', 401));
    }

    res.status(200).json({
      success: true,
      data: notification
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Mark notification as read
// @route   PUT /api/notifications/:id/read
// @access  Private
exports.markAsRead = async (req, res, next) => {
  try {
    const notification = await Notification.findById(req.params.id);

    if (!notification) {
      return next(new ErrorResponse('Notification not found', 404));
    }

    // Check if user owns notification
    if (notification.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new ErrorResponse('Not authorized to update this notification', 401));
    }

    notification.isRead = true;
    await notification.save();

    res.status(200).json({
      success: true,
      data: notification
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Mark all notifications as read
// @route   PUT /api/notifications/read-all
// @access  Private
exports.markAllAsRead = async (req, res, next) => {
  try {
    await Notification.updateMany(
      { user: req.user.id, isRead: false },
      { isRead: true }
    );

    res.status(200).json({
      success: true,
      message: 'All notifications marked as read'
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete notification
// @route   DELETE /api/notifications/:id
// @access  Private
exports.deleteNotification = async (req, res, next) => {
  try {
    const notification = await Notification.findById(req.params.id);

    if (!notification) {
      return next(new ErrorResponse('Notification not found', 404));
    }

    // Check if user owns notification
    if (notification.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new ErrorResponse('Not authorized to delete this notification', 401));
    }

    await notification.remove();

    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get unread count
// @route   GET /api/notifications/unread-count
// @access  Private
exports.getUnreadCount = async (req, res, next) => {
  try {
    const count = await Notification.countDocuments({
      user: req.user.id,
      isRead: false
    });

    res.status(200).json({
      success: true,
      data: { unreadCount: count }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Create notification (Admin only)
// @route   POST /api/notifications
// @access  Private/Admin
exports.createNotification = async (req, res, next) => {
  try {
    const { userId, title, message, type, category, isImportant, actionUrl, actionText } = req.body;

    const notification = await Notification.create({
      user: userId,
      title,
      message,
      type,
      category,
      isImportant,
      actionUrl,
      actionText
    });

    // Emit real-time notification
    req.app.get('io').to(`user_${userId}`).emit('new_notification', {
      notification: await notification.populate('user', 'name')
    });

    res.status(201).json({
      success: true,
      data: notification
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Send notification to all users (Admin only)
// @route   POST /api/notifications/broadcast
// @access  Private/Admin
exports.broadcastNotification = async (req, res, next) => {
  try {
    const { title, message, type, category, isImportant, actionUrl, actionText } = req.body;

    // Get all users
    const User = require('../../models/User');
    const users = await User.find({ role: 'user' });

    // Create notifications for all users
    const notifications = [];
    for (const user of users) {
      const notification = await Notification.create({
        user: user._id,
        title,
        message,
        type,
        category,
        isImportant,
        actionUrl,
        actionText
      });
      notifications.push(notification);
    }

    // Emit real-time notification to all users
    req.app.get('io').emit('broadcast_notification', {
      title,
      message,
      type,
      category,
      isImportant,
      actionUrl,
      actionText
    });

    res.status(201).json({
      success: true,
      message: `Notification sent to ${users.length} users`,
      data: { count: notifications.length }
    });
  } catch (error) {
    next(error);
  }
}; 