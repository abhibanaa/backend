const Horoscope = require('../../models/Horoscope');
const ErrorResponse = require('../../utils/errorResponse');

// @desc    Create new horoscope
// @route   POST /api/horoscope
// @access  Private (Admin only)
exports.createHoroscope = async (req, res, next) => {
  try {
    const horoscope = await Horoscope.create(req.body);

    res.status(201).json({
      success: true,
      data: horoscope
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all horoscopes
// @route   GET /api/horoscope
// @access  Public
exports.getHoroscopes = async (req, res, next) => {
  try {
    let query;

    // Copy req.query
    const reqQuery = { ...req.query };

    // Fields to exclude
    const removeFields = ['select', 'sort', 'page', 'limit'];

    // Loop over removeFields and delete them from reqQuery
    removeFields.forEach(param => delete reqQuery[param]);

    // Create query string
    let queryStr = JSON.stringify(reqQuery);

    // Create operators ($gt, $gte, etc)
    queryStr = queryStr.replace(/\b(gt|gte|lt|lte|in)\b/g, match => `$${match}`);

    // Finding resource
    query = Horoscope.find(JSON.parse(queryStr));

    // Select Fields
    if (req.query.select) {
      const fields = req.query.select.split(',').join(' ');
      query = query.select(fields);
    }

    // Sort
    if (req.query.sort) {
      const sortBy = req.query.sort.split(',').join(' ');
      query = query.sort(sortBy);
    } else {
      query = query.sort('-date');
    }

    // Pagination
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 25;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const total = await Horoscope.countDocuments();

    query = query.skip(startIndex).limit(limit);

    // Executing query
    const horoscopes = await query;

    // Pagination result
    const pagination = {};

    if (endIndex < total) {
      pagination.next = {
        page: page + 1,
        limit
      };
    }

    if (startIndex > 0) {
      pagination.prev = {
        page: page - 1,
        limit
      };
    }

    res.status(200).json({
      success: true,
      count: horoscopes.length,
      pagination,
      data: horoscopes
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single horoscope
// @route   GET /api/horoscope/:id
// @access  Public
exports.getHoroscope = async (req, res, next) => {
  try {
    const horoscope = await Horoscope.findById(req.params.id);

    if (!horoscope) {
      return next(new ErrorResponse(`Horoscope not found with id of ${req.params.id}`, 404));
    }

    res.status(200).json({
      success: true,
      data: horoscope
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update horoscope
// @route   PUT /api/horoscope/:id
// @access  Private (Admin only)
exports.updateHoroscope = async (req, res, next) => {
  try {
    let horoscope = await Horoscope.findById(req.params.id);

    if (!horoscope) {
      return next(new ErrorResponse(`Horoscope not found with id of ${req.params.id}`, 404));
    }

    horoscope = await Horoscope.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    res.status(200).json({
      success: true,
      data: horoscope
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete horoscope
// @route   DELETE /api/horoscope/:id
// @access  Private (Admin only)
exports.deleteHoroscope = async (req, res, next) => {
  try {
    const horoscope = await Horoscope.findById(req.params.id);

    if (!horoscope) {
      return next(new ErrorResponse(`Horoscope not found with id of ${req.params.id}`, 404));
    }

    await horoscope.remove();

    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get horoscope by zodiac sign and type
// @route   GET /api/horoscope/:zodiacSign/:type
// @access  Public
exports.getHoroscopeByZodiacAndType = async (req, res, next) => {
  try {
    const { zodiacSign, type } = req.params;
    const { date } = req.query;

    let query = {
      zodiacSign,
      type
    };

    if (date) {
      query.date = new Date(date);
    }

    const horoscope = await Horoscope.findOne(query).sort('-date');

    if (!horoscope) {
      return res.status(404).json({
        success: false,
        message: `No ${type} horoscope found for ${zodiacSign}`
      });
    }

    res.status(200).json({
      success: true,
      data: horoscope
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get daily horoscope for all signs
// @route   GET /api/horoscope/daily
// @access  Public
exports.getDailyHoroscopes = async (req, res, next) => {
  try {
    const { date } = req.query;
    const queryDate = date ? new Date(date) : new Date();

    const horoscopes = await Horoscope.find({
      type: 'daily',
      date: {
        $gte: new Date(queryDate.setHours(0, 0, 0, 0)),
        $lt: new Date(queryDate.setHours(23, 59, 59, 999))
      }
    }).sort('zodiacSign');

    res.status(200).json({
      success: true,
      count: horoscopes.length,
      data: horoscopes
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get weekly horoscope for all signs
// @route   GET /api/horoscope/weekly
// @access  Public
exports.getWeeklyHoroscopes = async (req, res, next) => {
  try {
    const { date } = req.query;
    const queryDate = date ? new Date(date) : new Date();

    const horoscopes = await Horoscope.find({
      type: 'weekly',
      date: {
        $gte: new Date(queryDate.setHours(0, 0, 0, 0)),
        $lt: new Date(queryDate.setHours(23, 59, 59, 999))
      }
    }).sort('zodiacSign');

    res.status(200).json({
      success: true,
      count: horoscopes.length,
      data: horoscopes
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Generate personalized horoscope
// @route   POST /api/horoscope/personalized
// @access  Private
exports.generatePersonalizedHoroscope = async (req, res, next) => {
  try {
    const { zodiacSign, type, date } = req.body;

    // Get base horoscope
    const baseHoroscope = await Horoscope.findOne({
      zodiacSign,
      type,
      date: new Date(date)
    });

    if (!baseHoroscope) {
      return res.status(404).json({
        success: false,
        message: `No ${type} horoscope found for ${zodiacSign}`
      });
    }

    // Create personalized version
    const personalizedHoroscope = await Horoscope.create({
      user: req.user.id,
      type,
      date: new Date(date),
      zodiacSign,
      content: baseHoroscope.content,
      lucky: baseHoroscope.lucky,
      planetaryInfluences: baseHoroscope.planetaryInfluences,
      compatibility: baseHoroscope.compatibility,
      mood: baseHoroscope.mood,
      energy: baseHoroscope.energy,
      isPersonalized: true
    });

    res.status(201).json({
      success: true,
      data: personalizedHoroscope
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get user's personalized horoscopes
// @route   GET /api/horoscope/personalized
// @access  Private
exports.getPersonalizedHoroscopes = async (req, res, next) => {
  try {
    const horoscopes = await Horoscope.find({
      user: req.user.id,
      isPersonalized: true
    }).sort('-date');

    res.status(200).json({
      success: true,
      count: horoscopes.length,
      data: horoscopes
    });
  } catch (error) {
    next(error);
  }
}; 