const express = require('express');
const {
  createHoroscope,
  getHoroscopes,
  getHoroscope,
  updateHoroscope,
  deleteHoroscope,
  getHoroscopeByZodiacAndType,
  getDailyHoroscopes,
  getWeeklyHoroscopes,
  generatePersonalizedHoroscope,
  getPersonalizedHoroscopes
} = require('./horoscopeController');

const { protect, authorize, optionalAuth } = require('../../middlewares/authMiddleware');

const router = express.Router();

// Public routes
router.route('/')
  .get(getHoroscopes);

router.route('/:id')
  .get(getHoroscope);

router.route('/daily')
  .get(getDailyHoroscopes);

router.route('/weekly')
  .get(getWeeklyHoroscopes);

router.route('/:zodiacSign/:type')
  .get(getHoroscopeByZodiacAndType);

// Protected routes
router.use(protect);

router.route('/personalized')
  .post(generatePersonalizedHoroscope)
  .get(getPersonalizedHoroscopes);

// Admin only routes
router.use(authorize('admin'));

router.route('/')
  .post(createHoroscope);

router.route('/:id')
  .put(updateHoroscope)
  .delete(deleteHoroscope);

module.exports = router; 