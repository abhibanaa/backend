const express = require('express');
const { body, param, query, validationResult } = require('express-validator');
const {
  register,
  sendOTP,
  login,
  adminLogin,
  getMe,
  updateDetails,
  logout,
  deleteAccount,
  // Admin functions
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
  createUser,
  getDashboardStats,
  changeUserRole,
  toggleUserStatus,
  getUserProfile,
  regenerateApiKey,
  getUserByUserId,
  getUserByApiKey
} = require('./authController');

const { protect, authorize } = require('../../middlewares/authMiddleware');
const { handleUpload } = require('../../middlewares/uploadMiddleware');
const multer = require('multer'); // Added multer for debug upload
const path = require('path'); // Added path for debug upload

const router = express.Router();

// Validation middleware
const registerValidation = [
  body('name').trim().isLength({ min: 2 }).withMessage('Name must be at least 2 characters long'),
  body('email').isEmail().withMessage('Please provide a valid email'),
  body('phone').notEmpty().withMessage('Phone number is required'),
  body('dateOfBirth').notEmpty().withMessage('Date of birth is required'),
  body('timeOfBirth').notEmpty().withMessage('Time of birth is required'),
  body('placeOfBirth').notEmpty().withMessage('Place of birth is required')
];

const sendOTPValidation = [
  body('phone').notEmpty().withMessage('Phone number is required')
];

const sendOTPParamValidation = [
  param('phone').notEmpty().withMessage('Phone number is required')
];

const loginValidation = [
  body('phone').notEmpty().withMessage('Phone number is required'),
  body('otp').isLength({ min: 6, max: 6 }).withMessage('OTP must be 6 digits')
];

const loginQueryValidation = [
  query('phone').notEmpty().withMessage('Phone number is required'),
  query('otp').isLength({ min: 6, max: 6 }).withMessage('OTP must be 6 digits')
];

const adminLoginValidation = [
  body('username').notEmpty().withMessage('Username is required'),
  body('password').notEmpty().withMessage('Password is required')
];

const createUserValidation = [
  body('name').trim().isLength({ min: 2 }).withMessage('Name must be at least 2 characters long'),
  body('email').isEmail().withMessage('Please provide a valid email'),
  body('phone').notEmpty().withMessage('Phone number is required')
];

// Public routes
router.post('/register', registerValidation, register);

// Single OTP endpoint - accepts phone in body or query parameter
router.post('/send-otp', (req, res, next) => {
  // Get phone from body or query parameter
  const phone = req.body.phone || req.query.phone;
  
  if (!phone) {
    return res.status(400).json({
      success: false,
      message: 'Phone number is required in body or query parameter'
    });
  }
  
  // Set phone in body for the sendOTP function
  req.body.phone = phone;
  sendOTP(req, res, next);
});

// Unified login endpoint - handles both POST and GET requests  
router.route('/login')
  .post(loginValidation, login)
  .get(loginQueryValidation, (req, res, next) => {
    // Convert GET request with query parameters to POST format
    req.body = { 
      phone: req.query.phone, 
      otp: req.query.otp 
    };
    login(req, res, next);
  });

// Admin login route
router.post('/admin/login', adminLoginValidation, adminLogin);

// Test upload route for debugging
router.post('/test-upload', handleUpload, (req, res) => {
  try {
    console.log('Test upload endpoint called');
    console.log('Request body:', req.body);
    console.log('Request file:', req.file);
    
    res.status(200).json({
      success: true,
      message: 'Upload test successful',
      data: {
        body: req.body,
        file: req.file ? {
          filename: req.file.filename,
          originalname: req.file.originalname,
          mimetype: req.file.mimetype,
          size: req.file.size
        } : null
      }
    });
  } catch (error) {
    console.error('Test upload error:', error);
    res.status(500).json({
      success: false,
      message: 'Test upload failed',
      error: error.message
    });
  }
});

// Debug upload route - accepts any file type
router.post('/debug-upload', (req, res) => {
  console.log('=== DEBUG UPLOAD ENDPOINT ===');
  console.log('Request method:', req.method);
  console.log('Request URL:', req.url);
  console.log('Request headers:', req.headers);
  console.log('Request body type:', typeof req.body);
  console.log('Request body keys:', Object.keys(req.body || {}));
  
  // Use multer without file filter for debugging
  const debugUpload = multer({
    storage: multer.diskStorage({
      destination: function (req, file, cb) {
        cb(null, 'uploads/');
      },
      filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, 'debug-' + file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
      }
    }),
    limits: {
      fileSize: 10 * 1024 * 1024 // 10MB limit for debugging
    }
  }).single('profileImage');
  
  debugUpload(req, res, function (err) {
    if (err) {
      console.log('Debug upload error:', err);
      return res.status(400).json({
        success: false,
        message: 'Debug upload failed: ' + err.message
      });
    }
    
    console.log('Debug upload successful');
    console.log('File received:', req.file);
    
    res.status(200).json({
      success: true,
      message: 'Debug upload successful',
      data: {
        body: req.body,
        file: req.file ? {
          filename: req.file.filename,
          originalname: req.file.originalname,
          mimetype: req.file.mimetype,
          size: req.file.size,
          path: req.file.path
        } : null
      }
    });
  });
});

// Protected routes
router.use(protect);
router.get('/me', getMe);
router.put('/updatedetails', handleUpload, updateDetails);
router.post('/logout', logout);
router.delete('/delete-account', deleteAccount);

// Admin routes
router.use(authorize('admin'));

// Dashboard
router.get('/admin/dashboard', getDashboardStats);

// User statistics
router.get('/admin/users/stats', getDashboardStats);

// General users endpoint (for admin)
router.get('/', getAllUsers);

// User management
router.route('/admin/users')
  .get(getAllUsers)
  .post(createUserValidation, createUser);

router.route('/admin/users/:id')
  .get(getUserById)
  .put(updateUser)
  .delete(deleteUser);

router.put('/admin/users/:id/role', changeUserRole);
router.put('/admin/users/:id/toggle-status', toggleUserStatus);

// Get user profile with API credentials
router.get('/profile', protect, getUserProfile);

// Regenerate API Key
router.post('/regenerate-api-key', protect, regenerateApiKey);

// Get user by User ID (public)
router.get('/user/:user_uni_id', getUserByUserId);

// Get user by API Key (public)
router.get('/api-key/:api_key', getUserByApiKey);

module.exports = router; 