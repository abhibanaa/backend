const User = require('../../models/User');
const ErrorResponse = require('../../utils/errorResponse');
const { validationResult } = require('express-validator');
const jwt = require('jsonwebtoken');
const asyncHandler = require('../../middlewares/async');

// @desc    Register user (for complete profile)
// @route   POST /api/auth/register
// @access  Public
const register = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        success: false, 
        errors: errors.array() 
      });
    }

    const { name, email, phone, dateOfBirth, timeOfBirth, placeOfBirth } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ 
      $or: [{ email }, { phone }] 
    });
    
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'User already exists with this email or phone number'
      });
    }

    // Create user
    const user = await User.create({
      name,
      email,
      phone,
      dateOfBirth,
      timeOfBirth,
      placeOfBirth,
      isProfileComplete: true
    });

    // Generate OTP for new user
    const otp = user.generateOTP();
    await user.save();

    res.status(201).json({
      success: true,
      message: 'User registered successfully. Please verify with OTP.',
      data: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        isProfileComplete: user.isProfileComplete
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Send OTP for login
// @route   POST /api/auth/send-otp
// @access  Public
const sendOTP = async (req, res, next) => {
  try {
    const { phone } = req.body;

    if (!phone) {
      return next(new ErrorResponse('Please provide a phone number', 400));
    }

    // Check for user
    let user = await User.findOne({ phone });

    // If user doesn't exist, create a new user (auto-registration)
    if (!user) {
      // Create a basic user with just phone number
      user = await User.create({
        phone: phone,
        isProfileComplete: false
      });
    }

    // Generate new OTP
    const otp = user.generateOTP();
    await user.save();

    res.status(200).json({
      success: true,
      message: 'OTP sent successfully',
      data: {
        phone: user.phone,
        otp: otp, // In production, this should be sent via SMS
        isNewUser: !user.createdAt || (new Date() - user.createdAt) < 60000, // Check if user was just created
        isProfileComplete: user.isProfileComplete
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Login user with OTP
// @route   POST /api/auth/login
// @access  Public
const login = async (req, res, next) => {
  try {
    const { phone, otp } = req.body;

    console.log('Login attempt:', { phone, otp });

    // Validate phone & OTP
    if (!phone || !otp) {
      return next(new ErrorResponse('Please provide phone number and OTP', 400));
    }

    // Check for user
    let user = await User.findOne({ phone });
    console.log('Found user:', user ? 'Yes' : 'No');

    // If user doesn't exist, create a new user (auto-registration)
    if (!user) {
      console.log('Creating new user for phone:', phone);
      // Create a basic user with just phone number
      user = await User.create({
        phone: phone,
        isProfileComplete: false
      });
      
      // Generate OTP for the new user
      user.generateOTP();
      await user.save();
      console.log('New user created with OTP:', user.otp.code);
    }

    // Generate User ID and API Key during login (for both new and existing users)
    let needsUpdate = false;
    
    if (!user.user_uni_id) {
      console.log('Generating User ID during login');
      user.user_uni_id = 'U' + Math.random().toString(36).substr(2, 7).toUpperCase();
      needsUpdate = true;
    }
    
          if (!user.api_key) {
        console.log('Generating API Key during login');
        const crypto = require('crypto');
        user.api_key = crypto.randomBytes(16).toString('hex');
        needsUpdate = true;
      }
      
      if (needsUpdate) {
        await user.save();
        console.log('Login: Generated User ID:', user.user_uni_id);
        console.log('Login: Generated API Key:', user.api_key);
      }

    console.log('User OTP code:', user.otp.code);
    console.log('User OTP expires:', user.otp.expiresAt);
    console.log('Current time:', new Date());

    // Check if OTP is expired and regenerate if needed
    if (user.otp.expiresAt < new Date()) {
      console.log('OTP expired, regenerating...');
      user.generateOTP();
      await user.save();
      console.log('New OTP generated:', user.otp.code);
    }

    // Verify OTP
    const isOTPValid = user.verifyOTP(otp);
    console.log('OTP validation result:', isOTPValid);

    if (!isOTPValid) {
      return next(new ErrorResponse('Invalid OTP. Please use: 333661', 401));
    }

    await user.save(); // Save the verified status

    sendTokenResponse(user, 200, res);
  } catch (error) {
    console.error('Login error:', error);
    next(error);
  }
};

// @desc    Admin login with username/password
// @route   POST /api/auth/admin/login
// @access  Public
const adminLogin = async (req, res, next) => {
  try {
    const { username, password } = req.body;

    console.log('Admin login attempt:', { username });

    // Validate username & password
    if (!username || !password) {
      return next(new ErrorResponse('Please provide username and password', 400));
    }

    // Check admin credentials
    if (username === 'admin123' && password === 'admin@123') {
      // Check if admin user exists in database
      let adminUser = await User.findOne({ role: 'admin' });
      
      if (!adminUser) {
        // Create admin user in database
        adminUser = await User.create({
          name: 'Admin User',
          email: 'admin@astrologyapp.com',
          phone: 'admin-phone',
          role: 'admin',
          isProfileComplete: true,
          isActive: true
        });
        console.log('Admin user created:', adminUser._id);
      }

      // Generate User ID and API Key during admin login
      let needsUpdate = false;
      
      if (!adminUser.user_uni_id) {
        console.log('Generating User ID during admin login');
        adminUser.user_uni_id = 'U' + Math.random().toString(36).substr(2, 7).toUpperCase();
        needsUpdate = true;
      }
      
      if (!adminUser.api_key) {
        console.log('Generating API Key during admin login');
        const crypto = require('crypto');
        adminUser.api_key = crypto.randomBytes(16).toString('hex');
        needsUpdate = true;
      }
      
      if (needsUpdate) {
        await adminUser.save();
        console.log('Admin Login: Generated User ID:', adminUser.user_uni_id);
        console.log('Admin Login: Generated API Key:', adminUser.api_key);
      }

      // Create admin token
      const token = jwt.sign({ id: adminUser._id }, process.env.JWT_SECRET || 'supersecurejwtkey123456789', {
        expiresIn: process.env.JWT_EXPIRE || '7d'
      });

      res.status(200).json({
        success: true,
        token,
        user: adminUser,
        apiCredentials: {
          userId: adminUser.userId,
          api_key: adminUser.api_key
        }
      });
    } else {
      return next(new ErrorResponse('Invalid admin credentials', 401));
    }
  } catch (error) {
    console.error('Admin login error:', error);
    next(error);
  }
};

// @desc    Get current logged in user
// @route   GET /api/auth/me
// @access  Private
const getMe = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id);
    res.status(200).json({
      success: true,
      data: user
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update user details (Complete profile)
// @route   PUT /api/auth/updatedetails
// @access  Private
const updateDetails = async (req, res, next) => {
  try {
    console.log('Profile update request received');
    console.log('Request body:', req.body);
    console.log('Request file:', req.file);
    console.log('Request headers:', req.headers['content-type']);

    const { name, email, dateOfBirth, timeOfBirth, placeOfBirth } = req.body;

    // Check if email is being updated and if it already exists
    if (email) {
      const existingUser = await User.findOne({ email, _id: { $ne: req.user.id } });
      if (existingUser) {
        return res.status(400).json({
          success: false,
          message: 'Email already exists'
        });
      }
    }

    const fieldsToUpdate = {
      name,
      email,
      dateOfBirth,
      timeOfBirth,
      placeOfBirth
    };

    // Add profile image if uploaded
    if (req.file) {
      console.log('Profile image uploaded:', req.file.filename);
      fieldsToUpdate.profileImage = `/uploads/${req.file.filename}`;
    } else {
      console.log('No profile image uploaded');
    }

    // Remove undefined fields
    Object.keys(fieldsToUpdate).forEach(key => 
      fieldsToUpdate[key] === undefined && delete fieldsToUpdate[key]
    );

    console.log('Fields to update:', fieldsToUpdate);

    const user = await User.findByIdAndUpdate(req.user.id, fieldsToUpdate, {
      new: true,
      runValidators: true
    });

    // Check if profile is now complete
    const isProfileComplete = user.checkProfileComplete();
    if (isProfileComplete !== user.isProfileComplete) {
      user.isProfileComplete = isProfileComplete;
      await user.save();
    }

    console.log('Profile update successful. Profile complete:', isProfileComplete);

    res.status(200).json({
      success: true,
      message: isProfileComplete ? 'Profile completed successfully!' : 'Profile updated successfully!',
      data: user
    });
  } catch (error) {
    console.error('Profile update error:', error);
    next(error);
  }
};

// @desc    Log user out / clear cookie
// @route   POST /api/auth/logout
// @access  Private
const logout = async (req, res, next) => {
  res.status(200).json({
    success: true,
    message: 'Logged out successfully'
  });
};

// @desc    Delete user account
// @route   DELETE /api/auth/delete-account
// @access  Private
const deleteAccount = async (req, res, next) => {
  try {
    console.log('Account deletion request for user:', req.user.id);
    
    const user = await User.findById(req.user.id);
    
    if (!user) {
      return next(new ErrorResponse('User not found', 404));
    }

    // Check if user is admin (prevent admin from deleting themselves)
    if (user.role === 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Admin accounts cannot be deleted through this endpoint'
      });
    }

    // Delete user's profile image if exists
    if (user.profileImage) {
      const fs = require('fs');
      const path = require('path');
      const imagePath = path.join(__dirname, '..', user.profileImage);
      
      try {
        if (fs.existsSync(imagePath)) {
          fs.unlinkSync(imagePath);
          console.log('Profile image deleted:', imagePath);
        }
      } catch (error) {
        console.log('Error deleting profile image:', error.message);
      }
    }

    // Delete the user
    await User.findByIdAndDelete(req.user.id);

    console.log('User account deleted successfully:', req.user.id);

    res.status(200).json({
      success: true,
      message: 'Account deleted successfully'
    });
  } catch (error) {
    console.error('Account deletion error:', error);
    next(error);
  }
};

// ========== ADMIN FUNCTIONS ==========

// @desc    Get all users (Admin only)
// @route   GET /api/auth/admin/users
// @access  Private/Admin
const getAllUsers = async (req, res, next) => {
  try {
    const users = await User.find().select('-otp');
    
    res.status(200).json({
      success: true,
      count: users.length,
      data: users
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get user by ID (Admin only)
// @route   GET /api/auth/admin/users/:id
// @access  Private/Admin
const getUserById = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id).select('-otp');
    
    if (!user) {
      return next(new ErrorResponse('User not found', 404));
    }

    res.status(200).json({
      success: true,
      data: user
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update user (Admin only)
// @route   PUT /api/auth/admin/users/:id
// @access  Private/Admin
const updateUser = async (req, res, next) => {
  try {
    // Handle empty date values
    const updateData = { ...req.body };
    
    // Convert empty string dates to null
    if (updateData.dateOfBirth === '') {
      updateData.dateOfBirth = null;
    }
    if (updateData.timeOfBirth === '') {
      updateData.timeOfBirth = null;
    }
    if (updateData.placeOfBirth === '') {
      updateData.placeOfBirth = null;
    }
    
    const user = await User.findByIdAndUpdate(req.params.id, updateData, {
      new: true,
      runValidators: true
    });

    if (!user) {
      return next(new ErrorResponse('User not found', 404));
    }

    res.status(200).json({
      success: true,
      data: user
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete user (Admin only)
// @route   DELETE /api/auth/admin/users/:id
// @access  Private/Admin
const deleteUser = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return next(new ErrorResponse('User not found', 404));
    }

    await User.findByIdAndDelete(req.params.id);

    res.status(200).json({
      success: true,
      message: 'User deleted successfully'
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get dashboard statistics (Admin only)
// @route   GET /api/auth/admin/dashboard
// @access  Private/Admin
const getDashboardStats = async (req, res, next) => {
  try {
    const totalUsers = await User.countDocuments();
    const activeUsers = await User.countDocuments({ isActive: true });
    const completeProfiles = await User.countDocuments({ isProfileComplete: true });
    const incompleteProfiles = await User.countDocuments({ isProfileComplete: false });
    
    // Get users registered in last 7 days
    const lastWeek = new Date();
    lastWeek.setDate(lastWeek.getDate() - 7);
    const newUsersThisWeek = await User.countDocuments({ 
      createdAt: { $gte: lastWeek } 
    });

    // Get users by role
    const adminUsers = await User.countDocuments({ role: 'admin' });
    const regularUsers = await User.countDocuments({ role: 'user' });

    res.status(200).json({
      success: true,
      data: {
        totalUsers,
        activeUsers,
        completeProfiles,
        incompleteProfiles,
        newUsersThisWeek,
        adminUsers,
        regularUsers,
        completionRate: totalUsers > 0 ? Math.round((completeProfiles / totalUsers) * 100) : 0
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Change user role (Admin only)
// @route   PUT /api/auth/admin/users/:id/role
// @access  Private/Admin
const changeUserRole = async (req, res, next) => {
  try {
    const { role } = req.body;

    if (!['user', 'admin'].includes(role)) {
      return next(new ErrorResponse('Invalid role. Must be user or admin', 400));
    }

    const user = await User.findByIdAndUpdate(
      req.params.id, 
      { role }, 
      { new: true, runValidators: true }
    );

    if (!user) {
      return next(new ErrorResponse('User not found', 404));
    }

    res.status(200).json({
      success: true,
      message: `User role changed to ${role}`,
      data: user
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Toggle user active status (Admin only)
// @route   PUT /api/auth/admin/users/:id/toggle-status
// @access  Private/Admin
const toggleUserStatus = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return next(new ErrorResponse('User not found', 404));
    }

    user.isActive = !user.isActive;
    await user.save();

    res.status(200).json({
      success: true,
      message: `User ${user.isActive ? 'activated' : 'deactivated'} successfully`,
      data: user
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Create new user (Admin only)
// @route   POST /api/auth/admin/users
// @access  Private/Admin
const createUser = async (req, res, next) => {
  try {
    const { 
      name, 
      email, 
      phone, 
      dateOfBirth, 
      timeOfBirth, 
      placeOfBirth, 
      role = 'user', 
      isActive = true 
    } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ 
      $or: [{ email }, { phone }] 
    });
    
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'User already exists with this email or phone number'
      });
    }

    // Create user data object
    const userData = {
      name,
      email,
      phone,
      dateOfBirth: dateOfBirth || null,
      timeOfBirth: timeOfBirth || null,
      placeOfBirth: placeOfBirth || null,
      role,
      isActive,
      isProfileComplete: true // Admin-created users are considered complete
    };

    // Create user
    const user = await User.create(userData);

    res.status(201).json({
      success: true,
      message: 'User created successfully',
      data: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        isActive: user.isActive,
        isProfileComplete: user.isProfileComplete,
        dateOfBirth: user.dateOfBirth,
        timeOfBirth: user.timeOfBirth,
        placeOfBirth: user.placeOfBirth
      }
    });
  } catch (error) {
    next(error);
  }
};

// Get token from model, create cookie and send response
const sendTokenResponse = (user, statusCode, res) => {
  // Create token
  const token = user.getSignedJwtToken();

  // Check if user needs to complete registration
  const needsRegistration = !user.isProfileComplete || !user.name || !user.email;

  res.status(statusCode).json({
    success: true,
    token,
    needsRegistration,
    user: {
      id: user._id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      isProfileComplete: user.isProfileComplete,
      role: user.role,
      dateOfBirth: user.dateOfBirth,
      timeOfBirth: user.timeOfBirth,
      placeOfBirth: user.placeOfBirth,
      profileImage: user.profileImage
    },
    apiCredentials: {
      user_uni_id: user.user_uni_id,
      api_key: user.api_key
    }
  });
}; 

// Get user profile with API credentials
const getUserProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user.id);
  
  if (!user) {
    return res.status(404).json({
      success: false,
      message: 'User not found'
    });
  }

  res.status(200).json({
    success: true,
    data: user.getUserInfo(),
    apiCredentials: user.getApiCredentials()
  });
});

// Regenerate API Key
const regenerateApiKey = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user.id);
  
  if (!user) {
    return res.status(404).json({
      success: false,
      message: 'User not found'
    });
  }

  const newApiKey = user.regenerateApiKey();
  await user.save();

  res.status(200).json({
    success: true,
    message: 'API key regenerated successfully',
    data: {
      user_uni_id: user.user_uni_id,
      api_key: newApiKey
    }
  });
});

// Get user by User ID (public endpoint)
const getUserByUserId = asyncHandler(async (req, res) => {
  const { user_uni_id } = req.params;
  
  const user = await User.findOne({ user_uni_id, isActive: true });
  
  if (!user) {
    return res.status(404).json({
      success: false,
      message: 'User not found'
    });
  }

  res.status(200).json({
    success: true,
    data: user.getUserInfo()
  });
});

// Get user by API Key (for external integrations)
const getUserByApiKey = asyncHandler(async (req, res) => {
  const { api_key } = req.params;
  
  const user = await User.findOne({ api_key: api_key, isActive: true });
  
  if (!user) {
    return res.status(404).json({
      success: false,
      message: 'Invalid API key'
    });
  }

  res.status(200).json({
    success: true,
    data: user.getUserInfo()
  });
});

module.exports = {
  register,
  login,
  logout,
  getMe,
  updateDetails,
  deleteAccount,
  sendOTP,
  adminLogin,
  getDashboardStats,
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
  changeUserRole,
  toggleUserStatus,
  createUser,
  getUserProfile,
  regenerateApiKey,
  getUserByUserId,
  getUserByApiKey
}; 