const express = require('express');
const {
  getBlogs,
  getBlog,
  createBlog,
  updateBlog,
  deleteBlog,
  addComment,
  likeBlog,
  getBlogsByCategory,
  getFeaturedBlogs,
  searchBlogs
} = require('./blogController');

const { protect, authorize } = require('../../middlewares/authMiddleware');

const router = express.Router();

// Public routes
router.route('/')
  .get(getBlogs);

router.route('/featured')
  .get(getFeaturedBlogs);

router.route('/category/:category')
  .get(getBlogsByCategory);

router.route('/search')
  .get(searchBlogs);

router.route('/:slug')
  .get(getBlog);

// Protected routes
router.use(protect);

router.route('/:id/comments')
  .post(addComment);

router.route('/:id/like')
  .post(likeBlog);

// Admin only routes
router.use(authorize('admin'));

router.route('/')
  .post(createBlog);

router.route('/:id')
  .put(updateBlog)
  .delete(deleteBlog);

module.exports = router; 