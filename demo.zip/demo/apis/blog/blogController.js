const Blog = require('../../models/Blog');
const ErrorResponse = require('../../utils/errorResponse');

// @desc    Get all published blogs
// @route   GET /api/blogs
// @access  Public
exports.getBlogs = async (req, res, next) => {
  try {
    const { page = 1, limit = 10, category, tag, search, featured } = req.query;
    
    let query = { status: 'published', isPublic: true };
    
    if (category) {
      query.category = category;
    }
    
    if (tag) {
      query.tags = { $in: [tag] };
    }
    
    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { excerpt: { $regex: search, $options: 'i' } },
        { content: { $regex: search, $options: 'i' } }
      ];
    }
    
    if (featured === 'true') {
      query.isFeatured = true;
    }

    const blogs = await Blog.find(query)
      .populate('author', 'name')
      .sort('-publishedAt')
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Blog.countDocuments(query);

    res.status(200).json({
      success: true,
      count: blogs.length,
      total,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      data: blogs
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single blog by slug
// @route   GET /api/blogs/:slug
// @access  Public
exports.getBlog = async (req, res, next) => {
  try {
    const blog = await Blog.findOne({ 
      slug: req.params.slug, 
      status: 'published',
      isPublic: true 
    }).populate('author', 'name');

    if (!blog) {
      return next(new ErrorResponse('Blog not found', 404));
    }

    // Increment views
    blog.views += 1;
    await blog.save();

    res.status(200).json({
      success: true,
      data: blog
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Create new blog (Admin only)
// @route   POST /api/blogs
// @access  Private/Admin
exports.createBlog = async (req, res, next) => {
  try {
    req.body.author = req.user.id;
    
    const blog = await Blog.create(req.body);

    res.status(201).json({
      success: true,
      data: blog
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update blog (Admin only)
// @route   PUT /api/blogs/:id
// @access  Private/Admin
exports.updateBlog = async (req, res, next) => {
  try {
    let blog = await Blog.findById(req.params.id);

    if (!blog) {
      return next(new ErrorResponse('Blog not found', 404));
    }

    blog = await Blog.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    res.status(200).json({
      success: true,
      data: blog
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete blog (Admin only)
// @route   DELETE /api/blogs/:id
// @access  Private/Admin
exports.deleteBlog = async (req, res, next) => {
  try {
    const blog = await Blog.findById(req.params.id);

    if (!blog) {
      return next(new ErrorResponse('Blog not found', 404));
    }

    await blog.remove();

    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Add comment to blog
// @route   POST /api/blogs/:id/comments
// @access  Private
exports.addComment = async (req, res, next) => {
  try {
    const blog = await Blog.findById(req.params.id);

    if (!blog) {
      return next(new ErrorResponse('Blog not found', 404));
    }

    const comment = {
      user: req.user.id,
      content: req.body.content,
      isApproved: req.user.role === 'admin' // Auto-approve admin comments
    };

    blog.comments.push(comment);
    await blog.save();

    // Populate user info for the new comment
    const populatedBlog = await Blog.findById(req.params.id)
      .populate('comments.user', 'name');

    const newComment = populatedBlog.comments[populatedBlog.comments.length - 1];

    res.status(201).json({
      success: true,
      data: newComment
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Like blog
// @route   POST /api/blogs/:id/like
// @access  Private
exports.likeBlog = async (req, res, next) => {
  try {
    const blog = await Blog.findById(req.params.id);

    if (!blog) {
      return next(new ErrorResponse('Blog not found', 404));
    }

    blog.likes += 1;
    await blog.save();

    res.status(200).json({
      success: true,
      data: { likes: blog.likes }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get blogs by category
// @route   GET /api/blogs/category/:category
// @access  Public
exports.getBlogsByCategory = async (req, res, next) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    
    const blogs = await Blog.find({
      category: req.params.category,
      status: 'published',
      isPublic: true
    })
    .populate('author', 'name')
    .sort('-publishedAt')
    .limit(limit * 1)
    .skip((page - 1) * limit);

    const total = await Blog.countDocuments({
      category: req.params.category,
      status: 'published',
      isPublic: true
    });

    res.status(200).json({
      success: true,
      count: blogs.length,
      total,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      data: blogs
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get featured blogs
// @route   GET /api/blogs/featured
// @access  Public
exports.getFeaturedBlogs = async (req, res, next) => {
  try {
    const { limit = 5 } = req.query;
    
    const blogs = await Blog.find({
      isFeatured: true,
      status: 'published',
      isPublic: true
    })
    .populate('author', 'name')
    .sort('-publishedAt')
    .limit(parseInt(limit));

    res.status(200).json({
      success: true,
      count: blogs.length,
      data: blogs
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Search blogs
// @route   GET /api/blogs/search
// @access  Public
exports.searchBlogs = async (req, res, next) => {
  try {
    const { q, page = 1, limit = 10 } = req.query;
    
    if (!q) {
      return next(new ErrorResponse('Search query is required', 400));
    }

    const blogs = await Blog.find({
      $or: [
        { title: { $regex: q, $options: 'i' } },
        { excerpt: { $regex: q, $options: 'i' } },
        { content: { $regex: q, $options: 'i' } },
        { tags: { $in: [new RegExp(q, 'i')] } }
      ],
      status: 'published',
      isPublic: true
    })
    .populate('author', 'name')
    .sort('-publishedAt')
    .limit(limit * 1)
    .skip((page - 1) * limit);

    const total = await Blog.countDocuments({
      $or: [
        { title: { $regex: q, $options: 'i' } },
        { excerpt: { $regex: q, $options: 'i' } },
        { content: { $regex: q, $options: 'i' } },
        { tags: { $in: [new RegExp(q, 'i')] } }
      ],
      status: 'published',
      isPublic: true
    });

    res.status(200).json({
      success: true,
      count: blogs.length,
      total,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      query: q,
      data: blogs
    });
  } catch (error) {
    next(error);
  }
}; 