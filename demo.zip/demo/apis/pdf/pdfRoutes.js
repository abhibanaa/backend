const express = require('express');
const {
  getAllPDFs,
  getPDFById,
  downloadPDF,
  createPDF,
  updatePDF,
  deletePDF,
  getPDFStats
} = require('./pdfController');
const { protect, authorize } = require('../../middlewares/authMiddleware');

const router = express.Router();

// Public routes
router.get('/', getAllPDFs);

// Admin routes (require admin privileges) - must come before parameterized routes
router.get('/stats', protect, authorize('admin'), getPDFStats);
router.post('/', protect, authorize('admin'), createPDF);
router.put('/:id', protect, authorize('admin'), updatePDF);
router.delete('/:id', protect, authorize('admin'), deletePDF);

// Parameterized routes (must come after specific routes)
router.get('/:id', getPDFById);
router.get('/:id/download', downloadPDF);

module.exports = router; 