const asyncHandler = require('../../middlewares/async');
const ErrorResponse = require('../../utils/errorResponse');
const PDF = require('../../models/PDF');
const User = require('../../models/User');

// @desc    Get all PDFs (Public)
// @route   GET /api/pdf
// @access  Public
exports.getAllPDFs = asyncHandler(async (req, res, next) => {
  try {
    const { 
      category, 
      language, 
      isFeatured, 
      search, 
      page = 1, 
      limit = 10,
      sortBy = 'createdAt',
      sortOrder = 'desc'
    } = req.query;

    // Build query
    const query = { isActive: true };
    
    if (category) query.category = category;
    if (language) query.pdfLanguage = language; // Use new field name
    if (isFeatured === 'true') query.isFeatured = true;
    
    // Search functionality
    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { tags: { $in: [new RegExp(search, 'i')] } }
      ];
    }

    // Pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);
    
    // Sorting
    const sortOptions = {};
    sortOptions[sortBy] = sortOrder === 'desc' ? -1 : 1;

    const pdfs = await PDF.find(query)
      .sort(sortOptions)
      .skip(skip)
      .limit(parseInt(limit))
      .populate('addedBy', 'name email')
      .exec();

    const total = await PDF.countDocuments(query);
    const totalPages = Math.ceil(total / parseInt(limit));

    res.status(200).json({
      success: true,
      message: 'PDFs retrieved successfully',
      data: {
        pdfs: pdfs.map(pdf => pdf.getFormattedData()),
        pagination: {
          currentPage: parseInt(page),
          totalPages,
          totalPDFs: total,
          pdfsPerPage: parseInt(limit),
          hasNextPage: parseInt(page) < totalPages,
          hasPrevPage: parseInt(page) > 1
        },
        filters: {
          category,
          language,
          isFeatured,
          search
        }
      }
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Get PDF by ID (Public)
// @route   GET /api/pdf/:id
// @access  Public
exports.getPDFById = asyncHandler(async (req, res, next) => {
  try {
    const { id } = req.params;

    let pdf;
    try {
      pdf = await PDF.findById(id).populate('addedBy', 'name email');
    } catch (error) {
      if (error.name === 'CastError') {
        return next(new ErrorResponse('Invalid PDF ID format. Please provide a valid ID.', 400));
      }
      throw error;
    }

    if (!pdf) {
      return next(new ErrorResponse('PDF not found', 404));
    }

    if (!pdf.isActive) {
      return next(new ErrorResponse('PDF is not available', 404));
    }

    // Increment view count
    await pdf.incrementViewCount();

    res.status(200).json({
      success: true,
      message: 'PDF details retrieved successfully',
      data: pdf.getFormattedData()
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Download PDF (Public)
// @route   GET /api/pdf/:id/download
// @access  Public
exports.downloadPDF = asyncHandler(async (req, res, next) => {
  try {
    const { id } = req.params;

    let pdf;
    try {
      pdf = await PDF.findById(id);
    } catch (error) {
      if (error.name === 'CastError') {
        return next(new ErrorResponse('Invalid PDF ID format. Please provide a valid ID.', 400));
      }
      throw error;
    }

    if (!pdf) {
      return next(new ErrorResponse('PDF not found', 404));
    }

    if (!pdf.isActive) {
      return next(new ErrorResponse('PDF is not available for download', 404));
    }

    // Increment download count
    await pdf.incrementDownloadCount();

    // Redirect to PDF URL
    res.status(200).json({
      success: true,
      message: 'PDF download initiated',
      data: {
        downloadUrl: pdf.pdfUrl,
        fileName: pdf.fileName,
        title: pdf.title,
        downloadCount: pdf.downloadCount + 1
      }
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Create PDF (Admin only)
// @route   POST /api/pdf
// @access  Private (Admin)
exports.createPDF = asyncHandler(async (req, res, next) => {
  try {
    const { 
      title, 
      description, 
      category, 
      pdfUrl, 
      fileName, 
      fileSize, 
      language, 
      isFeatured, 
      tags, 
      thumbnailUrl 
    } = req.body;

    // Validate required fields
    if (!title || !category || !pdfUrl || !fileName) {
      return next(new ErrorResponse('Title, category, PDF URL, and file name are required', 400));
    }

    // Validate language
    const validLanguages = ['hi', 'eng', 'both'];
    const selectedLanguage = language || 'eng';
    
    if (!validLanguages.includes(selectedLanguage)) {
      return next(new ErrorResponse(`Invalid language. Must be one of: ${validLanguages.join(', ')}`, 400));
    }

    // Create PDF data
    const pdfData = {
      title,
      description,
      category,
      pdfUrl,
      fileName,
      fileSize: fileSize || 0,
      pdfLanguage: selectedLanguage, // Use new field name
      isFeatured: isFeatured || false,
      tags: tags || [],
      thumbnailUrl,
      addedBy: req.user._id,
      lastUpdatedBy: req.user._id
    };

    const pdf = await PDF.create(pdfData);

    res.status(201).json({
      success: true,
      message: 'PDF created successfully',
      data: pdf.getFormattedData()
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Update PDF (Admin only)
// @route   PUT /api/pdf/:id
// @access  Private (Admin)
exports.updatePDF = asyncHandler(async (req, res, next) => {
  try {
    const { id } = req.params;
    const updateData = req.body;

    // Find PDF
    let pdf;
    try {
      pdf = await PDF.findById(id);
    } catch (error) {
      if (error.name === 'CastError') {
        return next(new ErrorResponse('Invalid PDF ID format. Please provide a valid ID.', 400));
      }
      throw error;
    }

    if (!pdf) {
      return next(new ErrorResponse('PDF not found', 404));
    }

    // Validate language if it's being updated
    if (updateData.language) {
      const validLanguages = ['hi', 'eng', 'both'];
      if (!validLanguages.includes(updateData.language)) {
        return next(new ErrorResponse(`Invalid language. Must be one of: ${validLanguages.join(', ')}`, 400));
      }
      // Convert language to pdfLanguage for database
      updateData.pdfLanguage = updateData.language;
      delete updateData.language;
    }

    // Update lastUpdatedBy
    updateData.lastUpdatedBy = req.user._id;

    // Update PDF
    const updatedPDF = await PDF.findByIdAndUpdate(
      id,
      updateData,
      { new: true, runValidators: true }
    ).populate('addedBy', 'name email');

    res.status(200).json({
      success: true,
      message: 'PDF updated successfully',
      data: updatedPDF.getFormattedData()
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Delete PDF (Admin only)
// @route   DELETE /api/pdf/:id
// @access  Private (Admin)
exports.deletePDF = asyncHandler(async (req, res, next) => {
  try {
    const { id } = req.params;

    // Find PDF
    let pdf;
    try {
      pdf = await PDF.findById(id);
    } catch (error) {
      if (error.name === 'CastError') {
        return next(new ErrorResponse('Invalid PDF ID format. Please provide a valid ID.', 400));
      }
      throw error;
    }

    if (!pdf) {
      return next(new ErrorResponse('PDF not found', 404));
    }

    // Delete PDF
    await pdf.deleteOne();

    res.status(200).json({
      success: true,
      message: 'PDF deleted successfully'
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Get PDF statistics (Admin only)
// @route   GET /api/pdf/stats
// @access  Private (Admin)
exports.getPDFStats = asyncHandler(async (req, res, next) => {
  try {
    // Get statistics
    const totalPDFs = await PDF.countDocuments();
    const activePDFs = await PDF.countDocuments({ isActive: true });
    const featuredPDFs = await PDF.countDocuments({ isFeatured: true, isActive: true });
    const totalDownloads = await PDF.aggregate([
      { $group: { _id: null, total: { $sum: '$downloadCount' } } }
    ]);
    const totalViews = await PDF.aggregate([
      { $group: { _id: null, total: { $sum: '$viewCount' } } }
    ]);

    // Get category breakdown
    const categoryStats = await PDF.aggregate([
      { $group: { _id: '$category', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);

    // Get language breakdown
    const languageStats = await PDF.aggregate([
      { $group: { _id: '$pdfLanguage', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);

    // Get top downloaded PDFs
    const topDownloads = await PDF.find({ isActive: true })
      .sort({ downloadCount: -1 })
      .limit(5)
      .select('title downloadCount category')
      .exec();

    res.status(200).json({
      success: true,
      message: 'PDF statistics retrieved successfully',
      data: {
        overview: {
          totalPDFs,
          activePDFs,
          featuredPDFs,
          totalDownloads: totalDownloads[0]?.total || 0,
          totalViews: totalViews[0]?.total || 0
        },
        categoryBreakdown: categoryStats,
        languageBreakdown: languageStats,
        topDownloads: topDownloads
      }
    });
  } catch (error) {
    next(error);
  }
}); 