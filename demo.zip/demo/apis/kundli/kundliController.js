const asyncHandler = require('../../middlewares/async');
const ErrorResponse = require('../../utils/errorResponse');
const Kundli = require('../../models/Kundli');
const User = require('../../models/User');

// @desc    Save Kundli Data
// @route   POST /api/kundli/saveKundliData
// @access  Public (with userId and api_key)
exports.saveKundliData = asyncHandler(async (req, res, next) => {
  try {
    const {
      user_uni_id,
      api_key,
      name,
      dateOfBirth,
      timeOfBirth,
      placeOfBirth,
      gender,
      kundliType = 'birth',
      isActive = true,
      notes = ''
    } = req.body;

    // Validate required fields
    if (!user_uni_id || !api_key || !name || !dateOfBirth || !timeOfBirth || !placeOfBirth) {
      return next(new ErrorResponse('Please provide user_uni_id, api_key, name, dateOfBirth, timeOfBirth, and placeOfBirth', 400));
    }

    // Verify user
    const user = await User.findOne({ user_uni_id: user_uni_id, api_key, isActive: true });
    if (!user) {
      return next(new ErrorResponse('Invalid user_uni_id or api_key', 401));
    }

    // Create kundli data
    const kundliData = {
      user: user._id,
      name,
      dateOfBirth: new Date(dateOfBirth),
      timeOfBirth,
      placeOfBirth,
      gender: gender || 'Other',
      kundliType,
      isActive,
      notes
    };

    const kundli = await Kundli.create(kundliData);

    res.status(201).json({
      success: true,
      message: 'Kundli data saved successfully',
      data: kundli.getFormattedData()
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Get User Kundli Requests
// @route   GET /api/kundli/userKundaliRequest
// @access  Public (with userId and api_key)
exports.userKundaliRequest = asyncHandler(async (req, res, next) => {
  try {
    const { user_uni_id, api_key, kundliType, isActive } = req.query;

    // Validate required fields
    if (!user_uni_id || !api_key) {
      return next(new ErrorResponse('Please provide user_uni_id and api_key', 400));
    }

    // Verify user
    const user = await User.findOne({ user_uni_id: user_uni_id, api_key, isActive: true });
    if (!user) {
      return next(new ErrorResponse('Invalid user_uni_id or api_key', 401));
    }

    // Build query
    const query = { user: user._id };
    if (kundliType) query.kundliType = kundliType;
    if (isActive !== undefined) query.isActive = isActive === 'true';

    // Get kundlis with pagination
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    const kundlis = await Kundli.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .exec();

    const total = await Kundli.countDocuments(query);
    const totalPages = Math.ceil(total / limit);

    res.status(200).json({
      success: true,
      count: kundlis.length,
      total,
      totalPages,
      currentPage: page,
      data: kundlis.map(kundli => kundli.getFormattedData())
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Get Kundli by ID
// @route   GET /api/kundli/:id
// @access  Public (with user_uni_id and api_key)
exports.getKundliById = asyncHandler(async (req, res, next) => {
  try {
    const { user_uni_id, api_key } = req.query;
    const { id } = req.params;

    // Validate required fields
    if (!user_uni_id || !api_key) {
      return next(new ErrorResponse('Please provide user_uni_id and api_key', 400));
    }

    // Verify user
    const user = await User.findOne({ user_uni_id: user_uni_id, api_key, isActive: true });
    if (!user) {
      return next(new ErrorResponse('Invalid user_uni_id or api_key', 401));
    }

    // Find kundli
    let kundli;
    try {
      kundli = await Kundli.findById(id);
    } catch (error) {
      if (error.name === 'CastError') {
        return next(new ErrorResponse('Invalid kundli ID format. Please provide a valid ID.', 400));
      }
      throw error;
    }

    if (!kundli) {
      return next(new ErrorResponse('Kundli not found', 404));
    }

    // Check if user owns this kundli
    if (kundli.user.toString() !== user._id.toString()) {
      return next(new ErrorResponse('Not authorized to access this kundli', 403));
    }

    res.status(200).json({
      success: true,
      data: kundli.getFormattedData()
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Edit Kundli Data
// @route   PUT /api/kundli/editKundliData/:id
// @access  Public (with user_uni_id and api_key)
exports.editKundliData = asyncHandler(async (req, res, next) => {
  try {
    const {
      user_uni_id,
      api_key,
      name,
      dateOfBirth,
      timeOfBirth,
      placeOfBirth,
      gender,
      kundliType,
      isActive,
      notes
    } = req.body;

    const { id } = req.params;

    // Validate required fields
    if (!user_uni_id || !api_key) {
      return next(new ErrorResponse('Please provide user_uni_id and api_key', 400));
    }

    // Verify user
    const user = await User.findOne({ user_uni_id: user_uni_id, api_key, isActive: true });
    if (!user) {
      return next(new ErrorResponse('Invalid user_uni_id or api_key', 401));
    }

    // Find kundli
    let kundli;
    try {
      kundli = await Kundli.findById(id);
    } catch (error) {
      if (error.name === 'CastError') {
        return next(new ErrorResponse('Invalid kundli ID format. Please provide a valid ID.', 400));
      }
      throw error;
    }

    if (!kundli) {
      return next(new ErrorResponse('Kundli not found', 404));
    }

    // Check if user owns this kundli
    if (kundli.user.toString() !== user._id.toString()) {
      return next(new ErrorResponse('Not authorized to update this kundli', 403));
    }

    // Update fields
    const updateData = {};
    if (name !== undefined) updateData.name = name;
    if (dateOfBirth !== undefined) updateData.dateOfBirth = new Date(dateOfBirth);
    if (timeOfBirth !== undefined) updateData.timeOfBirth = timeOfBirth;
    if (placeOfBirth !== undefined) updateData.placeOfBirth = placeOfBirth;
    if (gender !== undefined) updateData.gender = gender;
    if (kundliType !== undefined) updateData.kundliType = kundliType;
    if (isActive !== undefined) updateData.isActive = isActive;
    if (notes !== undefined) updateData.notes = notes;

    // Update kundli
    const updatedKundli = await Kundli.findByIdAndUpdate(
      id,
      updateData,
      { new: true, runValidators: true }
    );

    res.status(200).json({
      success: true,
      message: 'Kundli updated successfully',
      data: updatedKundli.getFormattedData()
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Delete Kundli
// @route   DELETE /api/kundli/deleteKundali/:id
// @access  Public (with user_uni_id and api_key)
exports.deleteKundali = asyncHandler(async (req, res, next) => {
  try {
    const { user_uni_id, api_key } = req.body;
    const { id } = req.params;

    // Validate required fields
    if (!user_uni_id || !api_key) {
      return next(new ErrorResponse('Please provide user_uni_id and api_key', 400));
    }

    // Verify user
    const user = await User.findOne({ user_uni_id: user_uni_id, api_key, isActive: true });
    if (!user) {
      return next(new ErrorResponse('Invalid user_uni_id or api_key', 401));
    }

    // Find kundli
    let kundli;
    try {
      kundli = await Kundli.findById(id);
    } catch (error) {
      if (error.name === 'CastError') {
        return next(new ErrorResponse('Invalid kundli ID format. Please provide a valid ID.', 400));
      }
      throw error;
    }

    if (!kundli) {
      return next(new ErrorResponse('Kundli not found', 404));
    }

    // Check if user owns this kundli
    if (kundli.user.toString() !== user._id.toString()) {
      return next(new ErrorResponse('Not authorized to delete this kundli', 403));
    }

    // Delete kundli
    await kundli.deleteOne();

    res.status(200).json({
      success: true,
      message: 'Kundli deleted successfully'
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Analyze Kundli
// @route   POST /api/kundli/:id/analyze
// @access  Public (with user_uni_id and api_key)
exports.analyzeKundli = asyncHandler(async (req, res, next) => {
  try {
    const { user_uni_id, api_key } = req.body;
    const { id } = req.params;

    // Validate required fields
    if (!user_uni_id || !api_key) {
      return next(new ErrorResponse('Please provide user_uni_id and api_key', 400));
    }

    // Verify user
    const user = await User.findOne({ user_uni_id: user_uni_id, api_key, isActive: true });
    if (!user) {
      return next(new ErrorResponse('Invalid user_uni_id or api_key', 401));
    }

    // Find kundli
    let kundli;
    try {
      kundli = await Kundli.findById(id);
    } catch (error) {
      if (error.name === 'CastError') {
        return next(new ErrorResponse('Invalid kundli ID format. Please provide a valid ID.', 400));
      }
      throw error;
    }

    if (!kundli) {
      return next(new ErrorResponse('Kundli not found', 404));
    }

    // Check if user owns this kundli
    if (kundli.user.toString() !== user._id.toString()) {
      return next(new ErrorResponse('Not authorized to analyze this kundli', 403));
    }

    // Perform kundli analysis (placeholder)
    const analysis = {
      rashi: 'Aries',
      nakshatra: 'Ashwini',
      ascendant: 'Aries',
      moonSign: 'Aries',
      sunSign: 'Aries',
      detailedAnalysis: {
        personality: 'Dynamic and energetic personality',
        career: 'Suitable for leadership roles',
        health: 'Generally good health',
        relationships: 'Passionate and loyal',
        compatibility: 'Best with Leo and Sagittarius'
      },
      planetaryPositions: {
        sun: 'Aries',
        moon: 'Aries',
        mars: 'Aries',
        mercury: 'Pisces',
        jupiter: 'Taurus',
        venus: 'Pisces',
        saturn: 'Capricorn',
        rahu: 'Cancer',
        ketu: 'Capricorn'
      },
      dashaPeriods: {
        current: 'Mars Dasha',
        next: 'Rahu Dasha',
        startDate: new Date().toISOString(),
        endDate: new Date(Date.now() + 7 * 365 * 24 * 60 * 60 * 1000).toISOString()
      }
    };

    // Update kundli with analysis
    kundli.analysis = analysis;
    await kundli.save();

    res.status(200).json({
      success: true,
      message: 'Kundli analysis completed successfully',
      data: {
        kundli: kundli.getFormattedData(),
        analysis: analysis
      }
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Get Kundlis by Zodiac Sign (Admin)
// @route   GET /api/kundli/zodiac/:sign
// @access  Private/Admin
exports.getKundlisByZodiac = asyncHandler(async (req, res, next) => {
  try {
    const { sign } = req.params;
    const { page = 1, limit = 10 } = req.query;

    const validSigns = ['Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo', 'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces'];
    
    if (!validSigns.includes(sign)) {
      return next(new ErrorResponse('Invalid zodiac sign', 400));
    }

    const query = {
      $or: [
        { sunSign: sign },
        { moonSign: sign },
        { ascendant: sign }
      ]
    };

    const kundlis = await Kundli.find(query)
      .populate('user', 'name email phone')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .exec();

    const total = await Kundli.countDocuments(query);

    res.status(200).json({
      success: true,
      count: kundlis.length,
      total,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      zodiacSign: sign,
      data: kundlis.map(kundli => ({
        ...kundli.getFormattedData(),
        user: kundli.user
      }))
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Get All Kundlis (Admin)
// @route   GET /api/kundli/admin/all
// @access  Private/Admin
exports.getAllKundlis = asyncHandler(async (req, res, next) => {
  try {
    const { page = 1, limit = 10, kundliType, sunSign, isActive } = req.query;
    
    const query = {};
    
    if (kundliType) query.kundliType = kundliType;
    if (sunSign) query.sunSign = sunSign;
    if (isActive !== undefined) query.isActive = isActive === 'true';

    const kundlis = await Kundli.find(query)
      .populate('user', 'name email phone userId')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .exec();

    const total = await Kundli.countDocuments(query);

    res.status(200).json({
      success: true,
      count: kundlis.length,
      total,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      data: kundlis.map(kundli => ({
        ...kundli.getFormattedData(),
        user: kundli.user
      }))
    });
  } catch (error) {
    next(error);
  }
});

 