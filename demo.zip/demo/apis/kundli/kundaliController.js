const Kundali = require('../../models/Kundali');
const ErrorResponse = require('../../utils/errorResponse');

// @desc    Create new kundali
// @route   POST /api/kundali
// @access  Private
exports.createKundali = async (req, res, next) => {
  try {
    // Add user to req.body
    req.body.user = req.user.id;

    const kundali = await Kundali.create(req.body);

    res.status(201).json({
      success: true,
      data: kundali
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all kundalis for logged in user
// @route   GET /api/kundali
// @access  Private
exports.getKundalis = async (req, res, next) => {
  try {
    let query;

    // Copy req.query
    const reqQuery = { ...req.query };

    // Fields to exclude
    const removeFields = ['select', 'sort', 'page', 'limit'];

    // Loop over removeFields and delete them from reqQuery
    removeFields.forEach(param => delete reqQuery[param]);

    // Create query string
    let queryStr = JSON.stringify(reqQuery);

    // Create operators ($gt, $gte, etc)
    queryStr = queryStr.replace(/\b(gt|gte|lt|lte|in)\b/g, match => `$${match}`);

    // Finding resource
    query = Kundali.find(JSON.parse(queryStr)).populate('user', 'name email');

    // Select Fields
    if (req.query.select) {
      const fields = req.query.select.split(',').join(' ');
      query = query.select(fields);
    }

    // Sort
    if (req.query.sort) {
      const sortBy = req.query.sort.split(',').join(' ');
      query = query.sort(sortBy);
    } else {
      query = query.sort('-createdAt');
    }

    // Pagination
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 25;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const total = await Kundali.countDocuments();

    query = query.skip(startIndex).limit(limit);

    // Executing query
    const kundalis = await query;

    // Pagination result
    const pagination = {};

    if (endIndex < total) {
      pagination.next = {
        page: page + 1,
        limit
      };
    }

    if (startIndex > 0) {
      pagination.prev = {
        page: page - 1,
        limit
      };
    }

    res.status(200).json({
      success: true,
      count: kundalis.length,
      pagination,
      data: kundalis
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single kundali
// @route   GET /api/kundali/:id
// @access  Private
exports.getKundali = async (req, res, next) => {
  try {
    const kundali = await Kundali.findById(req.params.id).populate('user', 'name email');

    if (!kundali) {
      return next(new ErrorResponse(`Kundali not found with id of ${req.params.id}`, 404));
    }

    // Make sure user owns kundali or is admin
    if (kundali.user._id.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new ErrorResponse(`User ${req.user.id} is not authorized to access this kundali`, 401));
    }

    res.status(200).json({
      success: true,
      data: kundali
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update kundali
// @route   PUT /api/kundali/:id
// @access  Private
exports.updateKundali = async (req, res, next) => {
  try {
    let kundali = await Kundali.findById(req.params.id);

    if (!kundali) {
      return next(new ErrorResponse(`Kundali not found with id of ${req.params.id}`, 404));
    }

    // Make sure user owns kundali or is admin
    if (kundali.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new ErrorResponse(`User ${req.user.id} is not authorized to update this kundali`, 401));
    }

    kundali = await Kundali.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    res.status(200).json({
      success: true,
      data: kundali
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete kundali
// @route   DELETE /api/kundali/:id
// @access  Private
exports.deleteKundali = async (req, res, next) => {
  try {
    const kundali = await Kundali.findById(req.params.id);

    if (!kundali) {
      return next(new ErrorResponse(`Kundali not found with id of ${req.params.id}`, 404));
    }

    // Make sure user owns kundali or is admin
    if (kundali.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new ErrorResponse(`User ${req.user.id} is not authorized to delete this kundali`, 401));
    }

    await kundali.remove();

    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get kundali by zodiac sign
// @route   GET /api/kundali/zodiac/:sign
// @access  Public
exports.getKundaliByZodiac = async (req, res, next) => {
  try {
    const { sign } = req.params;
    const { limit = 10 } = req.query;

    const kundalis = await Kundali.find({ 
      sunSign: sign,
      isPublic: true 
    })
    .populate('user', 'name')
    .limit(parseInt(limit))
    .sort('-createdAt');

    res.status(200).json({
      success: true,
      count: kundalis.length,
      data: kundalis
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Generate kundali analysis
// @route   POST /api/kundali/:id/analyze
// @access  Private
exports.analyzeKundali = async (req, res, next) => {
  try {
    const kundali = await Kundali.findById(req.params.id);

    if (!kundali) {
      return next(new ErrorResponse(`Kundali not found with id of ${req.params.id}`, 404));
    }

    // Make sure user owns kundali or is admin
    if (kundali.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new ErrorResponse(`User ${req.user.id} is not authorized to analyze this kundali`, 401));
    }

    // Here you would implement the actual astrological analysis
    // For now, we'll create a basic analysis
    const analysis = generateBasicAnalysis(kundali);

    kundali.analysis = analysis;
    await kundali.save();

    res.status(200).json({
      success: true,
      data: kundali
    });
  } catch (error) {
    next(error);
  }
};

// Helper function to generate basic analysis
const generateBasicAnalysis = (kundali) => {
  const analysis = {
    personality: `Based on your ${kundali.sunSign} sun sign, you are likely to be...`,
    strengths: ['Leadership qualities', 'Determination', 'Courage'],
    challenges: ['Impatience', 'Aggressiveness'],
    career: 'Suitable careers include leadership roles, entrepreneurship, and sports.',
    relationships: 'You are passionate and loyal in relationships.',
    health: 'Focus on physical exercise and stress management.',
    recommendations: [
      'Practice meditation for inner peace',
      'Channel your energy into productive activities',
      'Work on patience and listening skills'
    ]
  };

  return JSON.stringify(analysis);
}; 