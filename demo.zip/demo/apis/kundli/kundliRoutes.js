const express = require('express');
const {
  saveKundliData,
  userKundaliRequest,
  getKundliById,
  editKundliData,
  deleteKundali,
  analyzeKundli,
  getKundlisByZodiac,
  getAllKundlis
} = require('./kundliController');

const { protect, authorize } = require('../../middlewares/authMiddleware');

const router = express.Router();

// User routes (using userId and api_key for authentication)
router.post('/saveKundliData', saveKundliData);
router.get('/userKundaliRequest', userKundaliRequest);
router.get('/:id', getKundliById);
router.put('/editKundliData/:id', editKundliData);
router.delete('/deleteKundali/:id', deleteKundali);
router.post('/:id/analyze', analyzeKundli);

// Admin routes (still require JWT authentication)
router.get('/zodiac/:sign', protect, authorize('admin'), getKundlisByZodiac);
router.get('/admin/all', protect, authorize('admin'), getAllKundlis);

module.exports = router; 