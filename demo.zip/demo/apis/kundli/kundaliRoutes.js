const express = require('express');
const {
  createKundali,
  getKundalis,
  getKundali,
  updateKundali,
  deleteKundali,
  getKundaliByZodiac,
  analyzeKundali
} = require('./kundaliController');

const { protect, authorize } = require('../../middlewares/authMiddleware');

const router = express.Router();

// Apply authentication to all routes
router.use(protect);

// Routes
router.route('/')
  .post(createKundali)
  .get(getKundalis);

router.route('/:id')
  .get(getKundali)
  .put(updateKundali)
  .delete(deleteKundali);

router.route('/:id/analyze')
  .post(analyzeKundali);

router.route('/zodiac/:sign')
  .get(getKundaliByZodiac);

module.exports = router; 