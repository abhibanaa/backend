const express = require('express');
const {
  createNumerology,
  getNumerologies,
  getNumerology,
  updateNumerology,
  deleteNumerology
} = require('./numerologyController');

const { protect, authorize } = require('../../middlewares/authMiddleware');

const router = express.Router();

// Apply authentication to all routes
router.use(protect);

// Routes
router.route('/')
  .post(createNumerology)
  .get(getNumerologies);

router.route('/:id')
  .get(getNumerology)
  .put(updateNumerology)
  .delete(deleteNumerology);

module.exports = router; 