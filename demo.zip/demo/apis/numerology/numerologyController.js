const Numerology = require('../../models/Numerology');
const ErrorResponse = require('../../utils/errorResponse');

// @desc    Create new numerology report
// @route   POST /api/numerology
// @access  Private
exports.createNumerology = async (req, res, next) => {
  try {
    // Add user to req.body
    req.body.user = req.user.id;

    // Calculate core numbers
    const coreNumbers = calculateCoreNumbers(req.body.name, req.body.dateOfBirth);
    req.body = { ...req.body, ...coreNumbers };

    // Calculate name analysis
    const nameAnalysis = analyzeName(req.body.name);
    req.body.nameAnalysis = nameAnalysis;

    // Calculate birth date analysis
    const birthDateAnalysis = analyzeBirthDate(req.body.dateOfBirth);
    req.body.birthDateAnalysis = birthDateAnalysis;

    // Calculate personal year number
    const personalYearNumber = calculatePersonalYearNumber(req.body.dateOfBirth);
    req.body.personalYearNumber = personalYearNumber;

    // Generate lucky numbers and colors
    const luckyDetails = generateLuckyDetails(coreNumbers.lifePathNumber);
    req.body = { ...req.body, ...luckyDetails };

    // Generate detailed analysis
    const analysis = generateNumerologyAnalysis(coreNumbers);
    req.body.analysis = analysis;

    // Generate predictions
    const predictions = generatePredictions(coreNumbers, personalYearNumber);
    req.body.predictions = predictions;

    // Generate remedies and suggestions
    const remedies = generateRemedies(coreNumbers);
    req.body.remedies = remedies;

    const numerology = await Numerology.create(req.body);

    res.status(201).json({
      success: true,
      data: numerology
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all numerology reports for logged in user
// @route   GET /api/numerology
// @access  Private
exports.getNumerologies = async (req, res, next) => {
  try {
    let query;

    // Copy req.query
    const reqQuery = { ...req.query };

    // Fields to exclude
    const removeFields = ['select', 'sort', 'page', 'limit'];

    // Loop over removeFields and delete them from reqQuery
    removeFields.forEach(param => delete reqQuery[param]);

    // Create query string
    let queryStr = JSON.stringify(reqQuery);

    // Create operators ($gt, $gte, etc)
    queryStr = queryStr.replace(/\b(gt|gte|lt|lte|in)\b/g, match => `$${match}`);

    // Finding resource
    query = Numerology.find(JSON.parse(queryStr)).populate('user', 'name email');

    // Select Fields
    if (req.query.select) {
      const fields = req.query.select.split(',').join(' ');
      query = query.select(fields);
    }

    // Sort
    if (req.query.sort) {
      const sortBy = req.query.sort.split(',').join(' ');
      query = query.sort(sortBy);
    } else {
      query = query.sort('-createdAt');
    }

    // Pagination
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 25;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const total = await Numerology.countDocuments();

    query = query.skip(startIndex).limit(limit);

    // Executing query
    const numerologies = await query;

    // Pagination result
    const pagination = {};

    if (endIndex < total) {
      pagination.next = {
        page: page + 1,
        limit
      };
    }

    if (startIndex > 0) {
      pagination.prev = {
        page: page - 1,
        limit
      };
    }

    res.status(200).json({
      success: true,
      count: numerologies.length,
      pagination,
      data: numerologies
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single numerology report
// @route   GET /api/numerology/:id
// @access  Private
exports.getNumerology = async (req, res, next) => {
  try {
    const numerology = await Numerology.findById(req.params.id).populate('user', 'name email');

    if (!numerology) {
      return next(new ErrorResponse(`Numerology report not found with id of ${req.params.id}`, 404));
    }

    // Make sure user owns numerology or is admin
    if (numerology.user._id.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new ErrorResponse(`User ${req.user.id} is not authorized to access this numerology report`, 401));
    }

    res.status(200).json({
      success: true,
      data: numerology
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update numerology report
// @route   PUT /api/numerology/:id
// @access  Private
exports.updateNumerology = async (req, res, next) => {
  try {
    let numerology = await Numerology.findById(req.params.id);

    if (!numerology) {
      return next(new ErrorResponse(`Numerology report not found with id of ${req.params.id}`, 404));
    }

    // Make sure user owns numerology or is admin
    if (numerology.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new ErrorResponse(`User ${req.user.id} is not authorized to update this numerology report`, 401));
    }

    numerology = await Numerology.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    res.status(200).json({
      success: true,
      data: numerology
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete numerology report
// @route   DELETE /api/numerology/:id
// @access  Private
exports.deleteNumerology = async (req, res, next) => {
  try {
    const numerology = await Numerology.findById(req.params.id);

    if (!numerology) {
      return next(new ErrorResponse(`Numerology report not found with id of ${req.params.id}`, 404));
    }

    // Make sure user owns numerology or is admin
    if (numerology.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new ErrorResponse(`User ${req.user.id} is not authorized to delete this numerology report`, 401));
    }

    await numerology.remove();

    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get numerology by life path number
// @route   GET /api/numerology/life-path/:number
// @access  Public
exports.getNumerologyByLifePath = async (req, res, next) => {
  try {
    const { number } = req.params;
    const { limit = 10 } = req.query;

    const numerologies = await Numerology.find({ 
      lifePathNumber: parseInt(number),
      isPublic: true 
    })
    .populate('user', 'name')
    .limit(parseInt(limit))
    .sort('-createdAt');

    res.status(200).json({
      success: true,
      count: numerologies.length,
      data: numerologies
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Generate detailed numerology report
// @route   POST /api/numerology/:id/detailed
// @access  Private
exports.generateDetailedReport = async (req, res, next) => {
  try {
    const numerology = await Numerology.findById(req.params.id);

    if (!numerology) {
      return next(new ErrorResponse(`Numerology report not found with id of ${req.params.id}`, 404));
    }

    // Make sure user owns numerology or is admin
    if (numerology.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return next(new ErrorResponse(`User ${req.user.id} is not authorized to generate detailed report`, 401));
    }

    // Generate detailed analysis
    const detailedAnalysis = generateDetailedAnalysis(numerology);
    numerology.analysis = detailedAnalysis;
    numerology.isDetailed = true;
    await numerology.save();

    res.status(200).json({
      success: true,
      data: numerology
    });
  } catch (error) {
    next(error);
  }
};

// Helper function to calculate core numbers
const calculateCoreNumbers = (name, dateOfBirth) => {
  // Life Path Number (sum of birth date)
  const birthDate = new Date(dateOfBirth);
  const day = birthDate.getDate();
  const month = birthDate.getMonth() + 1;
  const year = birthDate.getFullYear();
  
  const lifePathNumber = reduceToSingleDigit(day + month + year);

  // Destiny Number (sum of name)
  const destinyNumber = calculateNameNumber(name);

  // Soul Number (sum of vowels in name)
  const soulNumber = calculateVowelNumber(name);

  // Personality Number (sum of consonants in name)
  const personalityNumber = calculateConsonantNumber(name);

  // Maturity Number (Life Path + Destiny)
  const maturityNumber = reduceToSingleDigit(lifePathNumber + destinyNumber);

  return {
    lifePathNumber,
    destinyNumber,
    soulNumber,
    personalityNumber,
    maturityNumber
  };
};

// Helper function to reduce number to single digit
const reduceToSingleDigit = (num) => {
  while (num > 9) {
    num = num.toString().split('').reduce((a, b) => parseInt(a) + parseInt(b), 0);
  }
  return num;
};

// Helper function to calculate name number
const calculateNameNumber = (name) => {
  const nameValues = {
    'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5, 'F': 6, 'G': 7, 'H': 8, 'I': 9,
    'J': 1, 'K': 2, 'L': 3, 'M': 4, 'N': 5, 'O': 6, 'P': 7, 'Q': 8, 'R': 9,
    'S': 1, 'T': 2, 'U': 3, 'V': 4, 'W': 5, 'X': 6, 'Y': 7, 'Z': 8
  };

  const sum = name.toUpperCase().split('').reduce((total, letter) => {
    return total + (nameValues[letter] || 0);
  }, 0);

  return reduceToSingleDigit(sum);
};

// Helper function to calculate vowel number
const calculateVowelNumber = (name) => {
  const vowels = ['A', 'E', 'I', 'O', 'U'];
  const nameValues = {
    'A': 1, 'E': 5, 'I': 9, 'O': 6, 'U': 3
  };

  const sum = name.toUpperCase().split('').reduce((total, letter) => {
    if (vowels.includes(letter)) {
      return total + nameValues[letter];
    }
    return total;
  }, 0);

  return reduceToSingleDigit(sum);
};

// Helper function to calculate consonant number
const calculateConsonantNumber = (name) => {
  const vowels = ['A', 'E', 'I', 'O', 'U'];
  const nameValues = {
    'B': 2, 'C': 3, 'D': 4, 'F': 6, 'G': 7, 'H': 8, 'J': 1, 'K': 2, 'L': 3,
    'M': 4, 'N': 5, 'P': 7, 'Q': 8, 'R': 9, 'S': 1, 'T': 2, 'V': 4, 'W': 5,
    'X': 6, 'Y': 7, 'Z': 8
  };

  const sum = name.toUpperCase().split('').reduce((total, letter) => {
    if (!vowels.includes(letter) && nameValues[letter]) {
      return total + nameValues[letter];
    }
    return total;
  }, 0);

  return reduceToSingleDigit(sum);
};

// Helper function to analyze name
const analyzeName = (name) => {
  const vowels = ['A', 'E', 'I', 'O', 'U'];
  const nameArray = name.toUpperCase().split('');
  
  const vowelsInName = nameArray.filter(letter => vowels.includes(letter));
  const consonantsInName = nameArray.filter(letter => !vowels.includes(letter) && /[A-Z]/.test(letter));

  return {
    vowels: vowelsInName,
    consonants: consonantsInName,
    totalVowels: vowelsInName.length,
    totalConsonants: consonantsInName.length,
    nameNumber: calculateNameNumber(name)
  };
};

// Helper function to analyze birth date
const analyzeBirthDate = (dateOfBirth) => {
  const birthDate = new Date(dateOfBirth);
  
  return {
    day: birthDate.getDate(),
    month: birthDate.getMonth() + 1,
    year: birthDate.getFullYear(),
    dayNumber: reduceToSingleDigit(birthDate.getDate()),
    monthNumber: reduceToSingleDigit(birthDate.getMonth() + 1),
    yearNumber: reduceToSingleDigit(birthDate.getFullYear())
  };
};

// Helper function to calculate personal year number
const calculatePersonalYearNumber = (dateOfBirth) => {
  const birthDate = new Date(dateOfBirth);
  const currentYear = new Date().getFullYear();
  const personalYear = birthDate.getDate() + (birthDate.getMonth() + 1) + currentYear;
  
  return reduceToSingleDigit(personalYear);
};

// Helper function to generate lucky details
const generateLuckyDetails = (lifePathNumber) => {
  const luckyNumbers = [lifePathNumber, lifePathNumber + 1, lifePathNumber + 2];
  const unluckyNumbers = [lifePathNumber + 4, lifePathNumber + 5];
  
  const colorMap = {
    1: ['Red', 'Orange'],
    2: ['White', 'Silver'],
    3: ['Yellow', 'Gold'],
    4: ['Green', 'Brown'],
    5: ['Blue', 'Purple'],
    6: ['Pink', 'Rose'],
    7: ['Violet', 'Indigo'],
    8: ['Black', 'Gray'],
    9: ['Crimson', 'Maroon']
  };

  const dayMap = {
    1: ['Sunday', 'Tuesday'],
    2: ['Monday', 'Friday'],
    3: ['Thursday', 'Sunday'],
    4: ['Wednesday', 'Saturday'],
    5: ['Wednesday', 'Friday'],
    6: ['Friday', 'Monday'],
    7: ['Monday', 'Wednesday'],
    8: ['Saturday', 'Tuesday'],
    9: ['Tuesday', 'Thursday']
  };

  return {
    luckyNumbers,
    unluckyNumbers,
    luckyColors: colorMap[lifePathNumber] || ['Blue', 'Green'],
    luckyDays: dayMap[lifePathNumber] || ['Monday', 'Friday']
  };
};

// Helper function to generate numerology analysis
const generateNumerologyAnalysis = (coreNumbers) => {
  const lifePathDescriptions = {
    1: 'Natural born leader with strong individuality',
    2: 'Diplomatic and peaceful nature',
    3: 'Creative and expressive personality',
    4: 'Practical and hardworking individual',
    5: 'Adventurous and freedom-loving spirit',
    6: 'Nurturing and responsible character',
    7: 'Analytical and spiritual seeker',
    8: 'Ambitious and material success oriented',
    9: 'Compassionate and humanitarian nature'
  };

  return {
    lifePath: {
      description: lifePathDescriptions[coreNumbers.lifePathNumber] || 'Unique individual with special qualities',
      strengths: ['Leadership', 'Determination', 'Courage'],
      challenges: ['Impatience', 'Ego issues', 'Dominance'],
      career: 'Suitable for leadership roles and entrepreneurship',
      relationships: 'Loyal and committed partner',
      health: 'Focus on stress management and physical exercise'
    },
    destiny: {
      description: `Your destiny number ${coreNumbers.destinyNumber} indicates your life purpose`,
      purpose: 'To lead and inspire others',
      talents: ['Leadership', 'Innovation', 'Strategic thinking']
    },
    soul: {
      description: `Your soul number ${coreNumbers.soulNumber} reveals your inner desires`,
      innerDesires: ['Recognition', 'Success', 'Independence'],
      spiritualPath: 'Meditation and self-reflection'
    },
    personality: {
      description: `Your personality number ${coreNumbers.personalityNumber} shows how others see you`,
      howOthersSeeYou: 'Confident and capable',
      socialStyle: 'Outgoing and charismatic'
    }
  };
};

// Helper function to generate predictions
const generatePredictions = (coreNumbers, personalYearNumber) => {
  return {
    currentYear: `This year (Personal Year ${personalYearNumber}) brings new opportunities and growth.`,
    nextYear: `Next year will focus on building foundations and stability.`,
    longTerm: `Your life path number ${coreNumbers.lifePathNumber} indicates a journey of leadership and achievement.`
  };
};

// Helper function to generate remedies
const generateRemedies = (coreNumbers) => {
  return [
    'Practice meditation daily for inner peace',
    'Wear your lucky colors regularly',
    'Perform activities on your lucky days',
    'Use your lucky numbers in important decisions',
    'Chant mantras for spiritual growth'
  ];
};

// Helper function to generate detailed analysis
const generateDetailedAnalysis = (numerology) => {
  // This would contain much more detailed analysis
  return {
    ...numerology.analysis,
    detailedReport: `Comprehensive analysis for ${numerology.name} based on all numerology calculations.`,
    compatibility: {
      bestNumbers: [1, 3, 5],
      goodNumbers: [2, 4, 6],
      avoidNumbers: [7, 8, 9]
    }
  };
}; 