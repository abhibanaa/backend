const asyncHandler = require('../../middlewares/async');
const ErrorResponse = require('../../utils/errorResponse');
const Matching = require('../../models/Matching');
const User = require('../../models/User');

// @desc    Create matching
// @route   POST /api/matching/saveMatching
// @access  Public (with user_uni_id and api_key)
exports.saveMatching = asyncHandler(async (req, res, next) => {
  try {
    const {
      user_uni_id,
      api_key,
      person1,
      person2,
      relationshipType = 'romantic',
      compatibilityScore = 0,
      analysis = {},
      notes = ''
    } = req.body;

    // Validate required fields
    if (!user_uni_id || !api_key || !person1 || !person2) {
      return next(new ErrorResponse('Please provide user_uni_id, api_key, person1, and person2', 400));
    }

    // Validate relationship type
    if (!['romantic', 'business', 'friendship', 'family'].includes(relationshipType)) {
      return next(new ErrorResponse('relationshipType must be one of: romantic, business, friendship, family', 400));
    }

    // Verify user
    const user = await User.findOne({ user_uni_id: user_uni_id, api_key, isActive: true });
    if (!user) {
      return next(new ErrorResponse('Invalid user_uni_id or api_key', 401));
    }

    // Create matching record
    const matchingData = {
      user: user._id,
      person1,
      person2,
      relationshipType,
      compatibilityScore,
      analysis,
      notes,
      status: 'Active'
    };

    const matching = await Matching.create(matchingData);

    res.status(201).json({
      success: true,
      message: 'Matching created successfully',
      data: matching.getFormattedData()
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Get user's matchings
// @route   GET /api/matching/userKundaliMatchingRequest
// @access  Public (with user_uni_id and api_key)
exports.getUserMatchings = asyncHandler(async (req, res, next) => {
  try {
    const { user_uni_id, api_key, relationshipType, status } = req.query;

    // Validate required fields
    if (!user_uni_id || !api_key) {
      return next(new ErrorResponse('Please provide user_uni_id and api_key', 400));
    }

    // Verify user
    const user = await User.findOne({ user_uni_id: user_uni_id, api_key, isActive: true });
    if (!user) {
      return next(new ErrorResponse('Invalid user_uni_id or api_key', 401));
    }

    // Build query
    const query = { user: user._id };
    if (relationshipType) query.relationshipType = relationshipType;
    if (status) query.status = status;

    // Get matchings with pagination
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    const matchings = await Matching.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .exec();

    const total = await Matching.countDocuments(query);
    const totalPages = Math.ceil(total / limit);

    res.status(200).json({
      success: true,
      count: matchings.length,
      total,
      totalPages,
      currentPage: page,
      data: matchings.map(matching => matching.getFormattedData())
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Get matching by ID
// @route   GET /api/matching/:id
// @access  Public (with user_uni_id and api_key)
exports.getMatchingById = asyncHandler(async (req, res, next) => {
  try {
    const { user_uni_id, api_key } = req.query;
    const { id } = req.params;

    // Validate required fields
    if (!user_uni_id || !api_key) {
      return next(new ErrorResponse('Please provide user_uni_id and api_key', 400));
    }

    // Verify user
    const user = await User.findOne({ user_uni_id: user_uni_id, api_key, isActive: true });
    if (!user) {
      return next(new ErrorResponse('Invalid user_uni_id or api_key', 401));
    }

    // Find matching
    let matching;
    try {
      matching = await Matching.findById(id);
    } catch (error) {
      if (error.name === 'CastError') {
        return next(new ErrorResponse('Invalid matching ID format. Please provide a valid ID.', 400));
      }
      throw error;
    }

    if (!matching) {
      return next(new ErrorResponse('Matching not found', 404));
    }

    // Check if user owns this matching
    if (matching.user.toString() !== user._id.toString()) {
      return next(new ErrorResponse('Not authorized to access this matching', 403));
    }

    res.status(200).json({
      success: true,
      data: matching.getFormattedData()
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Update matching
// @route   PUT /api/matching/editKundaliMatching/:id
// @access  Public (with user_uni_id and api_key)
exports.updateMatching = asyncHandler(async (req, res, next) => {
  try {
    const {
      user_uni_id,
      api_key,
      person1,
      person2,
      relationshipType,
      compatibilityScore,
      analysis,
      notes,
      status
    } = req.body;

    const { id } = req.params;

    // Validate required fields
    if (!user_uni_id || !api_key) {
      return next(new ErrorResponse('Please provide user_uni_id and api_key', 400));
    }

    // Verify user
    const user = await User.findOne({ user_uni_id: user_uni_id, api_key, isActive: true });
    if (!user) {
      return next(new ErrorResponse('Invalid user_uni_id or api_key', 401));
    }

    // Find matching
    let matching;
    try {
      matching = await Matching.findById(id);
    } catch (error) {
      if (error.name === 'CastError') {
        return next(new ErrorResponse('Invalid matching ID format. Please provide a valid ID.', 400));
      }
      throw error;
    }

    if (!matching) {
      return next(new ErrorResponse('Matching not found', 404));
    }

    // Check if user owns this matching
    if (matching.user.toString() !== user._id.toString()) {
      return next(new ErrorResponse('Not authorized to update this matching', 403));
    }

    // Update fields
    const updateData = {};
    if (person1 !== undefined) updateData.person1 = person1;
    if (person2 !== undefined) updateData.person2 = person2;
    if (relationshipType !== undefined) updateData.relationshipType = relationshipType;
    if (compatibilityScore !== undefined) updateData.compatibilityScore = compatibilityScore;
    if (analysis !== undefined) updateData.analysis = analysis;
    if (notes !== undefined) updateData.notes = notes;
    if (status !== undefined) updateData.status = status;

    // Update matching
    const updatedMatching = await Matching.findByIdAndUpdate(
      id,
      updateData,
      { new: true, runValidators: true }
    );

    res.status(200).json({
      success: true,
      message: 'Matching updated successfully',
      data: updatedMatching.getFormattedData()
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Delete matching
// @route   DELETE /api/matching/deleteKundaliMatching/:id
// @access  Public (with user_uni_id and api_key)
exports.deleteMatching = asyncHandler(async (req, res, next) => {
  try {
    const { user_uni_id, api_key } = req.body;
    const { id } = req.params;

    // Validate required fields
    if (!user_uni_id || !api_key) {
      return next(new ErrorResponse('Please provide user_uni_id and api_key', 400));
    }

    // Verify user
    const user = await User.findOne({ user_uni_id: user_uni_id, api_key, isActive: true });
    if (!user) {
      return next(new ErrorResponse('Invalid user_uni_id or api_key', 401));
    }

    // Find matching
    let matching;
    try {
      matching = await Matching.findById(id);
    } catch (error) {
      if (error.name === 'CastError') {
        return next(new ErrorResponse('Invalid matching ID format. Please provide a valid ID.', 400));
      }
      throw error;
    }

    if (!matching) {
      return next(new ErrorResponse('Matching not found', 404));
    }

    // Check if user owns this matching
    if (matching.user.toString() !== user._id.toString()) {
      return next(new ErrorResponse('Not authorized to delete this matching', 403));
    }

    // Delete matching
    await matching.deleteOne();

    res.status(200).json({
      success: true,
      message: 'Matching deleted successfully'
    });
  } catch (error) {
    next(error);
  }
}); 