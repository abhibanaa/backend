const express = require('express');
const {
  saveMatching,
  getUserMatchings,
  getMatchingById,
  updateMatching,
  deleteMatching
} = require('./matchingController');

const router = express.Router();

// Public routes (using user_uni_id and api_key for authentication)
router.post('/saveMatching', saveMatching);
router.get('/userKundaliMatchingRequest', getUserMatchings);
router.get('/:id', getMatchingById);
router.put('/editKundaliMatching/:id', updateMatching);
router.delete('/deleteKundaliMatching/:id', deleteMatching);

module.exports = router; 