const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const path = require('path');
const http = require('http');
const socketIo = require('socket.io');

// Load env vars
dotenv.config();

// Connect to database
const connectDB = require('./config/db');
connectDB();

const app = express();
const server = http.createServer(app);

// Socket.IO setup
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// Make io available to routes
app.set('io', io);

// Socket.IO connection handling
io.on('connection', (socket) => {
  console.log('🔌 New client connected:', socket.id);

  // Join user to their personal room
  socket.on('join_user', (userId) => {
    socket.join(`user_${userId}`);
    console.log(`👤 User ${userId} joined their room`);
  });

  // Handle disconnection
  socket.on('disconnect', () => {
    console.log('🔌 Client disconnected:', socket.id);
  });
});

// Body parser
app.use(express.json());

// Security middleware
app.use(helmet());

// Enable CORS
app.use(cors());

// Rate limiting
const limiter = rateLimit({
  windowMs: 10 * 60 * 1000, // 10 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});
app.use('/api/', limiter);

// Logging middleware
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
}

// Set static folder
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Routes
app.use('/api/auth', require('./apis/auth/authRoutes'));
app.use('/api/users', require('./apis/auth/authRoutes')); // Users routes (same as auth for admin functions)
app.use('/api/horoscope', require('./apis/horoscope/horoscopeRoutes'));
app.use('/api/kundali', require('./apis/kundli/kundaliRoutes'));
app.use('/api/kundli', require('./apis/kundli/kundliRoutes'));
app.use('/api/matching', require('./apis/matching/matchingRoutes'));
app.use('/api/paidKundli', require('./apis/paidKundli/paidKundliRoutes'));


app.use('/api/pdf', require('./apis/pdf/pdfRoutes'));

app.use('/api/numerology', require('./apis/numerology/numerologyRoutes'));
app.use('/api/panchang', require('./apis/panchang/panchangRoutes'));
app.use('/api/notifications', require('./apis/notification/notificationRoutes'));
app.use('/api/blogs', require('./apis/blog/blogRoutes'));

// Razorpay routes
app.use('/api/app/razorpay', require('./apis/razorpay/appRazorpayRoutes'));
app.use('/api/admin/razorpay', require('./apis/razorpay/adminRazorpayRoutes'));

// Serve admin panel
app.use('/admin-panel', express.static(path.join(__dirname, 'admin-panel')));

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Astrology App API is running',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development'
  });
});

// API documentation endpoint
app.get('/api', (req, res) => {
  res.json({
    message: 'Astrology App API Documentation',
    version: '1.0.0',
    endpoints: {
      auth: {
        register: 'POST /api/auth/register',
        login: 'POST /api/auth/login',
        logout: 'POST /api/auth/logout',
        getMe: 'GET /api/auth/me',
        updateDetails: 'PUT /api/auth/updatedetails',
        deleteAccount: 'DELETE /api/auth/delete-account',
        sendOTP: 'POST /api/auth/send-otp',
        sendOTPByPhone: 'GET /api/auth/send-otp/:phone',
        loginByQuery: 'GET /api/auth/login?phone=:phone&otp=:otp',
        adminLogin: 'POST /api/auth/admin/login'
      },
      kundli: {
        saveKundliData: 'POST /api/kundli/saveKundliData',
        userKundaliRequest: 'GET /api/kundli/userKundaliRequest',
        getKundliById: 'GET /api/kundli/:id',
        editKundliData: 'PUT /api/kundli/editKundliData/:id',
        deleteKundali: 'DELETE /api/kundli/deleteKundali/:id',
        analyzeKundli: 'POST /api/kundli/:id/analyze',
        getKundlisByZodiac: 'GET /api/kundli/zodiac/:sign (Admin)',
        getAllKundlis: 'GET /api/kundli/admin/all (Admin)'
      },
      matching: {
        saveMatching: 'POST /api/matching/saveMatching',
        userKundaliMatchingRequest: 'GET /api/matching/userKundaliMatchingRequest',
        getMatchingById: 'GET /api/matching/:id',
        editKundaliMatching: 'PUT /api/matching/editKundaliMatching/:id',
        deleteKundaliMatching: 'DELETE /api/matching/deleteKundaliMatching/:id'
      },
      notifications: {
        getAll: 'GET /api/notifications',
        getOne: 'GET /api/notifications/:id',
        markAsRead: 'PUT /api/notifications/:id/read',
        markAllAsRead: 'PUT /api/notifications/read-all',
        delete: 'DELETE /api/notifications/:id',
        unreadCount: 'GET /api/notifications/unread-count',
        create: 'POST /api/notifications (Admin)',
        broadcast: 'POST /api/notifications/broadcast (Admin)'
      },
      blogs: {
        getAll: 'GET /api/blogs',
        getOne: 'GET /api/blogs/:slug',
        create: 'POST /api/blogs (Admin)',
        update: 'PUT /api/blogs/:id (Admin)',
        delete: 'DELETE /api/blogs/:id (Admin)',
        addComment: 'POST /api/blogs/:id/comments',
        like: 'POST /api/blogs/:id/like',
        byCategory: 'GET /api/blogs/category/:category',
        featured: 'GET /api/blogs/featured',
        search: 'GET /api/blogs/search?q=:query'
      },
      horoscope: {
        daily: 'POST /api/horoscope/daily'
      },

      numerology: {
        calculate: 'POST /api/numerology/calculate'
      },
      panchang: {
        today: 'POST /api/panchang/today'
      }
    },
    realtime: {
      socket: 'WebSocket connection available',
      events: {
        join_user: 'Join user room for notifications',
        new_notification: 'Receive new notification',
        broadcast_notification: 'Receive broadcast notification'
      }
    }
  });
});

// Error handling middleware
app.use(require('./middlewares/errorHandler'));

const PORT = process.env.PORT || 5000;

server.listen(PORT, () => {
  console.log(`🚀 Astrology App API Server running on port ${PORT}`);
  console.log(`📊 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🔗 Health Check: http://localhost:${PORT}/health`);
  console.log(`📚 API Documentation: http://localhost:${PORT}/api`);
  console.log(`🔌 WebSocket: ws://localhost:${PORT}`);
}); 