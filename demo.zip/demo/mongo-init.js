// MongoDB initialization script for Docker
db = db.getSiblingDB('astroApp');

// Create collections
db.createCollection('users');
db.createCollection('kundalis');
db.createCollection('matchings');
db.createCollection('paidkundlis');
db.createCollection('pricingconfigs');
db.createCollection('pdfs');

db.createCollection('horoscopes');
db.createCollection('panchangs');
db.createCollection('numerologies');

// Create indexes for better performance
db.users.createIndex({ "email": 1 }, { unique: true });
db.users.createIndex({ "createdAt": -1 });

db.kundalis.createIndex({ "user": 1, "dateOfBirth": 1 });
db.kundalis.createIndex({ "sunSign": 1, "moonSign": 1 });

db.matchings.createIndex({ "user": 1, "createdAt": -1 });
db.matchings.createIndex({ "person1.name": 1, "person2.name": 1 });

db.paidkundlis.createIndex({ "user": 1, "createdAt": -1 });
db.paidkundlis.createIndex({ "paymentStatus": 1 });
db.paidkundlis.createIndex({ "status": 1 });
db.paidkundlis.createIndex({ "name": 1 });

db.pricingconfigs.createIndex({ "serviceName": 1 });
db.pricingconfigs.createIndex({ "isActive": 1 });

db.pdfs.createIndex({ "category": 1, "isActive": 1 });
db.pdfs.createIndex({ "isFeatured": 1, "isActive": 1 });
db.pdfs.createIndex({ "language": 1, "isActive": 1 });
db.pdfs.createIndex({ "title": "text", "description": "text" });
db.pdfs.createIndex({ "tags": 1 });
db.pdfs.createIndex({ "downloadCount": -1 });
db.pdfs.createIndex({ "createdAt": -1 });



db.horoscopes.createIndex({ "zodiacSign": 1, "type": 1, "date": 1 });
db.horoscopes.createIndex({ "user": 1, "date": -1 });

db.panchangs.createIndex({ "date": 1 });
db.panchangs.createIndex({ "location.name": 1, "date": 1 });

db.numerologies.createIndex({ "user": 1, "createdAt": -1 });
db.numerologies.createIndex({ "lifePathNumber": 1, "destinyNumber": 1 });

// Insert sample data (optional)
db.horoscopes.insertMany([
  {
    type: "daily",
    date: new Date("2024-01-15"),
    zodiacSign: "Aries",
    content: {
      general: "Today brings new opportunities for leadership and innovation.",
      love: "Romantic relationships flourish with open communication.",
      career: "Take initiative in professional matters.",
      health: "Focus on physical exercise and stress management."
    },
    lucky: {
      number: [1, 9],
      color: ["Red", "Orange"],
      day: ["Tuesday", "Sunday"],
      time: "10:00 AM"
    },
    mood: "Excellent",
    energy: "High",
    source: "AI Generated",
    isPersonalized: false,
    language: "English"
  },
  {
    type: "daily",
    date: new Date("2024-01-15"),
    zodiacSign: "Taurus",
    content: {
      general: "Stability and patience are your strengths today.",
      love: "Deep emotional connections are favored.",
      career: "Focus on long-term goals and steady progress.",
      health: "Grounding exercises and nature walks are beneficial."
    },
    lucky: {
      number: [2, 6],
      color: ["Green", "Brown"],
      day: ["Friday", "Monday"],
      time: "2:00 PM"
    },
    mood: "Good",
    energy: "Medium",
    source: "AI Generated",
    isPersonalized: false,
    language: "English"
  }
]);

db.panchangs.insertMany([
  {
    date: new Date("2024-01-15"),
    location: {
      name: "Mumbai",
      latitude: 19.0760,
      longitude: 72.8777,
      timezone: "Asia/Kolkata"
    },
    tithi: {
      name: "Dwitiya",
      number: 2,
      startTime: new Date("2024-01-15T06:00:00.000Z"),
      endTime: new Date("2024-01-15T18:00:00.000Z")
    },
    vara: "Monday",
    nakshatra: {
      name: "Rohini",
      number: 4,
      startTime: new Date("2024-01-15T06:00:00.000Z"),
      endTime: new Date("2024-01-15T18:00:00.000Z")
    },
    yoga: {
      name: "Ayushman",
      number: 3
    },
    karana: {
      name: "Balava",
      number: 2
    },
    muhurat: {
      sunrise: new Date("2024-01-15T06:45:00.000Z"),
      sunset: new Date("2024-01-15T18:15:00.000Z"),
      brahmaMuhurat: {
        start: new Date("2024-01-15T05:15:00.000Z"),
        end: new Date("2024-01-15T06:15:00.000Z")
      },
      abhijitMuhurat: {
        start: new Date("2024-01-15T12:00:00.000Z"),
        end: new Date("2024-01-15T12:45:00.000Z")
      }
    },
    festivals: [
      {
        name: "Makar Sankranti",
        description: "Sun enters Capricorn",
        isAuspicious: true
      }
    ],
    dosha: "None",
    remedies: [],
    recommendations: {
      goodFor: ["Starting new ventures", "Spiritual activities"],
      avoid: ["Negative thoughts", "Hasty decisions"],
      generalAdvice: "Focus on positive energy and spiritual growth"
    },
    language: "English"
  }
]);

print("MongoDB initialization completed successfully!"); 