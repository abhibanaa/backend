# 🔧 Key Code Snippets - Astrology App

## 🚀 Server Configuration

### Main Server (server.js)
```javascript
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('admin-panel'));
app.use('/uploads', express.static('uploads'));

// Routes
app.use('/api/auth', require('./routes/authRoutes'));

// Health Check
app.get('/health', (req, res) => {
  res.json({
    success: true,
    message: 'Astrology App API is running',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development'
  });
});

// Serve admin panel
app.get('/admin-panel/', (req, res) => {
  res.sendFile(path.join(__dirname, 'admin-panel', 'index.html'));
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Astrology App API Server running on port ${PORT}`);
});
```

## 🔐 Authentication Controller

### Admin Login
```javascript
exports.adminLogin = async (req, res, next) => {
  try {
    const { username, password } = req.body;
    
    if (username === 'admin123' && password === 'admin@123') {
      let adminUser = await User.findOne({ role: 'admin' });
      
      if (!adminUser) {
        adminUser = await User.create({
          name: 'Admin User',
          email: 'admin@astrologyapp.com',
          phone: 'admin-phone',
          role: 'admin',
          isProfileComplete: true,
          isActive: true
        });
      }

      const token = adminUser.getSignedJwtToken();
      
      res.status(200).json({
        success: true,
        token,
        user: {
          id: adminUser._id,
          name: adminUser.name,
          email: adminUser.email,
          role: adminUser.role
        }
      });
    } else {
      return next(new ErrorResponse('Invalid credentials', 401));
    }
  } catch (error) {
    next(error);
  }
};
```

### Create User (Admin)
```javascript
exports.createUser = async (req, res, next) => {
  try {
    const { 
      name, 
      email, 
      phone, 
      dateOfBirth, 
      timeOfBirth, 
      placeOfBirth, 
      role = 'user', 
      isActive = true 
    } = req.body;

    const existingUser = await User.findOne({ 
      $or: [{ email }, { phone }] 
    });
    
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'User already exists with this email or phone number'
      });
    }

    const userData = {
      name,
      email,
      phone,
      dateOfBirth: dateOfBirth || null,
      timeOfBirth: timeOfBirth || null,
      placeOfBirth: placeOfBirth || null,
      role,
      isActive,
      isProfileComplete: true
    };

    const user = await User.create(userData);

    res.status(201).json({
      success: true,
      message: 'User created successfully',
      data: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        isActive: user.isActive
      }
    });
  } catch (error) {
    next(error);
  }
};
```

## 🗺️ Google Places API Integration

### HTML Integration
```html
<!-- Google Places API Script -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBK07TpKO63SXH-QzaJP5iCU7jzJgtCL2s&libraries=places"></script>

<!-- Places Input Field -->
<div class="places-autocomplete-container">
    <input type="text" id="addUserPlaceOfBirth" placeholder="Start typing to search places...">
    <div id="addUserPlacesDropdown" class="places-dropdown"></div>
</div>
```

### JavaScript Implementation
```javascript
function setupPlacesAutocomplete(input, dropdown) {
    let autocomplete = new google.maps.places.Autocomplete(input, {
        types: ['(cities)'],
        componentRestrictions: { country: 'IN' }
    });
    
    input.addEventListener('input', function() {
        const query = this.value.trim();
        if (query.length >= 2) {
            searchPlaces(query, dropdown, input);
        } else {
            hideDropdown(dropdown);
        }
    });
}

function searchPlaces(query, dropdown, input) {
    const service = new google.maps.places.PlacesService(document.createElement('div'));
    
    const request = {
        query: query,
        types: ['(cities)'],
        componentRestrictions: { country: 'IN' }
    };
    
    service.textSearch(request, function(results, status) {
        if (status === google.maps.places.PlacesServiceStatus.OK && results) {
            displayPlacesResults(results, dropdown, input);
        } else {
            hideDropdown(dropdown);
        }
    });
}
```

## 🎨 CSS Styling

### Places Dropdown Styling
```css
.places-autocomplete-container {
    position: relative;
}

.places-dropdown {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background: white;
    border: 1px solid #e2e8f0;
    border-top: none;
    border-radius: 0 0 8px 8px;
    max-height: 200px;
    overflow-y: auto;
    z-index: 1000;
    display: none;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.places-dropdown.active {
    display: block;
}

.places-dropdown-item {
    padding: 12px 16px;
    cursor: pointer;
    border-bottom: 1px solid #f1f5f9;
    transition: background-color 0.2s ease;
}

.places-dropdown-item:hover {
    background-color: #f8fafc;
}
```

## 📊 Dashboard Analytics

### Dashboard Stats API
```javascript
exports.getDashboardStats = async (req, res, next) => {
  try {
    const totalUsers = await User.countDocuments();
    const activeUsers = await User.countDocuments({ isActive: true });
    const completeProfiles = await User.countDocuments({ isProfileComplete: true });
    const incompleteProfiles = await User.countDocuments({ isProfileComplete: false });
    
    const lastWeek = new Date();
    lastWeek.setDate(lastWeek.getDate() - 7);
    const newUsersThisWeek = await User.countDocuments({ 
      createdAt: { $gte: lastWeek } 
    });

    const adminUsers = await User.countDocuments({ role: 'admin' });

    res.status(200).json({
      success: true,
      data: {
        totalUsers,
        activeUsers,
        completeProfiles,
        incompleteProfiles,
        newUsersThisWeek,
        adminUsers,
        completionRate: totalUsers > 0 ? Math.round((completeProfiles / totalUsers) * 100) : 0
      }
    });
  } catch (error) {
    next(error);
  }
};
```

## 🔐 User Model Schema

```javascript
const userSchema = new mongoose.Schema({
  name: {
    type: String,
    default: null,
    trim: true,
    maxlength: [50, 'Name cannot be more than 50 characters']
  },
  email: {
    type: String,
    sparse: true,
    match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'Please provide a valid email']
  },
  phone: {
    type: String,
    required: [true, 'Please provide a phone number'],
    trim: true,
    unique: true
  },
  password: {
    type: String,
    select: false
  },
  dateOfBirth: {
    type: Date,
    default: null
  },
  timeOfBirth: {
    type: String,
    default: null
  },
  placeOfBirth: {
    type: String,
    default: null
  },
  profileImage: {
    type: String,
    default: null
  },
  isProfileComplete: {
    type: Boolean,
    default: false
  },
  isActive: {
    type: Boolean,
    default: true
  },
  role: {
    type: String,
    enum: ['user', 'admin'],
    default: 'user'
  },
  otp: {
    code: {
      type: String,
      default: '333661'
    },
    expiresAt: {
      type: Date,
      default: function() {
        return new Date(Date.now() + 10 * 60 * 1000);
      }
    },
    isVerified: {
      type: Boolean,
      default: false
    }
  }
}, {
  timestamps: true
});
```

## 🎯 Frontend Admin Panel

### Add User Modal
```javascript
async function handleAddUser(e) {
    e.preventDefault();
    
    try {
        showLoading('Creating user...');
        
        const userData = {
            name: document.getElementById('addUserName').value,
            email: document.getElementById('addUserEmail').value,
            phone: document.getElementById('addUserPhone').value,
            dateOfBirth: document.getElementById('addUserDateOfBirth').value || null,
            timeOfBirth: document.getElementById('addUserTimeOfBirth').value || null,
            placeOfBirth: document.getElementById('addUserPlaceOfBirth').value || null,
            role: document.getElementById('addUserRole').value,
            isActive: document.getElementById('addUserStatus').value === 'true'
        };
        
        const response = await fetch(`${API_BASE_URL}/auth/admin/users`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(userData)
        });
        
        const data = await response.json();
        
        if (data.success) {
            showToast('User created successfully', 'success');
            closeModal('addUserModal');
            loadUsers();
        } else {
            throw new Error(data.message || 'Failed to create user');
        }
    } catch (error) {
        showToast(error.message || 'Failed to create user', 'error');
    } finally {
        hideLoading();
    }
}
```

## 🔧 Environment Variables

```bash
# .env file
NODE_ENV=development
PORT=5000
MONGODB_URI=your_mongodb_connection_string
JWT_SECRET=your_jwt_secret_key
JWT_EXPIRE=7d
```

## 📱 API Response Format

### Success Response
```javascript
{
  "success": true,
  "message": "Operation completed successfully",
  "data": {
    // Response data
  }
}
```

### Error Response
```javascript
{
  "success": false,
  "message": "Error description",
  "errors": [
    // Validation errors
  ]
}
```

---

**Note**: This is the current implementation as of July 17, 2025. All features are working and tested. 