# Razorpay Configuration API Documentation

## Overview
The Razorpay Configuration API allows administrators to manage Razorpay payment gateway settings including Razorpay ID, Key, and RazorpayX Account information. This API supports both test and live environments.

## Features
- ✅ Create new Razorpay configurations
- ✅ Get all configurations with pagination
- ✅ Get specific configuration by ID
- ✅ Update existing configurations
- ✅ Delete configurations
- ✅ Toggle configuration status (active/inactive)
- ✅ Get active configuration for specific environment
- ✅ Environment support (test/live)
- ✅ Admin-only access control
- ✅ Secure key masking for public endpoints

## API Endpoints

### 1. Create Razorpay Configuration
**POST** `/api/razorpay/config`

**Access:** Admin only

**Request Body:**
```json
{
  "razorpayId": "rzp_test_xxxxxxxxxxxxx",
  "razorpayKey": "xxxxxxxxxxxxxxxxxxxxxxxx",
  "razorpayXAccount": "xxxxxxxxxxxxxxxxxxxxxxxx",
  "environment": "test",
  "description": "Test environment configuration"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Razorpay configuration created successfully",
  "data": {
    "id": "64f8a1b2c3d4e5f6a7b8c9d0",
    "razorpayId": "rzp_test_xxxxxxxxxxxxx",
    "razorpayKey": "xxxxxxxxxxxxxxxxxxxxxxxx",
    "razorpayXAccount": "xxxxxxxxxxxxxxxxxxxxxxxx",
    "isActive": true,
    "environment": "test",
    "description": "Test environment configuration",
    "updatedBy": "64f8a1b2c3d4e5f6a7b8c9d1",
    "updatedAt": "2023-09-06T10:30:00.000Z",
    "createdAt": "2023-09-06T10:30:00.000Z"
  }
}
```

### 2. Get All Configurations
**GET** `/api/razorpay/config`

**Access:** Admin only

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10)
- `environment` (optional): Filter by environment (test/live)
- `isActive` (optional): Filter by status (true/false)

**Response:**
```json
{
  "success": true,
  "message": "Razorpay configurations retrieved successfully",
  "data": {
    "docs": [
      {
        "id": "64f8a1b2c3d4e5f6a7b8c9d0",
        "razorpayId": "rzp_test_xxxxxxxxxxxxx",
        "razorpayKey": "xxxxxxxxxxxxxxxxxxxxxxxx",
        "razorpayXAccount": "xxxxxxxxxxxxxxxxxxxxxxxx",
        "isActive": true,
        "environment": "test",
        "description": "Test environment configuration",
        "updatedBy": {
          "id": "64f8a1b2c3d4e5f6a7b8c9d1",
          "name": "Admin User",
          "email": "admin@example.com"
        },
        "updatedAt": "2023-09-06T10:30:00.000Z",
        "createdAt": "2023-09-06T10:30:00.000Z"
      }
    ],
    "totalDocs": 1,
    "limit": 10,
    "page": 1,
    "totalPages": 1,
    "hasNextPage": false,
    "hasPrevPage": false
  }
}
```

### 3. Get Configuration by ID
**GET** `/api/razorpay/config/:id`

**Access:** Admin only

**Response:**
```json
{
  "success": true,
  "message": "Razorpay configuration retrieved successfully",
  "data": {
    "id": "64f8a1b2c3d4e5f6a7b8c9d0",
    "razorpayId": "rzp_test_xxxxxxxxxxxxx",
    "razorpayKey": "xxxxxxxxxxxxxxxxxxxxxxxx",
    "razorpayXAccount": "xxxxxxxxxxxxxxxxxxxxxxxx",
    "isActive": true,
    "environment": "test",
    "description": "Test environment configuration",
    "updatedBy": {
      "id": "64f8a1b2c3d4e5f6a7b8c9d1",
      "name": "Admin User",
      "email": "admin@example.com"
    },
    "updatedAt": "2023-09-06T10:30:00.000Z",
    "createdAt": "2023-09-06T10:30:00.000Z"
  }
}
```

### 4. Update Configuration
**PUT** `/api/razorpay/config/:id`

**Access:** Admin only

**Request Body:** (All fields are optional)
```json
{
  "razorpayId": "rzp_live_xxxxxxxxxxxxx",
  "razorpayKey": "new_key_xxxxxxxxxxxxx",
  "razorpayXAccount": "new_account_xxxxxxxxxxxxx",
  "environment": "live",
  "description": "Updated live environment configuration",
  "isActive": true
}
```

**Response:**
```json
{
  "success": true,
  "message": "Razorpay configuration updated successfully",
  "data": {
    "id": "64f8a1b2c3d4e5f6a7b8c9d0",
    "razorpayId": "rzp_live_xxxxxxxxxxxxx",
    "razorpayKey": "new_key_xxxxxxxxxxxxx",
    "razorpayXAccount": "new_account_xxxxxxxxxxxxx",
    "isActive": true,
    "environment": "live",
    "description": "Updated live environment configuration",
    "updatedBy": "64f8a1b2c3d4e5f6a7b8c9d1",
    "updatedAt": "2023-09-06T11:00:00.000Z",
    "createdAt": "2023-09-06T10:30:00.000Z"
  }
}
```

### 5. Delete Configuration
**DELETE** `/api/razorpay/config/:id`

**Access:** Admin only

**Response:**
```json
{
  "success": true,
  "message": "Razorpay configuration deleted successfully"
}
```

### 6. Toggle Configuration Status
**PATCH** `/api/razorpay/config/:id/toggle`

**Access:** Admin only

**Response:**
```json
{
  "success": true,
  "message": "Razorpay configuration activated successfully",
  "data": {
    "id": "64f8a1b2c3d4e5f6a7b8c9d0",
    "razorpayId": "rzp_test_xxxxxxxxxxxxx",
    "razorpayKey": "xxxxxxxxxxxxxxxxxxxxxxxx",
    "razorpayXAccount": "xxxxxxxxxxxxxxxxxxxxxxxx",
    "isActive": true,
    "environment": "test",
    "description": "Test environment configuration",
    "updatedBy": "64f8a1b2c3d4e5f6a7b8c9d1",
    "updatedAt": "2023-09-06T11:30:00.000Z",
    "createdAt": "2023-09-06T10:30:00.000Z"
  }
}
```

### 7. Get Active Configuration (Public)
**GET** `/api/razorpay/config/active/:environment`

**Access:** Public

**Response:** (Key is masked for security)
```json
{
  "success": true,
  "message": "Active Razorpay configuration retrieved successfully",
  "data": {
    "id": "64f8a1b2c3d4e5f6a7b8c9d0",
    "razorpayId": "rzp_test_xxxxxxxxxxxxx",
    "razorpayKey": "***xxxx",
    "razorpayXAccount": "xxxxxxxxxxxxxxxxxxxxxxxx",
    "isActive": true,
    "environment": "test",
    "description": "Test environment configuration",
    "updatedBy": "64f8a1b2c3d4e5f6a7b8c9d1",
    "updatedAt": "2023-09-06T10:30:00.000Z",
    "createdAt": "2023-09-06T10:30:00.000Z"
  }
}
```

## Authentication

All admin endpoints require authentication using Bearer token:

```
Authorization: Bearer YOUR_ADMIN_TOKEN
```

## Error Responses

### 400 Bad Request
```json
{
  "success": false,
  "message": "Configuration for test environment already exists"
}
```

### 401 Unauthorized
```json
{
  "success": false,
  "message": "Not authorized to access this route"
}
```

### 404 Not Found
```json
{
  "success": false,
  "message": "Razorpay configuration not found"
}
```

### 500 Internal Server Error
```json
{
  "success": false,
  "message": "Server Error"
}
```

## Usage Examples

### JavaScript/Node.js
```javascript
// Create configuration
const createConfig = async () => {
  const response = await fetch('/api/razorpay/config', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer YOUR_ADMIN_TOKEN'
    },
    body: JSON.stringify({
      razorpayId: 'rzp_test_xxxxxxxxxxxxx',
      razorpayKey: 'xxxxxxxxxxxxxxxxxxxxxxxx',
      razorpayXAccount: 'xxxxxxxxxxxxxxxxxxxxxxxx',
      environment: 'test',
      description: 'Test environment configuration'
    })
  });
  
  const data = await response.json();
  console.log(data);
};

// Get active configuration
const getActiveConfig = async (environment = 'test') => {
  const response = await fetch(`/api/razorpay/config/active/${environment}`);
  const data = await response.json();
  console.log(data);
};
```

### cURL Examples

#### Create Configuration
```bash
curl -X POST http://localhost:3000/api/razorpay/config \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN" \
  -d '{
    "razorpayId": "rzp_test_xxxxxxxxxxxxx",
    "razorpayKey": "xxxxxxxxxxxxxxxxxxxxxxxx",
    "razorpayXAccount": "xxxxxxxxxxxxxxxxxxxxxxxx",
    "environment": "test",
    "description": "Test environment configuration"
  }'
```

#### Get All Configurations
```bash
curl -X GET "http://localhost:3000/api/razorpay/config?page=1&limit=10" \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN"
```

#### Get Active Configuration
```bash
curl -X GET http://localhost:3000/api/razorpay/config/active/test
```

## Data Model

### RazorpayConfig Schema
```javascript
{
  razorpayId: String (required),
  razorpayKey: String (required),
  razorpayXAccount: String (required),
  isActive: Boolean (default: true),
  environment: String (enum: ['test', 'live'], default: 'test'),
  description: String (optional, max: 500 chars),
  updatedBy: ObjectId (ref: 'User'),
  createdAt: Date,
  updatedAt: Date
}
```

## Security Features

1. **Admin-only Access**: All management endpoints require admin authentication
2. **Key Masking**: Public endpoints mask sensitive information (razorpayKey)
3. **Environment Isolation**: Separate configurations for test and live environments
4. **Audit Trail**: Tracks who updated the configuration and when
5. **Validation**: Comprehensive input validation and error handling

## Testing

Use the provided `test-razorpay-config.html` file to test all API endpoints with a user-friendly interface.

## Notes

- Only one active configuration per environment is allowed
- When updating environment, the system checks for conflicts
- Deleted configurations cannot be recovered
- Public endpoints only return masked sensitive data
- All timestamps are in ISO 8601 format 