#!/bin/bash

echo "🔑 Testing Login API - User ID & API Key Generation"
echo "=================================================="

# Test login API
echo "📤 Sending login request..."
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "phone": "+918107804990",
    "otp": "333661"
  }' \
  | jq '.'

echo ""
echo "✅ Login API test completed!"
echo ""
echo "Expected response should include:"
echo "- success: true"
echo "- token: JWT token"
echo "- apiCredentials.userId: User ID (e.g., U1234567)"
echo "- apiCredentials.apiKey: API Key (32-character hex)"
echo ""
echo "To test with the generated credentials:"
echo "1. Copy the userId and apiKey from the response above"
echo "2. Use them in other API calls"
echo ""
echo "Example:"
echo "curl -X GET 'http://localhost:5000/api/auth/user/USER_ID_HERE'"
echo "curl -X GET 'http://localhost:5000/api/auth/api-key/API_KEY_HERE'" 