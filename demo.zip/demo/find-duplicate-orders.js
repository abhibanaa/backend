const mongoose = require('mongoose');
const PaidKundli = require('./models/PaidKundli');
const User = require('./models/User');

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/astrology_app', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

async function findAndRemoveDuplicates() {
  try {
    console.log('🔍 Searching for duplicate orders...');
    
    // Find all orders
    const allOrders = await PaidKundli.find({}).populate('user', 'user_uni_id');
    
    console.log(`📊 Total orders found: ${allOrders.length}`);
    
    // Group orders by user and order_for
    const orderGroups = {};
    
    allOrders.forEach(order => {
      const key = `${order.user.user_uni_id}_${order.order_for}`;
      if (!orderGroups[key]) {
        orderGroups[key] = [];
      }
      orderGroups[key].push(order);
    });
    
    // Find duplicates
    let totalDuplicates = 0;
    let removedDuplicates = 0;
    
    for (const [key, orders] of Object.entries(orderGroups)) {
      if (orders.length > 1) {
        console.log(`\n🔴 Found ${orders.length} orders for ${key}:`);
        
        // Sort by creation time (newest first)
        orders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        
        // Keep the newest order, remove the rest
        const [newestOrder, ...duplicates] = orders;
        
        console.log(`✅ Keeping newest order: ${newestOrder._id} (${newestOrder.createdAt})`);
        
        for (const duplicate of duplicates) {
          console.log(`🗑️  Removing duplicate: ${duplicate._id} (${duplicate.createdAt})`);
          await PaidKundli.findByIdAndDelete(duplicate._id);
          removedDuplicates++;
        }
        
        totalDuplicates += duplicates.length;
      }
    }
    
    console.log(`\n📈 Summary:`);
    console.log(`- Total duplicate orders found: ${totalDuplicates}`);
    console.log(`- Duplicate orders removed: ${removedDuplicates}`);
    console.log(`- Remaining orders: ${allOrders.length - removedDuplicates}`);
    
  } catch (error) {
    console.error('❌ Error:', error);
  } finally {
    mongoose.connection.close();
  }
}

findAndRemoveDuplicates(); 