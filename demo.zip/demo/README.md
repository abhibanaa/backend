# Astrology App Backend API

A comprehensive Node.js + Express backend for an Astrology App with Kundali Generator, Horoscope, Panchang, Numerology, and Kundali Matching modules.

## 🚀 Features

- **Kundali Generator**: Create and manage birth charts with planetary positions
- **Kundali Matching**: Compatibility analysis between two people (Gun Milan)
- **Daily/Weekly Horoscope**: Zodiac-based predictions and insights
- **Panchang Calendar**: Hindu calendar with auspicious timings and festivals
- **Numerology**: Life path, destiny, and personality number calculations
- **User Authentication**: JWT-based authentication with role-based access
- **RESTful API**: Complete CRUD operations for all modules
- **MongoDB Integration**: Mongoose ODM with optimized schemas
- **Security**: Rate limiting, CORS, Helmet, and input validation
- **Error Handling**: Comprehensive error handling and logging

## 📁 Project Structure

```
/backend
│
├── controllers/
│   ├── authController.js
│   ├── kundaliController.js
│   ├── matchingController.js
│   ├── horoscopeController.js
│   ├── panchangController.js
│   └── numerologyController.js
│
├── models/
│   ├── User.js
│   ├── Kundali.js
│   ├── Matching.js
│   ├── Horoscope.js
│   ├── Panchang.js
│   └── Numerology.js
│
├── routes/
│   ├── authRoutes.js
│   ├── kundaliRoutes.js
│   ├── matchingRoutes.js
│   ├── horoscopeRoutes.js
│   ├── panchangRoutes.js
│   └── numerologyRoutes.js
│
├── middlewares/
│   ├── authMiddleware.js
│   └── errorHandler.js
│
├── config/
│   └── db.js
│
├── utils/
│   └── errorResponse.js
│
├── app.js
├── server.js
├── package.json
└── README.md
```

## 🛠️ Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd astrology-app-backend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Environment Setup**
   Create a `.env` file in the root directory:
   ```env
   PORT=5000
   MONGO_URI=mongodb://localhost:27017/astroApp
   JWT_SECRET=supersecurejwtkey123456789
   NODE_ENV=development
   JWT_EXPIRE=7d
   ```

4. **Start MongoDB**
   Make sure MongoDB is running on your system or use MongoDB Atlas.

5. **Run the application**
   ```bash
   # Development mode
   npm run dev
   
   # Production mode
   npm start
   ```

## 📚 API Documentation

### Base URL
```
http://localhost:5000/api
```

### Authentication Endpoints

#### Register User
```http
POST /api/auth/register
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password123",
  "phone": "+1234567890",
  "dateOfBirth": "1990-01-01",
  "timeOfBirth": "10:30",
  "placeOfBirth": "New York"
}
```

#### Login User (OTP-based)
```http
POST /api/auth/send-otp
Content-Type: application/json

{
  "phone": "+1234567890"
}
```

```http
POST /api/auth/login
Content-Type: application/json

{
  "phone": "+1234567890",
  "otp": "333661"
}
```

**Response:**
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "needsRegistration": true,
  "user": {
    "id": "user_id",
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "+1234567890",
    "isProfileComplete": false,
    "role": "user",
    "dateOfBirth": "1990-01-01",
    "timeOfBirth": "10:30",
    "placeOfBirth": "New York"
  }
}
```

**Key Fields:**
- `needsRegistration`: `true` if user needs to complete profile, `false` if profile is complete
- `isProfileComplete`: Profile completion status
- If `needsRegistration` is `true`, redirect to registration screen
- If `needsRegistration` is `false`, redirect to home screen

#### Get Profile
```http
GET /api/auth/me
Authorization: Bearer <token>
```

#### Update Profile (with Image Upload)
```http
PUT /api/auth/updatedetails
Authorization: Bearer <token>
Content-Type: multipart/form-data

Form Data:
- name: "John Doe"
- email: "john@example.com"
- dateOfBirth: "1990-01-01"
- timeOfBirth: "10:30"
- placeOfBirth: "New York"
- profileImage: [image file]
```

**Response:**
```json
{
  "success": true,
  "message": "Profile completed successfully!",
  "data": {
    "id": "user_id",
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "+1234567890",
    "profileImage": "/uploads/profileImage-1234567890.jpg",
    "isProfileComplete": true,
    "role": "user"
  }
}
```

#### Get Current User Profile
```http
GET /api/auth/me
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "user_id",
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "+1234567890",
    "profileImage": "/uploads/profileImage-1234567890.jpg",
    "dateOfBirth": "1990-01-01",
    "timeOfBirth": "10:30",
    "placeOfBirth": "New York",
    "isProfileComplete": true,
    "role": "user",
    "createdAt": "2024-01-15T10:30:00.000Z",
    "updatedAt": "2024-01-15T10:30:00.000Z"
  }
}
```

### Kundali Endpoints

#### Create Kundali
```http
POST /api/kundali
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "John Doe",
  "dateOfBirth": "1990-01-01",
  "timeOfBirth": "10:30",
  "placeOfBirth": "New York",
  "latitude": 40.7128,
  "longitude": -74.0060
}
```

#### Get All Kundalis
```http
GET /api/kundali
Authorization: Bearer <token>
```

#### Get Kundali by ID
```http
GET /api/kundali/:id
Authorization: Bearer <token>
```

### Horoscope Endpoints

#### Get Daily Horoscope
```http
GET /api/horoscope/daily
```

#### Get Horoscope by Zodiac and Type
```http
GET /api/horoscope/Aries/daily
```

#### Generate Personalized Horoscope
```http
POST /api/horoscope/personalized
Authorization: Bearer <token>
Content-Type: application/json

{
  "zodiacSign": "Aries",
  "type": "daily",
  "date": "2024-01-15"
}
```

### Panchang Endpoints

#### Get Today's Panchang
```http
GET /api/panchang/today?location=Mumbai
```

#### Get Muhurat (Auspicious Timings)
```http
GET /api/panchang/muhurat/2024-01-15?location=Delhi
```

#### Get Festivals
```http
GET /api/panchang/festivals?startDate=2024-01-01&endDate=2024-12-31&location=Mumbai
```

### Numerology Endpoints

#### Create Numerology Report
```http
POST /api/numerology
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "John Doe",
  "dateOfBirth": "1990-01-01"
}
```

#### Get Numerology by Life Path Number
```http
GET /api/numerology/life-path/1
```

### Matching Endpoints

#### Create Compatibility Analysis
```http
POST /api/matching
Authorization: Bearer <token>
Content-Type: application/json

{
  "person1": {
    "name": "John Doe",
    "dateOfBirth": "1990-01-01",
    "timeOfBirth": "10:30",
    "placeOfBirth": "New York"
  },
  "person2": {
    "name": "Jane Smith",
    "dateOfBirth": "1992-05-15",
    "timeOfBirth": "14:45",
    "placeOfBirth": "Los Angeles"
  },
  "relationshipType": "Marriage"
}
```

## 🔐 Authentication

The API uses JWT (JSON Web Tokens) for authentication. Include the token in the Authorization header:

```
Authorization: Bearer <your-jwt-token>
```

## 📊 Database Models

### User Model
- Basic user information
- Encrypted passwords
- JWT token generation
- Role-based access control

### Kundali Model
- Birth chart data
- Planetary positions
- House calculations
- Analysis and predictions

### Matching Model
- Compatibility scores
- Gun Milan calculations
- Relationship analysis
- Detailed reports

### Horoscope Model
- Daily/Weekly/Monthly predictions
- Zodiac-specific content
- Lucky numbers and colors
- Planetary influences

### Panchang Model
- Hindu calendar data
- Auspicious timings (Muhurat)
- Festival information
- Location-based calculations

### Numerology Model
- Core numbers (Life Path, Destiny, Soul, Personality)
- Name analysis
- Birth date calculations
- Predictions and remedies

## 🚀 Flutter Integration

This API is designed to work seamlessly with Flutter frontend using Dio HTTP client:

```dart
// Example Flutter API call
final dio = Dio();
dio.options.headers['Authorization'] = 'Bearer $token';

final response = await dio.get('http://localhost:5000/api/horoscope/daily');
```

## 📱 Flutter Integration Example

### Login Flow with Registration Check

```dart
class AuthService {
  static const String baseUrl = 'http://192.168.29.21:5000/api'; // Use your computer's IP
  
  Future<Map<String, dynamic>> login(String phone, String otp) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/auth/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'phone': phone,
          'otp': otp,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        
        // Store token
        await SharedPreferences.getInstance().then((prefs) {
          prefs.setString('token', data['token']);
          prefs.setString('user', jsonEncode(data['user']));
        });

        return {
          'success': true,
          'needsRegistration': data['needsRegistration'],
          'user': data['user'],
        };
      } else {
        return {
          'success': false,
          'message': 'Login failed',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Network error: $e',
      };
    }
  }
}

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final AuthService _authService = AuthService();
  String phone = '';
  String otp = '';

  Future<void> _login() async {
    final result = await _authService.login(phone, otp);
    
    if (result['success']) {
      if (result['needsRegistration']) {
        // Navigate to registration screen
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => RegistrationScreen()),
        );
      } else {
        // Navigate to home screen
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomeScreen()),
        );
      }
    } else {
      // Show error message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result['message'])),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              decoration: InputDecoration(labelText: 'Phone Number'),
              onChanged: (value) => phone = value,
            ),
            SizedBox(height: 16),
            TextField(
              decoration: InputDecoration(labelText: 'OTP (use: 333661)'),
              onChanged: (value) => otp = value,
            ),
            SizedBox(height: 24),
            ElevatedButton(
              onPressed: _login,
              child: Text('Login'),
            ),
          ],
        ),
      ),
    );
  }
}

### Registration Screen Example (with Image Upload)

```dart
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class RegistrationScreen extends StatefulWidget {
  @override
  _RegistrationScreenState createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final _formKey = GlobalKey<FormState>();
  final ImagePicker _picker = ImagePicker();
  
  String name = '';
  String email = '';
  String dateOfBirth = '';
  String timeOfBirth = '';
  String placeOfBirth = '';
  File? _imageFile;

  Future<void> _pickImage() async {
    final XFile? image = await _picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 512,
      maxHeight: 512,
      imageQuality: 80,
    );
    
    if (image != null) {
      setState(() {
        _imageFile = File(image.path);
      });
    }
  }

  Future<void> _takePhoto() async {
    final XFile? image = await _picker.pickImage(
      source: ImageSource.camera,
      maxWidth: 512,
      maxHeight: 512,
      imageQuality: 80,
    );
    
    if (image != null) {
      setState(() {
        _imageFile = File(image.path);
      });
    }
  }

  Future<void> _completeRegistration() async {
    if (_formKey.currentState!.validate()) {
      if (_imageFile == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Please select a profile image')),
        );
        return;
      }

      // Call update details API with image
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('token');
      
      try {
        // Create multipart request
        var request = http.MultipartRequest(
          'PUT',
          Uri.parse('$baseUrl/auth/updatedetails'),
        );
        
        // Add headers
        request.headers['Authorization'] = 'Bearer $token';
        
        // Add text fields
        request.fields['name'] = name;
        request.fields['email'] = email;
        request.fields['dateOfBirth'] = dateOfBirth;
        request.fields['timeOfBirth'] = timeOfBirth;
        request.fields['placeOfBirth'] = placeOfBirth;
        
        // Add image file
        request.files.add(
          await http.MultipartFile.fromPath(
            'profileImage',
            _imageFile!.path,
          ),
        );
        
        final response = await request.send();
        final responseData = await response.stream.bytesToString();
        final result = jsonDecode(responseData);

        if (response.statusCode == 200) {
          // Navigate to home screen
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => HomeScreen()),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(result['message'] ?? 'Registration failed')),
          );
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Registration failed: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Complete Registration')),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16.0),
          child: Column(
            children: [
              // Profile Image Section
              Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.grey, width: 2),
                ),
                child: _imageFile != null
                    ? ClipOval(
                        child: Image.file(
                          _imageFile!,
                          fit: BoxFit.cover,
                        ),
                      )
                    : Icon(Icons.person, size: 60, color: Colors.grey),
              ),
              SizedBox(height: 16),
              
              // Image Selection Buttons
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton.icon(
                    onPressed: _pickImage,
                    icon: Icon(Icons.photo_library),
                    label: Text('Gallery'),
                  ),
                  ElevatedButton.icon(
                    onPressed: _takePhoto,
                    icon: Icon(Icons.camera_alt),
                    label: Text('Camera'),
                  ),
                ],
              ),
              SizedBox(height: 24),
              
              // Form Fields
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'Full Name',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty ? 'Name is required' : null,
                onChanged: (value) => name = value,
              ),
              SizedBox(height: 16),
              
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty ? 'Email is required' : null,
                onChanged: (value) => email = value,
              ),
              SizedBox(height: 16),
              
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'Date of Birth (YYYY-MM-DD)',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty ? 'Date of birth is required' : null,
                onChanged: (value) => dateOfBirth = value,
              ),
              SizedBox(height: 16),
              
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'Time of Birth (HH:MM)',
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) => timeOfBirth = value,
              ),
              SizedBox(height: 16),
              
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'Place of Birth',
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) => placeOfBirth = value,
              ),
              SizedBox(height: 24),
              
              ElevatedButton(
                onPressed: _completeRegistration,
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(double.infinity, 50),
                ),
                child: Text('Complete Registration'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
```

### Required Dependencies for Flutter

Add these to your `pubspec.yaml`:

```yaml
dependencies:
  flutter:
    sdk: flutter
  http: ^1.1.0
  image_picker: ^1.0.4
  shared_preferences: ^2.2.2
```

## 📱 Flutter Registration Data Management

### Complete AuthService Class

```dart
import 'dart:io';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';

class AuthService {
  static const String baseUrl = 'http://192.168.29.21:5000/api'; // Use your computer's IP
  
  // Get stored token
  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }
  
  // Save user data locally
  static Future<void> saveUserData(Map<String, dynamic> userData) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user', jsonEncode(userData));
  }
  
  // Get user data from local storage
  static Future<Map<String, dynamic>?> getUserData() async {
    final prefs = await SharedPreferences.getInstance();
    final userString = prefs.getString('user');
    if (userString != null) {
      return jsonDecode(userString);
    }
    return null;
  }

  // Login with OTP
  Future<Map<String, dynamic>> login(String phone, String otp) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/auth/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'phone': phone,
          'otp': otp,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        
        // Store token and user data
        await SharedPreferences.getInstance().then((prefs) {
          prefs.setString('token', data['token']);
          prefs.setString('user', jsonEncode(data['user']));
        });

        return {
          'success': true,
          'needsRegistration': data['needsRegistration'],
          'user': data['user'],
        };
      } else {
        final errorData = jsonDecode(response.body);
        return {
          'success': false,
          'message': errorData['message'] ?? 'Login failed',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Network error: $e',
      };
    }
  }

  // Get current user profile
  Future<Map<String, dynamic>> getProfile() async {
    try {
      final token = await getToken();
      if (token == null) {
        return {
          'success': false,
          'message': 'No token found. Please login again.',
        };
      }

      final response = await http.get(
        Uri.parse('$baseUrl/auth/me'),
        headers: {
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        
        // Update local storage with fresh data
        await saveUserData(data['data']);
        
        return {
          'success': true,
          'user': data['data'],
        };
      } else {
        return {
          'success': false,
          'message': 'Failed to fetch profile',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Network error: $e',
      };
    }
  }

  // Update profile with image
  Future<Map<String, dynamic>> updateProfile({
    required String name,
    required String email,
    required String dateOfBirth,
    String? timeOfBirth,
    String? placeOfBirth,
    File? profileImage,
  }) async {
    try {
      final token = await getToken();
      if (token == null) {
        return {
          'success': false,
          'message': 'No token found. Please login again.',
        };
      }

      // Create multipart request
      var request = http.MultipartRequest(
        'PUT',
        Uri.parse('$baseUrl/auth/updatedetails'),
      );
      
      // Add headers
      request.headers['Authorization'] = 'Bearer $token';
      
      // Add text fields
      request.fields['name'] = name;
      request.fields['email'] = email;
      request.fields['dateOfBirth'] = dateOfBirth;
      if (timeOfBirth != null) request.fields['timeOfBirth'] = timeOfBirth;
      if (placeOfBirth != null) request.fields['placeOfBirth'] = placeOfBirth;
      
      // Add image file if provided
      if (profileImage != null) {
        request.files.add(
          await http.MultipartFile.fromPath(
            'profileImage',
            profileImage.path,
          ),
        );
      }
      
      final response = await request.send();
      final responseData = await response.stream.bytesToString();
      final result = jsonDecode(responseData);

      if (response.statusCode == 200) {
        // Update local storage with new data
        await saveUserData(result['data']);
        
        return {
          'success': true,
          'message': result['message'],
          'user': result['data'],
        };
      } else {
        return {
          'success': false,
          'message': result['message'] ?? 'Profile update failed',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Network error: $e',
      };
    }
  }

  // Logout
  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
    await prefs.remove('user');
  }

  // Check if user is logged in
  Future<bool> isLoggedIn() async {
    final token = await getToken();
    return token != null;
  }

  // Check if profile is complete
  Future<bool> isProfileComplete() async {
    final userData = await getUserData();
    return userData?['isProfileComplete'] ?? false;
  }
}
```

### Profile Management Screen

```dart
class ProfileScreen extends StatefulWidget {
  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final AuthService _authService = AuthService();
  final ImagePicker _picker = ImagePicker();
  
  Map<String, dynamic>? _userData;
  bool _isLoading = true;
  File? _selectedImage;
  
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _emailController;
  late TextEditingController _dateOfBirthController;
  late TextEditingController _timeOfBirthController;
  late TextEditingController _placeOfBirthController;

  @override
  void initState() {
    super.initState();
    _initializeControllers();
    _loadProfile();
  }

  void _initializeControllers() {
    _nameController = TextEditingController();
    _emailController = TextEditingController();
    _dateOfBirthController = TextEditingController();
    _timeOfBirthController = TextEditingController();
    _placeOfBirthController = TextEditingController();
  }

  Future<void> _loadProfile() async {
    setState(() => _isLoading = true);
    
    final result = await _authService.getProfile();
    
    if (result['success']) {
      setState(() {
        _userData = result['user'];
        _populateControllers();
        _isLoading = false;
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result['message'])),
      );
      setState(() => _isLoading = false);
    }
  }

  void _populateControllers() {
    if (_userData != null) {
      _nameController.text = _userData!['name'] ?? '';
      _emailController.text = _userData!['email'] ?? '';
      _dateOfBirthController.text = _userData!['dateOfBirth'] ?? '';
      _timeOfBirthController.text = _userData!['timeOfBirth'] ?? '';
      _placeOfBirthController.text = _userData!['placeOfBirth'] ?? '';
    }
  }

  Future<void> _pickImage() async {
    final XFile? image = await _picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 512,
      maxHeight: 512,
      imageQuality: 80,
    );
    
    if (image != null) {
      setState(() {
        _selectedImage = File(image.path);
      });
    }
  }

  Future<void> _saveProfile() async {
    if (_formKey.currentState!.validate()) {
      setState(() => _isLoading = true);
      
      final result = await _authService.updateProfile(
        name: _nameController.text,
        email: _emailController.text,
        dateOfBirth: _dateOfBirthController.text,
        timeOfBirth: _timeOfBirthController.text,
        placeOfBirth: _placeOfBirthController.text,
        profileImage: _selectedImage,
      );
      
      setState(() => _isLoading = false);
      
      if (result['success']) {
        setState(() {
          _userData = result['user'];
          _selectedImage = null;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(result['message'])),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(result['message'])),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        appBar: AppBar(title: Text('Profile')),
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Profile'),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: _loadProfile,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // Profile Image Section
              Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.grey, width: 2),
                ),
                child: _selectedImage != null
                    ? ClipOval(
                        child: Image.file(
                          _selectedImage!,
                          fit: BoxFit.cover,
                        ),
                      )
                    : _userData?['profileImage'] != null
                        ? ClipOval(
                            child: Image.network(
                              'http://192.168.29.21:5000${_userData!['profileImage']}',
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) {
                                return Icon(Icons.person, size: 60, color: Colors.grey);
                              },
                            ),
                          )
                        : Icon(Icons.person, size: 60, color: Colors.grey),
              ),
              SizedBox(height: 16),
              
              ElevatedButton.icon(
                onPressed: _pickImage,
                icon: Icon(Icons.photo_library),
                label: Text('Change Photo'),
              ),
              SizedBox(height: 24),
              
              // Form Fields
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(
                  labelText: 'Full Name',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty ? 'Name is required' : null,
              ),
              SizedBox(height: 16),
              
              TextFormField(
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty ? 'Email is required' : null,
              ),
              SizedBox(height: 16),
              
              TextFormField(
                controller: _dateOfBirthController,
                decoration: InputDecoration(
                  labelText: 'Date of Birth (YYYY-MM-DD)',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty ? 'Date of birth is required' : null,
              ),
              SizedBox(height: 16),
              
              TextFormField(
                controller: _timeOfBirthController,
                decoration: InputDecoration(
                  labelText: 'Time of Birth (HH:MM)',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 16),
              
              TextFormField(
                controller: _placeOfBirthController,
                decoration: InputDecoration(
                  labelText: 'Place of Birth',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 24),
              
              ElevatedButton(
                onPressed: _saveProfile,
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(double.infinity, 50),
                ),
                child: Text('Save Profile'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _dateOfBirthController.dispose();
    _timeOfBirthController.dispose();
    _placeOfBirthController.dispose();
    super.dispose();
  }
}
```

### Main App with Navigation

```dart
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Astrology App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: AuthWrapper(),
    );
  }
}

class AuthWrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: AuthService().isLoggedIn(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        
        if (snapshot.data == true) {
          return FutureBuilder<bool>(
            future: AuthService().isProfileComplete(),
            builder: (context, profileSnapshot) {
              if (profileSnapshot.data == true) {
                return HomeScreen();
              } else {
                return RegistrationScreen();
              }
            },
          );
        } else {
          return LoginScreen();
        }
      },
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Astrology App'),
        actions: [
          IconButton(
            icon: Icon(Icons.person),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProfileScreen()),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () async {
              await AuthService().logout();
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => LoginScreen()),
              );
            },
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Welcome to Astrology App!', style: TextStyle(fontSize: 24)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ProfileScreen()),
                );
              },
              child: Text('View Profile'),
            ),
          ],
        ),
      ),
    );
  }
}
```

## 🔧 Configuration

### Environment Variables
- `PORT`: Server port (default: 5000)
- `MONGO_URI`: MongoDB connection string
- `JWT_SECRET`: Secret key for JWT tokens
- `NODE_ENV`: Environment (development/production)
- `JWT_EXPIRE`: JWT token expiration time

### Rate Limiting
- 100 requests per 15 minutes per IP
- Configurable in `app.js`

### CORS
- Configured for development and production
- Update origins in `app.js` for your domains

## 📝 Sample Data

### Sample Horoscope
```json
{
  "type": "daily",
  "date": "2024-01-15",
  "zodiacSign": "Aries",
  "content": {
    "general": "Today brings new opportunities for leadership and innovation.",
    "love": "Romantic relationships flourish with open communication.",
    "career": "Take initiative in professional matters.",
    "health": "Focus on physical exercise and stress management."
  },
  "lucky": {
    "number": [1, 9],
    "color": ["Red", "Orange"],
    "day": ["Tuesday", "Sunday"],
    "time": "10:00 AM"
  }
}
```

### Sample Panchang
```json
{
  "date": "2024-01-15",
  "location": {
    "name": "Mumbai",
    "latitude": 19.0760,
    "longitude": 72.8777
  },
  "tithi": {
    "name": "Dwitiya",
    "number": 2
  },
  "vara": "Monday",
  "nakshatra": {
    "name": "Rohini",
    "number": 4
  },
  "muhurat": {
    "sunrise": "2024-01-15T06:45:00.000Z",
    "sunset": "2024-01-15T18:15:00.000Z",
    "brahmaMuhurat": {
      "start": "2024-01-15T05:15:00.000Z",
      "end": "2024-01-15T06:15:00.000Z"
    }
  }
}
```

## 🧪 Testing

### Health Check
```bash
curl http://localhost:5000/health
```

### API Documentation
```bash
curl http://localhost:5000/api
```

## 🚀 Deployment

### Local Development
```bash
npm run dev
```

### Production
```bash
npm start
```

### Docker (Optional)
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 5000
CMD ["npm", "start"]
```

## 📞 Support

For support and questions:
- Create an issue in the repository
- Contact the development team
- Check the API documentation at `/api` endpoint

## 📄 License

This project is licensed under the ISC License.

## 🔄 Version History

- **v1.0.0**: Initial release with all core modules
- Complete CRUD operations
- JWT authentication
- MongoDB integration
- Comprehensive error handling 