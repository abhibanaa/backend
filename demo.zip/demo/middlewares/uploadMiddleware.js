const multer = require('multer');
const path = require('path');

// Configure storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    // Create unique filename with timestamp
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

// File filter
const fileFilter = (req, file, cb) => {
  console.log('=== FILE UPLOAD DEBUG ===');
  console.log('File upload attempt:', {
    fieldname: file.fieldname,
    originalname: file.originalname,
    mimetype: file.mimetype,
    size: file.size,
    encoding: file.encoding,
    buffer: file.buffer ? 'Buffer present' : 'No buffer'
  });
  
  console.log('Request headers:', {
    'content-type': req.headers['content-type'],
    'content-length': req.headers['content-length'],
    'user-agent': req.headers['user-agent']
  });
  
  // More flexible image detection
  const isImage = 
    file.mimetype.startsWith('image/') ||
    file.mimetype === 'application/octet-stream' ||
    file.mimetype === 'binary/octet-stream' ||
    /\.(jpg|jpeg|png|gif|webp|bmp|tiff)$/i.test(file.originalname);
  
  if (isImage) {
    console.log('✅ Image file accepted:', file.originalname, 'MIME:', file.mimetype);
    cb(null, true);
  } else {
    console.log('❌ File rejected - not an image:', file.mimetype);
    console.log('Expected MIME types: image/jpeg, image/png, image/gif, image/webp');
    console.log('Or file extensions: .jpg, .jpeg, .png, .gif, .webp, .bmp, .tiff');
    cb(new Error('Only image files are allowed! Supported formats: JPG, PNG, GIF, WEBP. Received: ' + file.mimetype), false);
  }
};

// Configure multer
const upload = multer({
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  },
  fileFilter: fileFilter
});

// Single file upload middleware
const uploadSingle = upload.single('profileImage');

// Middleware to handle upload errors
const handleUpload = (req, res, next) => {
  console.log('=== UPLOAD MIDDLEWARE CALLED ===');
  console.log('Request method:', req.method);
  console.log('Request URL:', req.url);
  console.log('Request headers:', req.headers);
  console.log('Request body keys:', Object.keys(req.body || {}));
  
  uploadSingle(req, res, function (err) {
    if (err instanceof multer.MulterError) {
      // Multer error
      console.log('❌ Multer error:', err);
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({
          success: false,
          message: 'File size too large. Maximum size is 5MB.'
        });
      }
      return res.status(400).json({
        success: false,
        message: 'File upload error: ' + err.message
      });
    } else if (err) {
      // Other errors
      console.log('❌ Upload error:', err.message);
      return res.status(400).json({
        success: false,
        message: err.message
      });
    }
    
    // Log successful upload
    if (req.file) {
      console.log('✅ File uploaded successfully:', {
        filename: req.file.filename,
        originalname: req.file.originalname,
        mimetype: req.file.mimetype,
        size: req.file.size,
        path: req.file.path
      });
    } else {
      console.log('⚠️ No file uploaded');
    }
    
    console.log('=== UPLOAD MIDDLEWARE COMPLETE ===');
    next();
  });
};

module.exports = {
  upload,
  handleUpload
}; 