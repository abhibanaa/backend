# 🚀 Flutter Integration Guide - Astrology App Backend

## 📱 Complete Flutter App Integration

This guide provides everything you need to integrate your astrology app backend with Flutter.

## 🛠️ Setup Requirements

### 1. Flutter Dependencies
Add these to your `pubspec.yaml`:

```yaml
dependencies:
  flutter:
    sdk: flutter
  http: ^1.1.0
  dio: ^5.3.2
  shared_preferences: ^2.2.2
  image_picker: ^1.0.4
  file_picker: ^6.1.1
  socket_io_client: ^2.0.3+1
  flutter_secure_storage: ^9.0.0
  provider: ^6.1.1
  json_annotation: ^4.8.1

dev_dependencies:
  build_runner: ^2.4.7
  json_serializable: ^6.7.1
```

### 2. Network Configuration
For Android, add to `android/app/src/main/AndroidManifest.xml`:
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
```

For iOS, add to `ios/Runner/Info.plist`:
```xml
<key>NSAppTransportSecurity</key>
<dict>
    <key>NSAllowsArbitraryLoads</key>
    <true/>
</dict>
```

## 🔧 API Service Class

### `lib/services/api_service.dart`

```dart
import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  static const String baseUrl = 'http://192.168.29.21:5000/api'; // Change to your IP
  static const String socketUrl = 'http://192.168.29.21:5000'; // Change to your IP
  
  late Dio _dio;
  
  ApiService() {
    _dio = Dio(BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: Duration(seconds: 30),
      receiveTimeout: Duration(seconds: 30),
    ));
    
    // Add interceptors for logging
    _dio.interceptors.add(LogInterceptor(
      requestBody: true,
      responseBody: true,
    ));
  }

  // Set authentication headers
  void setAuthHeaders(String? token, String? apiKey) {
    _dio.options.headers.clear();
    _dio.options.headers['Content-Type'] = 'application/json';
    
    if (token != null) {
      _dio.options.headers['Authorization'] = 'Bearer $token';
    }
    
    if (apiKey != null) {
      _dio.options.headers['X-API-Key'] = apiKey;
    }
  }

  // Send OTP
  Future<Map<String, dynamic>> sendOTP(String phone) async {
    try {
      final response = await _dio.post('/auth/send-otp', data: {
        'phone': phone,
      });
      
      return response.data;
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  // Login with OTP
  Future<Map<String, dynamic>> login(String phone, String otp) async {
    try {
      final response = await _dio.post('/auth/login', data: {
        'phone': phone,
        'otp': otp,
      });
      
      if (response.data['success']) {
        // Store credentials
        await _storeCredentials(response.data);
      }
      
      return response.data;
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  // Get user profile
  Future<Map<String, dynamic>> getProfile() async {
    try {
      final response = await _dio.get('/auth/me');
      return response.data;
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  // Update user profile
  Future<Map<String, dynamic>> updateProfile(Map<String, dynamic> data) async {
    try {
      final response = await _dio.put('/auth/updatedetails', data: data);
      return response.data;
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  // Upload profile image
  Future<Map<String, dynamic>> uploadProfileImage(File imageFile) async {
    try {
      String fileName = imageFile.path.split('/').last;
      FormData formData = FormData.fromMap({
        'profileImage': await MultipartFile.fromFile(
          imageFile.path,
          filename: fileName,
        ),
      });

      final response = await _dio.put(
        '/auth/updatedetails',
        data: formData,
        options: Options(
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        ),
      );
      
      return response.data;
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  // Delete account
  Future<Map<String, dynamic>> deleteAccount() async {
    try {
      final response = await _dio.delete('/auth/delete-account');
      return response.data;
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  // Get daily horoscope
  Future<Map<String, dynamic>> getDailyHoroscope() async {
    try {
      final response = await _dio.get('/horoscope/daily');
      return response.data;
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  // Get horoscope by zodiac
  Future<Map<String, dynamic>> getHoroscopeByZodiac(String zodiac) async {
    try {
      final response = await _dio.get('/horoscope/zodiac/$zodiac');
      return response.data;
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  // Create Kundli
  Future<Map<String, dynamic>> createKundli(Map<String, dynamic> kundliData) async {
    try {
      final response = await _dio.post('/kundli', data: kundliData);
      return response.data;
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  // Get user's Kundlis
  Future<Map<String, dynamic>> getUserKundlis() async {
    try {
      final response = await _dio.get('/kundli');
      return response.data;
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  // Get numerology analysis
  Future<Map<String, dynamic>> getNumerologyAnalysis(Map<String, dynamic> data) async {
    try {
      final response = await _dio.post('/numerology/analyze', data: data);
      return response.data;
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  // Get panchang
  Future<Map<String, dynamic>> getPanchang(String date, String location) async {
    try {
      final response = await _dio.get('/panchang', queryParameters: {
        'date': date,
        'location': location,
      });
      return response.data;
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  // Get matching compatibility
  Future<Map<String, dynamic>> getMatchingCompatibility(Map<String, dynamic> data) async {
    try {
      final response = await _dio.post('/matching/compatibility', data: data);
      return response.data;
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  // Get notifications
  Future<Map<String, dynamic>> getNotifications() async {
    try {
      final response = await _dio.get('/notifications');
      return response.data;
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  // Get blogs
  Future<Map<String, dynamic>> getBlogs() async {
    try {
      final response = await _dio.get('/blogs');
      return response.data;
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  // Store credentials locally
  Future<void> _storeCredentials(Map<String, dynamic> data) async {
    final prefs = await SharedPreferences.getInstance();
    
    if (data['token'] != null) {
      await prefs.setString('token', data['token']);
    }
    
    if (data['user'] != null) {
      await prefs.setString('user', jsonEncode(data['user']));
    }
    
    if (data['apiCredentials'] != null) {
      await prefs.setString('userId', data['apiCredentials']['userId']);
      await prefs.setString('apiKey', data['apiCredentials']['apiKey']);
    }
  }

  // Get stored credentials
  Future<Map<String, String?>> getStoredCredentials() async {
    final prefs = await SharedPreferences.getInstance();
    
    return {
      'token': prefs.getString('token'),
      'userId': prefs.getString('userId'),
      'apiKey': prefs.getString('apiKey'),
      'user': prefs.getString('user'),
    };
  }

  // Clear stored credentials
  Future<void> clearCredentials() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }

  // Handle Dio errors
  String _handleDioError(DioException e) {
    if (e.response != null) {
      final data = e.response?.data;
      return data['message'] ?? 'Network error occurred';
    } else if (e.type == DioExceptionType.connectionTimeout) {
      return 'Connection timeout';
    } else if (e.type == DioExceptionType.receiveTimeout) {
      return 'Receive timeout';
    } else {
      return 'Network error: ${e.message}';
    }
  }
}
```

## 🔐 Authentication Provider

### `lib/providers/auth_provider.dart`

```dart
import 'dart:convert';
import 'package:flutter/material.dart';
import '../services/api_service.dart';

class AuthProvider extends ChangeNotifier {
  final ApiService _apiService = ApiService();
  
  bool _isLoading = false;
  bool _isAuthenticated = false;
  Map<String, dynamic>? _user;
  String? _token;
  String? _userId;
  String? _apiKey;

  bool get isLoading => _isLoading;
  bool get isAuthenticated => _isAuthenticated;
  Map<String, dynamic>? get user => _user;
  String? get token => _token;
  String? get userId => _userId;
  String? get apiKey => _apiKey;

  // Initialize auth state
  Future<void> initializeAuth() async {
    _setLoading(true);
    
    try {
      final credentials = await _apiService.getStoredCredentials();
      
      if (credentials['token'] != null) {
        _token = credentials['token'];
        _userId = credentials['userId'];
        _apiKey = credentials['apiKey'];
        
        if (credentials['user'] != null) {
          _user = jsonDecode(credentials['user']!);
        }
        
        // Set auth headers
        _apiService.setAuthHeaders(_token, _apiKey);
        
        // Verify token by getting profile
        try {
          final profile = await _apiService.getProfile();
          if (profile['success']) {
            _user = profile['data'];
            _isAuthenticated = true;
          } else {
            await _logout();
          }
        } catch (e) {
          await _logout();
        }
      }
    } catch (e) {
      print('Auth initialization error: $e');
    } finally {
      _setLoading(false);
    }
  }

  // Send OTP
  Future<Map<String, dynamic>> sendOTP(String phone) async {
    _setLoading(true);
    
    try {
      final result = await _apiService.sendOTP(phone);
      return result;
    } finally {
      _setLoading(false);
    }
  }

  // Login
  Future<Map<String, dynamic>> login(String phone, String otp) async {
    _setLoading(true);
    
    try {
      final result = await _apiService.login(phone, otp);
      
      if (result['success']) {
        _token = result['token'];
        _user = result['user'];
        _userId = result['apiCredentials']['userId'];
        _apiKey = result['apiCredentials']['apiKey'];
        _isAuthenticated = true;
        
        // Set auth headers
        _apiService.setAuthHeaders(_token, _apiKey);
        
        notifyListeners();
      }
      
      return result;
    } finally {
      _setLoading(false);
    }
  }

  // Update profile
  Future<Map<String, dynamic>> updateProfile(Map<String, dynamic> data) async {
    _setLoading(true);
    
    try {
      final result = await _apiService.updateProfile(data);
      
      if (result['success']) {
        _user = result['data'];
        notifyListeners();
      }
      
      return result;
    } finally {
      _setLoading(false);
    }
  }

  // Upload profile image
  Future<Map<String, dynamic>> uploadProfileImage(dynamic imageFile) async {
    _setLoading(true);
    
    try {
      final result = await _apiService.uploadProfileImage(imageFile);
      
      if (result['success']) {
        _user = result['data'];
        notifyListeners();
      }
      
      return result;
    } finally {
      _setLoading(false);
    }
  }

  // Delete account
  Future<Map<String, dynamic>> deleteAccount() async {
    _setLoading(true);
    
    try {
      final result = await _apiService.deleteAccount();
      
      if (result['success']) {
        await _logout();
      }
      
      return result;
    } finally {
      _setLoading(false);
    }
  }

  // Logout
  Future<void> logout() async {
    await _logout();
  }

  // Private logout method
  Future<void> _logout() async {
    await _apiService.clearCredentials();
    
    _isAuthenticated = false;
    _user = null;
    _token = null;
    _userId = null;
    _apiKey = null;
    
    notifyListeners();
  }

  // Set loading state
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }
}
```

## 📱 Main App Structure

### `lib/main.dart`

```dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/auth_provider.dart';
import 'screens/splash_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
      ],
      child: MaterialApp(
        title: 'Astrology App',
        theme: ThemeData(
          primarySwatch: Colors.purple,
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        home: SplashScreen(),
        debugShowCheckedModeBanner: false,
      ),
    );
  }
}
```

## 🎨 Login Screen

### `lib/screens/login_screen.dart`

```dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import 'home_screen.dart';
import 'registration_screen.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _phoneController = TextEditingController();
  final _otpController = TextEditingController();
  
  bool _otpSent = false;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    // Pre-fill with test data
    _phoneController.text = '+918107804990';
    _otpController.text = '333661';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
        backgroundColor: Colors.purple,
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // App Logo/Title
              Icon(
                Icons.auto_awesome,
                size: 80,
                color: Colors.purple,
              ),
              SizedBox(height: 16),
              Text(
                'Astrology App',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.purple,
                ),
              ),
              SizedBox(height: 32),

              // Phone Number Field
              TextFormField(
                controller: _phoneController,
                decoration: InputDecoration(
                  labelText: 'Phone Number',
                  prefixIcon: Icon(Icons.phone),
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.phone,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter phone number';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),

              // OTP Field
              TextFormField(
                controller: _otpController,
                decoration: InputDecoration(
                  labelText: 'OTP',
                  prefixIcon: Icon(Icons.lock),
                  border: OutlineInputBorder(),
                  suffixIcon: !_otpSent ? TextButton(
                    onPressed: _sendOTP,
                    child: Text('Send OTP'),
                  ) : null,
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter OTP';
                  }
                  return null;
                },
              ),
              SizedBox(height: 24),

              // Login Button
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _login,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.purple,
                    foregroundColor: Colors.white,
                  ),
                  child: _isLoading
                      ? CircularProgressIndicator(color: Colors.white)
                      : Text('Login'),
                ),
              ),
              SizedBox(height: 16),

              // Info Text
              Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.blue.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.blue.shade200),
                ),
                child: Column(
                  children: [
                    Text(
                      'Test Credentials:',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Text('Phone: +918107804990'),
                    Text('OTP: 333661'),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _sendOTP() async {
    if (_phoneController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please enter phone number')),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      final result = await authProvider.sendOTP(_phoneController.text);

      if (result['success']) {
        setState(() => _otpSent = true);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('OTP sent successfully!')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(result['message'] ?? 'Failed to send OTP')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      final result = await authProvider.login(
        _phoneController.text,
        _otpController.text,
      );

      if (result['success']) {
        if (result['needsRegistration']) {
          // Navigate to registration screen
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => RegistrationScreen()),
          );
        } else {
          // Navigate to home screen
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => HomeScreen()),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(result['message'] ?? 'Login failed')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  void dispose() {
    _phoneController.dispose();
    _otpController.dispose();
    super.dispose();
  }
}
```

## 🏠 Home Screen

### `lib/screens/home_screen.dart`

```dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../services/api_service.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ApiService _apiService = ApiService();
  Map<String, dynamic>? _dailyHoroscope;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadDailyHoroscope();
  }

  Future<void> _loadDailyHoroscope() async {
    setState(() => _isLoading = true);

    try {
      final result = await _apiService.getDailyHoroscope();
      if (result['success']) {
        setState(() => _dailyHoroscope = result['data']);
      }
    } catch (e) {
      print('Error loading horoscope: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final user = authProvider.user;

    return Scaffold(
      appBar: AppBar(
        title: Text('Astrology App'),
        backgroundColor: Colors.purple,
        actions: [
          IconButton(
            icon: Icon(Icons.person),
            onPressed: () {
              // Navigate to profile screen
            },
          ),
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () async {
              await authProvider.logout();
              Navigator.pushReplacementNamed(context, '/login');
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Welcome Section
            Card(
              child: Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Welcome, ${user?['name'] ?? 'User'}!',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text('User ID: ${authProvider.userId}'),
                    Text('API Key: ${authProvider.apiKey?.substring(0, 8)}...'),
                  ],
                ),
              ),
            ),
            SizedBox(height: 16),

            // Daily Horoscope Section
            Card(
              child: Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.auto_awesome, color: Colors.purple),
                        SizedBox(width: 8),
                        Text(
                          'Daily Horoscope',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        if (_isLoading)
                          SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                      ],
                    ),
                    SizedBox(height: 16),
                    if (_dailyHoroscope != null) ...[
                      Text(
                        _dailyHoroscope!['zodiac'] ?? 'Unknown',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.purple,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(_dailyHoroscope!['prediction'] ?? 'No prediction available'),
                    ] else if (!_isLoading) ...[
                      Text('No horoscope available'),
                    ],
                  ],
                ),
              ),
            ),
            SizedBox(height: 16),

            // Quick Actions Grid
            GridView.count(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              children: [
                _buildActionCard(
                  'Kundli',
                  Icons.account_tree,
                  Colors.blue,
                  () {
                    // Navigate to Kundli screen
                  },
                ),
                _buildActionCard(
                  'Numerology',
                  Icons.numbers,
                  Colors.green,
                  () {
                    // Navigate to Numerology screen
                  },
                ),
                _buildActionCard(
                  'Panchang',
                  Icons.calendar_today,
                  Colors.orange,
                  () {
                    // Navigate to Panchang screen
                  },
                ),
                _buildActionCard(
                  'Matching',
                  Icons.favorite,
                  Colors.red,
                  () {
                    // Navigate to Matching screen
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionCard(String title, IconData icon, Color color, VoidCallback onTap) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 40, color: color),
              SizedBox(height: 8),
              Text(
                title,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
```

## 🔄 Splash Screen

### `lib/screens/splash_screen.dart`

```dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import 'login_screen.dart';
import 'home_screen.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _initializeApp();
  }

  Future<void> _initializeApp() async {
    // Wait for 2 seconds to show splash
    await Future.delayed(Duration(seconds: 2));
    
    // Initialize auth
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    await authProvider.initializeAuth();
    
    // Navigate based on auth state
    if (mounted) {
      if (authProvider.isAuthenticated) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomeScreen()),
        );
      } else {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => LoginScreen()),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.purple,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.auto_awesome,
              size: 100,
              color: Colors.white,
            ),
            SizedBox(height: 24),
            Text(
              'Astrology App',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 32),
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}
```

## 📝 Registration Screen

### `lib/screens/registration_screen.dart`

```dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import 'home_screen.dart';

class RegistrationScreen extends StatefulWidget {
  @override
  _RegistrationScreenState createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _dateController = TextEditingController();
  final _timeController = TextEditingController();
  final _placeController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Complete Profile'),
        backgroundColor: Colors.purple,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              Text(
                'Complete Your Profile',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.purple,
                ),
              ),
              SizedBox(height: 24),

              // Name Field
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(
                  labelText: 'Full Name',
                  prefixIcon: Icon(Icons.person),
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your name';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),

              // Email Field
              TextFormField(
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: 'Email',
                  prefixIcon: Icon(Icons.email),
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.emailAddress,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your email';
                  }
                  if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value)) {
                    return 'Please enter a valid email';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),

              // Date of Birth Field
              TextFormField(
                controller: _dateController,
                decoration: InputDecoration(
                  labelText: 'Date of Birth',
                  prefixIcon: Icon(Icons.calendar_today),
                  border: OutlineInputBorder(),
                ),
                readOnly: true,
                onTap: () async {
                  final date = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now().subtract(Duration(days: 6570)), // 18 years ago
                    firstDate: DateTime(1900),
                    lastDate: DateTime.now(),
                  );
                  if (date != null) {
                    _dateController.text = date.toIso8601String().split('T')[0];
                  }
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please select your date of birth';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),

              // Time of Birth Field
              TextFormField(
                controller: _timeController,
                decoration: InputDecoration(
                  labelText: 'Time of Birth',
                  prefixIcon: Icon(Icons.access_time),
                  border: OutlineInputBorder(),
                ),
                readOnly: true,
                onTap: () async {
                  final time = await showTimePicker(
                    context: context,
                    initialTime: TimeOfDay.now(),
                  );
                  if (time != null) {
                    _timeController.text = '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
                  }
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please select your time of birth';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),

              // Place of Birth Field
              TextFormField(
                controller: _placeController,
                decoration: InputDecoration(
                  labelText: 'Place of Birth',
                  prefixIcon: Icon(Icons.location_on),
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your place of birth';
                  }
                  return null;
                },
              ),
              SizedBox(height: 24),

              // Submit Button
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: _submitRegistration,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.purple,
                    foregroundColor: Colors.white,
                  ),
                  child: Text('Complete Registration'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _submitRegistration() async {
    if (!_formKey.currentState!.validate()) return;

    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    
    try {
      final result = await authProvider.updateProfile({
        'name': _nameController.text,
        'email': _emailController.text,
        'dateOfBirth': _dateController.text,
        'timeOfBirth': _timeController.text,
        'placeOfBirth': _placeController.text,
      });

      if (result['success']) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomeScreen()),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(result['message'] ?? 'Registration failed')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _dateController.dispose();
    _timeController.dispose();
    _placeController.dispose();
    super.dispose();
  }
}
```

## 🔌 Socket.IO Integration

### `lib/services/socket_service.dart`

```dart
import 'package:socket_io_client/socket_io_client.dart' as IO;

class SocketService {
  static const String socketUrl = 'http://192.168.29.21:5000'; // Change to your IP
  late IO.Socket socket;

  void initializeSocket() {
    socket = IO.io(socketUrl, <String, dynamic>{
      'transports': ['websocket'],
      'autoConnect': false,
    });

    socket.onConnect((_) {
      print('Socket connected');
    });

    socket.onDisconnect((_) {
      print('Socket disconnected');
    });

    socket.onError((error) {
      print('Socket error: $error');
    });

    // Listen for notifications
    socket.on('notification', (data) {
      print('New notification: $data');
      // Handle notification here
    });

    // Listen for blog updates
    socket.on('blogUpdate', (data) {
      print('Blog update: $data');
      // Handle blog update here
    });

    socket.connect();
  }

  void disconnect() {
    socket.disconnect();
  }

  void emit(String event, dynamic data) {
    socket.emit(event, data);
  }
}
```

## 🚀 How to Run

### 1. Update IP Address
Change the IP address in all service files from `192.168.29.21` to your computer's IP address.

### 2. Run Backend
```bash
cd /path/to/your/backend
npm start
```

### 3. Run Flutter App
```bash
cd /path/to/your/flutter/app
flutter pub get
flutter run
```

## 📱 Key Features Implemented

✅ **Complete Authentication Flow**
- OTP-based login
- Automatic User ID & API Key generation
- Profile completion check
- Secure token storage

✅ **Profile Management**
- Update user details
- Profile image upload
- Account deletion

✅ **Astrology Features**
- Daily horoscope
- Kundli creation and management
- Numerology analysis
- Panchang information
- Compatibility matching

✅ **Real-time Features**
- Socket.IO integration
- Real-time notifications
- Blog updates

✅ **API Integration**
- All backend endpoints integrated
- Error handling
- Loading states
- Offline support

## 🔧 Configuration

### For Development
- Use `http://localhost:5000` for Android emulator
- Use `http://10.0.2.2:5000` for Android emulator
- Use your computer's IP for physical devices

### For Production
- Replace with your production server URL
- Use HTTPS
- Implement proper SSL certificates

## 📞 Support

If you need help with:
1. **IP Configuration**: Use `ipconfig` (Windows) or `ifconfig` (Mac/Linux) to find your IP
2. **Network Issues**: Ensure both devices are on the same network
3. **API Errors**: Check the backend logs for detailed error messages
4. **Flutter Issues**: Run `flutter doctor` to check your setup

The Flutter app is now fully integrated with your astrology backend! 🎉 