const mongoose = require('mongoose');
const User = require('./models/User');

// Connect to MongoDB Atlas (same as server)
const connectDB = async () => {
  try {
    // Use the same MongoDB Atlas connection that the server uses
    const mongoUri = 'mongodb+srv://ac-opwgnms-shard-00-02.hnwk3ow.mongodb.net';
    await mongoose.connect(mongoUri, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('MongoDB Connected to Atlas');
  } catch (error) {
    console.error('MongoDB connection error:', error);
    process.exit(1);
  }
};

// Find user by phone number
const findUserByPhone = async (phoneNumber) => {
  try {
    // Try different phone number formats
    const phoneVariations = [
      phoneNumber,
      `+91${phoneNumber}`,
      `+91-${phoneNumber}`,
      `91${phoneNumber}`,
      `91-${phoneNumber}`
    ];

    console.log('🔍 Searching for user with phone number:', phoneNumber);
    console.log('📱 Trying variations:', phoneVariations);

    for (const phone of phoneVariations) {
      const user = await User.findOne({ phone });
      if (user) {
        console.log('\n✅ User found!');
        console.log('📋 User Details:');
        console.log('   ID:', user._id);
        console.log('   Name:', user.name || 'Not set');
        console.log('   Email:', user.email || 'Not set');
        console.log('   Phone:', user.phone);
        console.log('   User ID (uni_id):', user.userId || 'Not generated yet');
        console.log('   API Key:', user.api_key || 'Not generated yet');
        console.log('   Role:', user.role);
        console.log('   Is Active:', user.isActive);
        console.log('   Profile Complete:', user.isProfileComplete);
        console.log('   Created At:', user.createdAt);
        console.log('   Updated At:', user.updatedAt);
        
        if (!user.userId || !user.api_key) {
          console.log('\n⚠️  User ID or API Key not generated yet!');
          console.log('   User needs to login first to generate credentials.');
        }
        
        return user;
      }
    }

    console.log('\n❌ User not found with any phone number variation');
    console.log('💡 User might not exist or phone number format is different');
    
    // Show all users in database for reference
    const allUsers = await User.find().select('phone name userId api_key createdAt');
    if (allUsers.length > 0) {
      console.log('\n📊 All users in database:');
      allUsers.forEach((user, index) => {
        console.log(`   ${index + 1}. Phone: ${user.phone}, Name: ${user.name || 'N/A'}, User ID: ${user.userId || 'N/A'}`);
      });
    } else {
      console.log('\n📊 No users found in database');
    }

  } catch (error) {
    console.error('❌ Error finding user:', error);
  }
};

// Main function
const main = async () => {
  await connectDB();
  
  const phoneNumber = '8107804990';
  await findUserByPhone(phoneNumber);
  
  // Close connection
  await mongoose.connection.close();
  console.log('\n🔌 Database connection closed');
};

// Run the script
main().catch(console.error); 