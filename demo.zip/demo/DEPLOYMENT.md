# Deployment Guide

This guide covers deployment options for the Astrology App Backend API.

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- MongoDB 6.0+
- Git

### Local Development
```bash
# Clone repository
git clone <repository-url>
cd astrology-app-backend

# Install dependencies
npm install

# Create environment file
cp .env.example .env
# Edit .env with your configuration

# Start development server
npm run dev
```

## 🐳 Docker Deployment

### Using Docker Compose (Recommended)
```bash
# Clone repository
git clone <repository-url>
cd astrology-app-backend

# Start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

### Using Docker only
```bash
# Build image
docker build -t astrology-api .

# Run container
docker run -d \
  --name astrology-api \
  -p 5000:5000 \
  -e MONGO_URI=mongodb://host.docker.internal:27017/astroApp \
  -e JWT_SECRET=your-secret-key \
  astrology-api
```

## ☁️ Cloud Deployment

### Heroku
```bash
# Install Heroku CLI
npm install -g heroku

# Login to Heroku
heroku login

# Create app
heroku create your-astrology-app

# Add MongoDB addon
heroku addons:create mongolab:sandbox

# Set environment variables
heroku config:set JWT_SECRET=your-secret-key
heroku config:set NODE_ENV=production

# Deploy
git push heroku main
```

### Railway
```bash
# Install Railway CLI
npm install -g @railway/cli

# Login to Railway
railway login

# Initialize project
railway init

# Deploy
railway up
```

### Render
1. Connect your GitHub repository to Render
2. Create a new Web Service
3. Set build command: `npm install`
4. Set start command: `npm start`
5. Add environment variables in Render dashboard

### DigitalOcean App Platform
1. Connect your GitHub repository
2. Create a new App
3. Select Node.js environment
4. Configure environment variables
5. Deploy

## 🗄️ Database Setup

### MongoDB Atlas (Cloud)
1. Create account at [MongoDB Atlas](https://www.mongodb.com/atlas)
2. Create new cluster
3. Set up database access (username/password)
4. Set up network access (IP whitelist)
5. Get connection string
6. Update `MONGO_URI` in environment variables

### Local MongoDB
```bash
# Install MongoDB
# Ubuntu/Debian
sudo apt-get install mongodb

# macOS
brew install mongodb-community

# Start MongoDB
sudo systemctl start mongod
# or
brew services start mongodb-community
```

## 🔧 Environment Configuration

### Required Variables
```env
PORT=5000
MONGO_URI=mongodb://localhost:27017/astroApp
JWT_SECRET=your-super-secret-key
NODE_ENV=production
JWT_EXPIRE=7d
```

### Optional Variables
```env
# Redis (for caching)
REDIS_URL=redis://localhost:6379

# Email (for notifications)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password

# File upload
CLOUDINARY_CLOUD_NAME=your-cloud-name
CLOUDINARY_API_KEY=your-api-key
CLOUDINARY_API_SECRET=your-api-secret
```

## 🔒 Security Configuration

### SSL/HTTPS Setup
```bash
# Generate SSL certificate (Let's Encrypt)
sudo certbot certonly --standalone -d yourdomain.com

# Update nginx configuration
# Add SSL certificate paths to nginx.conf
```

### Rate Limiting
- Default: 100 requests per 15 minutes per IP
- Configure in `app.js`:
```javascript
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100 // Adjust as needed
});
```

### CORS Configuration
Update CORS origins in `app.js`:
```javascript
app.use(cors({
  origin: ['https://yourdomain.com', 'https://www.yourdomain.com'],
  credentials: true
}));
```

## 📊 Monitoring & Logging

### PM2 (Process Manager)
```bash
# Install PM2
npm install -g pm2

# Start application
pm2 start server.js --name "astrology-api"

# Monitor
pm2 monit

# View logs
pm2 logs

# Restart
pm2 restart astrology-api
```

### PM2 Ecosystem File
Create `ecosystem.config.js`:
```javascript
module.exports = {
  apps: [{
    name: 'astrology-api',
    script: 'server.js',
    instances: 'max',
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    env_production: {
      NODE_ENV: 'production',
      PORT: 5000
    }
  }]
};
```

### Logging
```bash
# View application logs
tail -f logs/app.log

# View error logs
tail -f logs/error.log
```

## 🔄 CI/CD Pipeline

### GitHub Actions
Create `.github/workflows/deploy.yml`:
```yaml
name: Deploy to Production

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    
    - name: Setup Node.js
      uses: actions/setup-node@v2
      with:
        node-version: '18'
        
    - name: Install dependencies
      run: npm ci
      
    - name: Run tests
      run: npm test
      
    - name: Deploy to Heroku
      uses: akhileshns/heroku-deploy@v3.12.14
      with:
        heroku_api_key: ${{ secrets.HEROKU_API_KEY }}
        heroku_app_name: ${{ secrets.HEROKU_APP_NAME }}
        heroku_email: ${{ secrets.HEROKU_EMAIL }}
```

## 🧪 Testing

### Health Check
```bash
curl http://localhost:5000/health
```

### API Documentation
```bash
curl http://localhost:5000/api
```

### Load Testing
```bash
# Install artillery
npm install -g artillery

# Run load test
artillery run load-test.yml
```

## 📈 Performance Optimization

### Database Indexing
```javascript
// Ensure indexes are created
db.users.createIndex({ "email": 1 }, { unique: true });
db.kundalis.createIndex({ "user": 1, "dateOfBirth": 1 });
db.horoscopes.createIndex({ "zodiacSign": 1, "type": 1, "date": 1 });
```

### Caching
```javascript
// Redis caching example
const redis = require('redis');
const client = redis.createClient(process.env.REDIS_URL);

// Cache horoscope data
app.get('/api/horoscope/daily', async (req, res) => {
  const cacheKey = 'horoscope:daily:' + new Date().toDateString();
  const cached = await client.get(cacheKey);
  
  if (cached) {
    return res.json(JSON.parse(cached));
  }
  
  // Fetch from database and cache
  const horoscopes = await Horoscope.find({ type: 'daily' });
  await client.setex(cacheKey, 3600, JSON.stringify(horoscopes));
  res.json(horoscopes);
});
```

## 🚨 Troubleshooting

### Common Issues

#### MongoDB Connection Error
```bash
# Check MongoDB status
sudo systemctl status mongod

# Check connection string
echo $MONGO_URI

# Test connection
mongo $MONGO_URI
```

#### Port Already in Use
```bash
# Find process using port
lsof -i :5000

# Kill process
kill -9 <PID>
```

#### Memory Issues
```bash
# Check memory usage
pm2 monit

# Restart with more memory
pm2 restart astrology-api --max-memory-restart 1G
```

### Log Analysis
```bash
# View recent errors
grep "ERROR" logs/app.log | tail -20

# Monitor real-time logs
tail -f logs/app.log | grep -E "(ERROR|WARN)"
```

## 📞 Support

For deployment issues:
1. Check the logs: `npm run logs`
2. Verify environment variables
3. Test database connection
4. Check network connectivity
5. Review security group/firewall settings

## 🔄 Updates & Maintenance

### Updating Application
```bash
# Pull latest changes
git pull origin main

# Install new dependencies
npm install

# Restart application
pm2 restart astrology-api
# or
docker-compose restart astrology-api
```

### Database Migrations
```bash
# Backup database
mongodump --db astroApp --out backup/

# Restore database
mongorestore --db astroApp backup/astroApp/
```

### Monitoring
- Set up alerts for high CPU/memory usage
- Monitor API response times
- Track error rates
- Set up uptime monitoring 