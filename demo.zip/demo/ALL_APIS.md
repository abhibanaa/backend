# 🌟 Complete API Documentation - Astrology App Backend

## 🚀 Base URL
```
http://localhost:5000/api
```

## 🔐 Authentication
All protected routes require JWT token in Authorization header:
```
Authorization: Bearer <your-jwt-token>
```

Alternative: Use API Key in header:
```
X-API-Key: <your-api-key>
```

---

## 📱 1. AUTHENTICATION APIs

### 1.1 Send OTP
```http
POST /api/auth/send-otp
Content-Type: application/json

{
  "phone": "+918107804990"
}
```

**Response:**
```json
{
  "success": true,
  "message": "OTP sent successfully",
  "otp": "333661"
}
```

### 1.2 Login with OTP
```http
POST /api/auth/login
Content-Type: application/json

{
  "phone": "+918107804990",
  "otp": "333661"
}
```

**Response:**
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "needsRegistration": false,
  "user": {
    "id": "68788a737a98679b78228d93",
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "+918107804990",
    "isProfileComplete": true,
    "role": "user",
    "dateOfBirth": "1990-01-01T00:00:00.000Z",
    "timeOfBirth": "12:00 PM",
    "placeOfBirth": "Mumbai",
    "profileImage": "/uploads/profile.jpg"
  },
  "apiCredentials": {
    "userId": "U1234567",
    "apiKey": "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6"
  }
}
```

### 1.3 Get Current User Profile
```http
GET /api/auth/me
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "68788a737a98679b78228d93",
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "+918107804990",
    "profileImage": "/uploads/profile.jpg",
    "dateOfBirth": "1990-01-01T00:00:00.000Z",
    "timeOfBirth": "12:00 PM",
    "placeOfBirth": "Mumbai",
    "isProfileComplete": true,
    "role": "user",
    "createdAt": "2024-01-15T10:30:00.000Z",
    "updatedAt": "2024-01-15T10:30:00.000Z"
  }
}
```

### 1.4 Update User Profile
```http
PUT /api/auth/updatedetails
Authorization: Bearer <token>
Content-Type: multipart/form-data

Form Data:
- name: "John Doe"
- email: "john@example.com"
- dateOfBirth: "1990-01-01"
- timeOfBirth: "12:00 PM"
- placeOfBirth: "Mumbai"
- profileImage: [image file]
```

**Response:**
```json
{
  "success": true,
  "message": "Profile updated successfully",
  "data": {
    "id": "68788a737a98679b78228d93",
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "+918107804990",
    "profileImage": "/uploads/profileImage-1234567890.jpg",
    "isProfileComplete": true,
    "role": "user"
  }
}
```

### 1.5 Delete Account
```http
DELETE /api/auth/delete-account
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "message": "Account deleted successfully"
}
```

### 1.6 Logout
```http
POST /api/auth/logout
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "message": "Logged out successfully"
}
```

### 1.7 Admin Login
```http
POST /api/auth/admin/login
Content-Type: application/json

{
  "username": "admin123",
  "password": "admin@123"
}
```

**Response:**
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "admin_id",
    "name": "Admin User",
    "email": "admin@astrologyapp.com",
    "role": "admin"
  },
  "apiCredentials": {
    "userId": "UADMIN123",
    "apiKey": "admin_api_key_here"
  }
}
```

### 1.8 Get User by User ID
```http
GET /api/auth/user/:userId
```

**Response:**
```json
{
  "success": true,
  "data": {
    "userId": "U1234567",
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "+918107804990",
    "profileImage": "/uploads/profile.jpg",
    "isProfileComplete": true,
    "role": "user"
  }
}
```

### 1.9 Get User by API Key
```http
GET /api/auth/api-key/:apiKey
```

**Response:**
```json
{
  "success": true,
  "data": {
    "userId": "U1234567",
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "+918107804990",
    "profileImage": "/uploads/profile.jpg",
    "isProfileComplete": true,
    "role": "user"
  }
}
```

### 1.10 Regenerate API Key
```http
POST /api/auth/regenerate-api-key
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "message": "API key regenerated successfully",
  "data": {
    "userId": "U1234567",
    "apiKey": "new_api_key_here"
  }
}
```

---

## 👑 2. ADMIN APIs

### 2.1 Get Dashboard Stats
```http
GET /api/auth/admin/dashboard
Authorization: Bearer <admin-token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "totalUsers": 150,
    "activeUsers": 120,
    "completeProfiles": 85,
    "incompleteProfiles": 35,
    "recentRegistrations": [
      {
        "id": "user_id",
        "name": "John Doe",
        "email": "john@example.com",
        "createdAt": "2024-01-15T10:30:00.000Z"
      }
    ]
  }
}
```

### 2.2 Get All Users (Admin)
```http
GET /api/auth/admin/users
Authorization: Bearer <admin-token>
```

**Response:**
```json
{
  "success": true,
  "count": 150,
  "data": [
    {
      "id": "user_id",
      "name": "John Doe",
      "email": "john@example.com",
      "phone": "+918107804990",
      "role": "user",
      "isActive": true,
      "isProfileComplete": true,
      "createdAt": "2024-01-15T10:30:00.000Z"
    }
  ]
}
```

### 2.3 Create User (Admin)
```http
POST /api/auth/admin/users
Authorization: Bearer <admin-token>
Content-Type: application/json

{
  "name": "New User",
  "email": "newuser@example.com",
  "phone": "+918107804991",
  "role": "user",
  "dateOfBirth": "1990-01-01",
  "timeOfBirth": "12:00 PM",
  "placeOfBirth": "Mumbai"
}
```

### 2.4 Update User (Admin)
```http
PUT /api/auth/admin/users/:id
Authorization: Bearer <admin-token>
Content-Type: application/json

{
  "name": "Updated Name",
  "email": "updated@example.com",
  "role": "user",
  "isActive": true
}
```

### 2.5 Delete User (Admin)
```http
DELETE /api/auth/admin/users/:id
Authorization: Bearer <admin-token>
```

### 2.6 Change User Role (Admin)
```http
PUT /api/auth/admin/users/:id/role
Authorization: Bearer <admin-token>
Content-Type: application/json

{
  "role": "admin"
}
```

### 2.7 Toggle User Status (Admin)
```http
PUT /api/auth/admin/users/:id/toggle-status
Authorization: Bearer <admin-token>
```

---

## 🔮 3. HOROSCOPE APIs

### 3.1 Get Daily Horoscope
```http
GET /api/horoscope/daily
```

**Response:**
```json
{
  "success": true,
  "data": {
    "zodiac": "Aries",
    "date": "2024-01-15",
    "prediction": "Today is a great day for new beginnings...",
    "luckyNumber": 7,
    "luckyColor": "Red",
    "compatibility": "Leo"
  }
}
```

### 3.2 Get Horoscope by Zodiac and Type
```http
GET /api/horoscope/:zodiacSign/:type
```

**Example:**
```http
GET /api/horoscope/Aries/daily
GET /api/horoscope/Taurus/weekly
GET /api/horoscope/Gemini/monthly
```

### 3.3 Get All Horoscopes
```http
GET /api/horoscope
```

### 3.4 Get Specific Horoscope
```http
GET /api/horoscope/:id
```

### 3.5 Generate Personalized Horoscope
```http
POST /api/horoscope/personalized
Authorization: Bearer <token>
Content-Type: application/json

{
  "zodiacSign": "Aries",
  "type": "daily",
  "date": "2024-01-15"
}
```

### 3.6 Get Personalized Horoscopes
```http
GET /api/horoscope/personalized
Authorization: Bearer <token>
```

---

## 📊 4. KUNDALI APIs

### 4.1 Create Kundali
```http
POST /api/kundali
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "John Doe",
  "dateOfBirth": "1990-01-01",
  "timeOfBirth": "10:30",
  "placeOfBirth": "Mumbai",
  "latitude": 19.0760,
  "longitude": 72.8777,
  "gender": "Male"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "kundali_id",
    "name": "John Doe",
    "dateOfBirth": "1990-01-01T00:00:00.000Z",
    "timeOfBirth": "10:30",
    "placeOfBirth": "Mumbai",
    "zodiacSign": "Capricorn",
    "ascendant": "Libra",
    "planetaryPositions": {
      "sun": "Capricorn 15°",
      "moon": "Aquarius 8°",
      "mars": "Scorpio 22°"
    },
    "houses": {
      "house1": "Libra",
      "house2": "Scorpio",
      "house3": "Sagittarius"
    },
    "createdAt": "2024-01-15T10:30:00.000Z"
  }
}
```

### 4.2 Get All Kundalis
```http
GET /api/kundali
Authorization: Bearer <token>
```

### 4.3 Get Specific Kundali
```http
GET /api/kundali/:id
Authorization: Bearer <token>
```

### 4.4 Update Kundali
```http
PUT /api/kundali/:id
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "Updated Name",
  "placeOfBirth": "Delhi"
}
```

### 4.5 Delete Kundali
```http
DELETE /api/kundali/:id
Authorization: Bearer <token>
```

### 4.6 Analyze Kundali
```http
POST /api/kundali/:id/analyze
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "kundaliId": "kundali_id",
    "analysis": {
      "personality": "Strong and determined individual...",
      "career": "Suitable for leadership roles...",
      "health": "Generally good health...",
      "relationships": "Compatible with earth signs...",
      "luckyElements": {
        "color": "Blue",
        "number": 8,
        "day": "Saturday",
        "stone": "Sapphire"
      }
    }
  }
}
```

### 4.7 Get Kundali by Zodiac
```http
GET /api/kundali/zodiac/:sign
Authorization: Bearer <token>
```

---

## 💕 5. MATCHING APIs

### 5.1 Create Compatibility Analysis
```http
POST /api/matching
Authorization: Bearer <token>
Content-Type: application/json

{
  "person1": {
    "name": "John Doe",
    "dateOfBirth": "1990-01-01",
    "timeOfBirth": "10:30",
    "placeOfBirth": "Mumbai"
  },
  "person2": {
    "name": "Jane Smith",
    "dateOfBirth": "1992-05-15",
    "timeOfBirth": "14:45",
    "placeOfBirth": "Delhi"
  },
  "relationshipType": "Marriage"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "matching_id",
    "person1": {
      "name": "John Doe",
      "zodiac": "Capricorn",
      "ascendant": "Libra"
    },
    "person2": {
      "name": "Jane Smith",
      "zodiac": "Taurus",
      "ascendant": "Cancer"
    },
    "compatibilityScore": 85,
    "gunMilan": {
      "totalGuns": 36,
      "matchingGuns": 28,
      "percentage": 77.78
    },
    "analysis": {
      "overall": "Very good compatibility...",
      "emotional": "Strong emotional bond...",
      "physical": "Good physical compatibility...",
      "intellectual": "Excellent mental compatibility..."
    },
    "recommendations": [
      "This is a very compatible match",
      "Both partners complement each other well",
      "Good for long-term relationship"
    ]
  }
}
```

### 5.2 Get All Matchings
```http
GET /api/matching
Authorization: Bearer <token>
```

### 5.3 Get Specific Matching
```http
GET /api/matching/:id
Authorization: Bearer <token>
```

### 5.4 Update Matching
```http
PUT /api/matching/:id
Authorization: Bearer <token>
Content-Type: application/json

{
  "relationshipType": "Engagement"
}
```

### 5.5 Delete Matching
```http
DELETE /api/matching/:id
Authorization: Bearer <token>
```

### 5.6 Get Matchings by Relationship Type
```http
GET /api/matching/relationship/:type
Authorization: Bearer <token>
```

---

## 🔢 6. NUMEROLOGY APIs

### 6.1 Create Numerology Report
```http
POST /api/numerology
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "John Doe",
  "dateOfBirth": "1990-01-01",
  "phone": "8107804990"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "numerology_id",
    "name": "John Doe",
    "dateOfBirth": "1990-01-01",
    "lifePathNumber": 3,
    "destinyNumber": 7,
    "soulNumber": 5,
    "personalityNumber": 2,
    "birthDayNumber": 1,
    "analysis": {
      "lifePath": "Creative and expressive individual...",
      "destiny": "Spiritual and analytical nature...",
      "soul": "Freedom-loving and adventurous...",
      "personality": "Diplomatic and cooperative..."
    },
    "luckyElements": {
      "color": "Yellow",
      "number": 3,
      "day": "Wednesday",
      "stone": "Yellow Sapphire"
    }
  }
}
```

### 6.2 Get All Numerology Reports
```http
GET /api/numerology
Authorization: Bearer <token>
```

### 6.3 Get Specific Numerology Report
```http
GET /api/numerology/:id
Authorization: Bearer <token>
```

### 6.4 Update Numerology Report
```http
PUT /api/numerology/:id
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "Updated Name"
}
```

### 6.5 Delete Numerology Report
```http
DELETE /api/numerology/:id
Authorization: Bearer <token>
```

### 6.6 Generate Detailed Report
```http
POST /api/numerology/:id/detailed
Authorization: Bearer <token>
```

### 6.7 Get Numerology by Life Path Number
```http
GET /api/numerology/life-path/:number
```

---

## 📅 7. PANCHANG APIs

### 7.1 Get Today's Panchang
```http
GET /api/panchang/today?location=Mumbai
```

**Response:**
```json
{
  "success": true,
  "data": {
    "date": "2024-01-15",
    "location": "Mumbai",
    "tithi": "Shukla Paksha Dwadashi",
    "nakshatra": "Purva Phalguni",
    "yoga": "Shobhana",
    "karana": "Taitila",
    "muhurat": {
      "brahma": "06:00-06:48",
      "abhi": "12:00-13:30",
      "godhuli": "17:30-18:00"
    },
    "festivals": [
      "Makar Sankranti"
    ]
  }
}
```

### 7.2 Get All Panchangs
```http
GET /api/panchang
```

### 7.3 Get Specific Panchang
```http
GET /api/panchang/:id
```

### 7.4 Get Panchang by Date
```http
GET /api/panchang/date/:date?location=Mumbai
```

### 7.5 Get Panchang by Location
```http
GET /api/panchang/location/:location
```

### 7.6 Get Muhurat (Auspicious Timings)
```http
GET /api/panchang/muhurat/:date?location=Delhi
```

**Response:**
```json
{
  "success": true,
  "data": {
    "date": "2024-01-15",
    "location": "Delhi",
    "muhurat": {
      "brahma": "06:00-06:48",
      "abhi": "12:00-13:30",
      "godhuli": "17:30-18:00",
      "amrit": "09:00-10:30",
      "kaal": "15:00-16:30"
    },
    "activities": {
      "marriage": "12:00-13:30",
      "business": "09:00-10:30",
      "travel": "06:00-06:48",
      "medical": "15:00-16:30"
    }
  }
}
```

### 7.7 Get Festivals
```http
GET /api/panchang/festivals?startDate=2024-01-01&endDate=2024-12-31&location=Mumbai
```

---

## 🔔 8. NOTIFICATION APIs

### 8.1 Get All Notifications
```http
GET /api/notifications
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "notification_id",
      "title": "Daily Horoscope",
      "message": "Your daily horoscope is ready!",
      "type": "horoscope",
      "isRead": false,
      "createdAt": "2024-01-15T10:30:00.000Z"
    }
  ]
}
```

### 8.2 Get Specific Notification
```http
GET /api/notifications/:id
Authorization: Bearer <token>
```

### 8.3 Mark Notification as Read
```http
PUT /api/notifications/:id/read
Authorization: Bearer <token>
```

### 8.4 Mark All Notifications as Read
```http
PUT /api/notifications/read-all
Authorization: Bearer <token>
```

### 8.5 Delete Notification
```http
DELETE /api/notifications/:id
Authorization: Bearer <token>
```

### 8.6 Get Unread Count
```http
GET /api/notifications/unread-count
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "unreadCount": 5
  }
}
```

### 8.7 Create Notification (Admin)
```http
POST /api/notifications
Authorization: Bearer <admin-token>
Content-Type: application/json

{
  "title": "New Feature",
  "message": "Check out our new numerology calculator!",
  "type": "announcement",
  "userId": "user_id"
}
```

### 8.8 Broadcast Notification (Admin)
```http
POST /api/notifications/broadcast
Authorization: Bearer <admin-token>
Content-Type: application/json

{
  "title": "System Maintenance",
  "message": "Server maintenance scheduled for tomorrow",
  "type": "maintenance"
}
```

---

## 📝 9. BLOG APIs

### 9.1 Get All Blogs
```http
GET /api/blogs
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "blog_id",
      "title": "Understanding Kundali",
      "slug": "understanding-kundali",
      "content": "Kundali is a birth chart...",
      "author": "Astrologer",
      "category": "Education",
      "tags": ["kundali", "astrology"],
      "featured": true,
      "likes": 25,
      "comments": 10,
      "createdAt": "2024-01-15T10:30:00.000Z"
    }
  ]
}
```

### 9.2 Get Specific Blog
```http
GET /api/blogs/:slug
```

### 9.3 Create Blog (Admin)
```http
POST /api/blogs
Authorization: Bearer <admin-token>
Content-Type: application/json

{
  "title": "New Blog Post",
  "content": "Blog content here...",
  "category": "Education",
  "tags": ["astrology", "tips"],
  "featured": true
}
```

### 9.4 Update Blog (Admin)
```http
PUT /api/blogs/:id
Authorization: Bearer <admin-token>
Content-Type: application/json

{
  "title": "Updated Title",
  "content": "Updated content..."
}
```

### 9.5 Delete Blog (Admin)
```http
DELETE /api/blogs/:id
Authorization: Bearer <admin-token>
```

### 9.6 Add Comment to Blog
```http
POST /api/blogs/:id/comments
Authorization: Bearer <token>
Content-Type: application/json

{
  "comment": "Great article! Very informative."
}
```

### 9.7 Like Blog
```http
POST /api/blogs/:id/like
Authorization: Bearer <token>
```

### 9.8 Get Blogs by Category
```http
GET /api/blogs/category/:category
```

### 9.9 Get Featured Blogs
```http
GET /api/blogs/featured
```

### 9.10 Search Blogs
```http
GET /api/blogs/search?q=astrology
```

---

## 💰 10. PAID KUNDLI APIs

### 10.1 Get PDF Pricing
```http
GET /api/paidKundli/pdfPricing
```

**Response:**
```json
{
  "success": true,
  "data": {
    "pdfTypes": {
      "small": {
        "price": 199,
        "description": "Basic PDF Report",
        "gstAmount": 35.82,
        "totalAmount": 234.82
      },
      "medium": {
        "price": 399,
        "description": "Standard PDF Report",
        "gstAmount": 71.82,
        "totalAmount": 470.82
      },
      "large": {
        "price": 599,
        "description": "Premium PDF Report",
        "gstAmount": 107.82,
        "totalAmount": 706.82
      }
    },
    "gstPercentage": 18,
    "serviceName": "Paid Kundli Calculation"
  }
}
```

### 10.2 Create Paid Kundli Calculation
```http
POST /api/paidKundli/createCalculation
Content-Type: application/json

{
  "user_uni_id": "U1234567",
  "api_key": "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6",
  "order_for": "horoscope",
  "pdf_type": "medium",
  "payment_status": "Completed",
  "orderUrl": "https://payment-gateway.com/order/123"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Order created successfully",
  "data": {
    "order_id": "ORD202412011234567",
    "orderUrl": "https://payment-gateway.com/order/123",
    "pdf_type": "medium",
    "pricing": {
      "basePrice": 299,
      "pdfTypePrice": 399,
      "pdfTypeDescription": "Standard PDF Report",
      "gstPercentage": 18,
      "gstAmount": 71.82,
      "totalAmount": 470.82
    },
    "paymentStatus": "Completed"
  }
}
```

### 10.3 Get User Calculations
```http
GET /api/paidKundli/userCalculations?user_uni_id=U1234567&api_key=a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6
```

**Response:**
```json
{
  "success": true,
  "count": 2,
  "total": 2,
  "data": [
    {
      "id": "507f1f77bcf86cd799439011",
      "order_id": "ORD202412011234567",
      "name": "User Calculation",
      "order_for": "horoscope",
      "pdf_type": "medium",
      "pricing": {
        "basePrice": 299,
        "pdfTypePrice": 399,
        "gstPercentage": 18,
        "gstAmount": 71.82,
        "totalAmount": 470.82
      },
      "paymentStatus": "Completed",
      "status": "Completed"
    }
  ]
}
```

### 10.4 Update Pricing Configuration (Admin)
```http
PUT /api/paidKundli/updatePricing
Authorization: Bearer <admin-token>
Content-Type: application/json

{
  "basePrice": 299,
  "gstPercentage": 18,
  "serviceName": "Paid Kundli Calculation",
  "description": "Professional Kundli calculation with detailed analysis",
  "pdfTypes": {
    "small": {
      "price": 199,
      "description": "Basic PDF Report"
    },
    "medium": {
      "price": 399,
      "description": "Standard PDF Report"
    },
    "large": {
      "price": 599,
      "description": "Premium PDF Report"
    }
  },
  "pdf_type": "medium"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Pricing configuration updated successfully",
  "data": {
    "id": "507f1f77bcf86cd799439012",
    "serviceName": "Paid Kundli Calculation",
    "basePrice": 299,
    "gstPercentage": 18,
    "gstAmount": 53.82,
    "totalAmount": 352.82,
    "pdfTypes": {
      "small": {
        "price": 199,
        "description": "Basic PDF Report"
      },
      "medium": {
        "price": 399,
        "description": "Standard PDF Report"
      },
      "large": {
        "price": 599,
        "description": "Premium PDF Report"
      }
    },
    "isActive": true,
    "description": "Professional Kundli calculation with detailed analysis",
    "updatedBy": "507f1f77bcf86cd799439013",
    "updatedAt": "2024-01-15T10:30:00.000Z"
  }
}
```

### 10.5 Get Paid Kundli Statistics (Admin)
```http
GET /api/paidKundli/stats
Authorization: Bearer <admin-token>
```

**Response:**
```json
{
  "success": true,
  "message": "Paid Kundli statistics retrieved successfully",
  "data": {
    "overview": {
      "totalCalculations": 150,
      "completedCalculations": 120,
      "pendingCalculations": 20,
      "failedCalculations": 10,
      "totalRevenue": 45000,
      "completionRate": 80
    },
    "calculationsByType": [
      { "_id": "horoscope", "count": 100 },
      { "_id": "matching", "count": 50 }
    ],
    "recentCalculations": [
      {
        "order_for": "horoscope",
        "status": "Completed",
        "amount": 470.82,
        "createdAt": "2024-01-15T10:30:00.000Z",
        "user": {
          "name": "John Doe",
          "email": "john@example.com",
          "phone": "+918107804990"
        }
      }
    ],
    "monthlyStats": {
      "count": 25,
      "revenue": 7500
    }
  }
}
```

---

## 🔌 11. REAL-TIME APIs (Socket.IO)

### 11.1 Connect to Socket
```javascript
const socket = io('http://localhost:5000');

socket.on('connect', () => {
  console.log('Connected to server');
});

socket.on('disconnect', () => {
  console.log('Disconnected from server');
});
```

### 11.2 Join User Room
```javascript
socket.emit('join_user', { userId: 'U1234567' });
```

### 11.3 Listen for Notifications
```javascript
socket.on('new_notification', (data) => {
  console.log('New notification:', data);
});

socket.on('broadcast_notification', (data) => {
  console.log('Broadcast notification:', data);
});
```

### 11.4 Listen for Blog Updates
```javascript
socket.on('blogUpdate', (data) => {
  console.log('Blog update:', data);
});
```

---

## 🛠️ 12. UTILITY APIs

### 12.1 Health Check
```http
GET /health
```

**Response:**
```json
{
  "success": true,
  "message": "Astrology App API is running",
  "timestamp": "2024-01-15T10:30:00.000Z",
  "environment": "development"
}
```

### 12.2 API Documentation
```http
GET /api
```

**Response:**
```json
{
  "message": "Astrology App API Documentation",
  "version": "1.0.0",
  "endpoints": {
    "auth": { ... },
    "kundali": { ... },
    "notifications": { ... },
    "blogs": { ... }
  }
}
```

---

## 📋 13. TEST CREDENTIALS

### User Login
- **Phone**: `+918107804990`
- **OTP**: `333661`

### Admin Login
- **Username**: `admin123`
- **Password**: `admin@123`

---

## 🔧 14. ERROR RESPONSES

### 400 Bad Request
```json
{
  "success": false,
  "message": "Validation error",
  "errors": [
    {
      "field": "email",
      "message": "Please provide a valid email"
    }
  ]
}
```

### 401 Unauthorized
```json
{
  "success": false,
  "message": "Not authorized to access this route"
}
```

### 403 Forbidden
```json
{
  "success": false,
  "message": "Access forbidden"
}
```

### 404 Not Found
```json
{
  "success": false,
  "message": "Resource not found"
}
```

### 500 Internal Server Error
```json
{
  "success": false,
  "message": "Server error"
}
```

---

## 🚀 15. FLUTTER INTEGRATION EXAMPLES

### Login Example
```dart
final response = await http.post(
  Uri.parse('http://localhost:5000/api/auth/login'),
  headers: {'Content-Type': 'application/json'},
  body: jsonEncode({
    'phone': '+918107804990',
    'otp': '333661'
  }),
);

final data = jsonDecode(response.body);
final token = data['token'];
final userId = data['apiCredentials']['userId'];
final apiKey = data['apiCredentials']['apiKey'];
```

### API Call with Token
```dart
final response = await http.get(
  Uri.parse('http://localhost:5000/api/horoscope/daily'),
  headers: {
    'Authorization': 'Bearer $token',
    'Content-Type': 'application/json'
  },
);
```

### API Call with API Key
```dart
final response = await http.get(
  Uri.parse('http://localhost:5000/api/kundali'),
  headers: {
    'X-API-Key': apiKey,
    'Content-Type': 'application/json'
  },
);
```

---

## 📱 16. POSTMAN COLLECTION

Import the provided `Astrology_App_API.postman_collection.json` file into Postman for easy API testing.

---

## 🔐 17. SECURITY NOTES

1. **JWT Tokens**: Valid for 7 days by default
2. **API Keys**: 32-character hexadecimal strings
3. **Rate Limiting**: Implemented on sensitive endpoints
4. **CORS**: Configured for cross-origin requests
5. **Input Validation**: All inputs are validated and sanitized

---

## 📞 18. SUPPORT

For API support and questions:
- Check the server logs for detailed error messages
- Use the health check endpoint to verify server status
- Test with the provided test credentials
- Review the Flutter integration guide for mobile app integration

---

**Total APIs Available: 50+ endpoints** 🎉 