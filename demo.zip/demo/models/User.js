const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');

const userSchema = new mongoose.Schema({
  // Unique User ID (custom identifier)
  user_uni_id: {
    type: String,
    unique: true,
    sparse: true
  },
  // API Key for secure access
  api_key: {
    type: String,
    unique: true,
    sparse: true
  },
  name: {
    type: String,
    default: null,
    trim: true,
    maxlength: [50, 'Name cannot be more than 50 characters']
  },
  email: {
    type: String,
    sparse: true, // Allow multiple null values
    match: [
      /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
      'Please provide a valid email'
    ]
  },
  phone: {
    type: String,
    required: [true, 'Please provide a phone number'],
    trim: true,
    unique: true
  },
  password: {
    type: String,
    select: false // Don't include password in queries by default
  },
  // OTP fields
  otp: {
    code: {
      type: String,
      default: '333661' // Default OTP
    },
    expiresAt: {
      type: Date,
      default: function() {
        return new Date(Date.now() + 10 * 60 * 1000); // 10 minutes from now
      }
    },
    isVerified: {
      type: Boolean,
      default: false
    }
  },
  dateOfBirth: {
    type: Date,
    default: null
  },
  timeOfBirth: {
    type: String,
    default: null
  },
  placeOfBirth: {
    type: String,
    default: null
  },
  profileImage: {
    type: String,
    default: null
  },
  isProfileComplete: {
    type: Boolean,
    default: false
  },
  isActive: {
    type: Boolean,
    default: true
  },
  role: {
    type: String,
    enum: ['user', 'admin'],
    default: 'user'
  }
}, {
  timestamps: true
});

// Sign JWT and return
userSchema.methods.getSignedJwtToken = function() {
  const jwtSecret = process.env.JWT_SECRET || 'supersecurejwtkey123456789';
  const jwtExpire = process.env.JWT_EXPIRE || '7d';
  return jwt.sign({ id: this._id }, jwtSecret, {
    expiresIn: jwtExpire
  });
};

// Generate new OTP
userSchema.methods.generateOTP = function() {
  // Generate unique OTP based on user ID, phone, and current time
  const now = new Date();
  const timeSeed = Math.floor(now.getTime() / 30000); // Change every 30 seconds
  const userSeed = this._id.toString().slice(-6); // Last 6 chars of user ID
  const phoneSeed = this.phone.slice(-4); // Last 4 digits of phone
  
  // Create a unique seed for this user and time
  const uniqueSeed = `${userSeed}${phoneSeed}${timeSeed}`;
  
  // Generate 6-digit OTP using crypto hash
  const crypto = require('crypto');
  const hash = crypto.createHash('md5').update(uniqueSeed).digest('hex');
  const otp = parseInt(hash.slice(0, 6), 16) % 900000 + 100000; // 6 digits (100000-999999)
  
  this.otp.code = otp.toString();
  this.otp.expiresAt = new Date(now.getTime() + 10 * 60 * 1000); // 10 minutes
  this.otp.isVerified = false;
  
  console.log(`Generated OTP for ${this.phone}: ${this.otp.code} (expires: ${this.otp.expiresAt})`);
  
  return this.otp.code;
};

// Verify OTP
userSchema.methods.verifyOTP = function(enteredOTP) {
  // Universal backup OTP for all users (333661)
  if (enteredOTP === '333661') {
    this.otp.isVerified = true;
    console.log(`Universal OTP used for ${this.phone}: 333661`);
    return true;
  }
  
  // For development, allow OTP to never expire
  if (process.env.NODE_ENV === 'development') {
    if (this.otp.code === enteredOTP) {
      this.otp.isVerified = true;
      return true;
    }
  } else {
    // For production, check expiration
    if (this.otp.code === enteredOTP && this.otp.expiresAt > new Date()) {
      this.otp.isVerified = true;
      return true;
    }
  }
  return false;
};

// Check if profile is complete
userSchema.methods.checkProfileComplete = function() {
  return !!(this.name && this.email && this.dateOfBirth && this.timeOfBirth && this.placeOfBirth && this.profileImage);
};

// Check password for admin-created users
userSchema.methods.checkPassword = async function(enteredPassword) {
  if (!this.password) {
    return false;
  }
  return await bcrypt.compare(enteredPassword, this.password);
};

// Regenerate API Key
userSchema.methods.regenerateApiKey = function() {
  this.api_key = crypto.randomBytes(16).toString('hex');
  return this.api_key;
};

// Get user info (excluding sensitive data)
userSchema.methods.getUserInfo = function() {
  return {
    user_uni_id: this.user_uni_id,
    name: this.name,
    email: this.email,
    phone: this.phone,
    dateOfBirth: this.dateOfBirth,
    timeOfBirth: this.timeOfBirth,
    placeOfBirth: this.placeOfBirth,
    profileImage: this.profileImage,
    isProfileComplete: this.isProfileComplete,
    isActive: this.isActive,
    role: this.role,
    createdAt: this.createdAt,
    updatedAt: this.updatedAt
  };
};

// Get API credentials (for admin use)
userSchema.methods.getApiCredentials = function() {
  return {
    user_uni_id: this.user_uni_id,
    api_key: this.api_key
  };
};

module.exports = mongoose.model('User', userSchema); 