const mongoose = require('mongoose');
const mongoosePaginate = require('mongoose-paginate-v2');

const razorpayConfigSchema = new mongoose.Schema({
  razorpayId: {
    type: String,
    required: [true, 'Razorpay ID is required'],
    trim: true
  },
  razorpayKey: {
    type: String,
    required: [true, 'Razorpay Key is required'],
    trim: true
  },
  razorpayXAccount: {
    type: String,
    required: [true, 'RazorpayX Account is required'],
    trim: true
  },
  isActive: {
    type: Boolean,
    default: true
  },
  environment: {
    type: String,
    enum: ['test', 'live'],
    default: 'test',
    required: true
  },
  description: {
    type: String,
    trim: true,
    maxlength: [500, 'Description cannot be more than 500 characters']
  },
  updatedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, {
  timestamps: true
});

// Add pagination plugin
razorpayConfigSchema.plugin(mongoosePaginate);

// Method to get formatted data (without sensitive information)
razorpayConfigSchema.methods.getFormattedData = function() {
  return {
    id: this._id,
    razorpayId: this.razorpayId,
    razorpayKey: this.razorpayKey ? '***' + this.razorpayKey.slice(-4) : null, // Only show last 4 characters
    razorpayXAccount: this.razorpayXAccount,
    isActive: this.isActive,
    environment: this.environment,
    description: this.description,
    updatedBy: this.updatedBy,
    updatedAt: this.updatedAt,
    createdAt: this.createdAt
  };
};

// Method to get full data (for admin use)
razorpayConfigSchema.methods.getFullData = function() {
  return {
    id: this._id,
    razorpayId: this.razorpayId,
    razorpayKey: this.razorpayKey,
    razorpayXAccount: this.razorpayXAccount,
    isActive: this.isActive,
    environment: this.environment,
    description: this.description,
    updatedBy: this.updatedBy,
    updatedAt: this.updatedAt,
    createdAt: this.createdAt
  };
};

// Indexes
razorpayConfigSchema.index({ environment: 1 });
razorpayConfigSchema.index({ isActive: 1 });
razorpayConfigSchema.index({ updatedAt: -1 });

module.exports = mongoose.model('RazorpayConfig', razorpayConfigSchema); 