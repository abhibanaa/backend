const mongoose = require('mongoose');

const horoscopeSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  // Horoscope type
  type: {
    type: String,
    enum: ['daily', 'weekly', 'monthly', 'yearly'],
    required: true
  },
  // Date for the horoscope
  date: {
    type: Date,
    required: true
  },
  // Zodiac sign
  zodiacSign: {
    type: String,
    enum: ['Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo', 'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces'],
    required: true
  },
  // Horoscope content
  content: {
    general: {
      type: String,
      required: true
    },
    love: String,
    career: String,
    health: String,
    finance: String,
    family: String,
    travel: String,
    education: String
  },
  // Lucky details
  lucky: {
    number: [Number],
    color: [String],
    day: [String],
    time: String
  },
  // Planetary influences
  planetaryInfluences: {
    sun: String,
    moon: String,
    mars: String,
    mercury: String,
    jupiter: String,
    venus: String,
    saturn: String
  },
  // Compatibility
  compatibility: {
    best: [String],
    good: [String],
    avoid: [String]
  },
  // Mood and energy
  mood: {
    type: String,
    enum: ['Excellent', 'Very Good', 'Good', 'Average', 'Poor', 'Very Poor']
  },
  energy: {
    type: String,
    enum: ['High', 'Medium', 'Low']
  },
  // Source of horoscope
  source: {
    type: String,
    default: 'AI Generated'
  },
  // Is this a personalized horoscope
  isPersonalized: {
    type: Boolean,
    default: false
  },
  // Language
  language: {
    type: String,
    default: 'English'
  }
}, {
  timestamps: true
});

// Index for better query performance
horoscopeSchema.index({ zodiacSign: 1, type: 1, date: 1 });
horoscopeSchema.index({ user: 1, date: -1 });
horoscopeSchema.index({ type: 1, date: -1 });

module.exports = mongoose.model('Horoscope', horoscopeSchema); 