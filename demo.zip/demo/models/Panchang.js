const mongoose = require('mongoose');

const panchangSchema = new mongoose.Schema({
  // Date for the panchang
  date: {
    type: Date,
    required: true
  },
  // Location details
  location: {
    name: {
      type: String,
      required: true
    },
    latitude: Number,
    longitude: Number,
    timezone: String
  },
  // Tithi (Lunar day)
  tithi: {
    name: {
      type: String,
      enum: ['Pratipada', 'Dwitiya', 'Tritiya', 'Chaturthi', 'Panchami', 'Shashthi', 'Saptami', 'Ashtami', 'Navami', 'Dashami', 'Ekadashi', 'Dwadashi', 'Trayodashi', 'Chaturdashi', 'Amavasya'],
      required: true
    },
    number: {
      type: Number,
      min: 1,
      max: 30
    },
    startTime: Date,
    endTime: Date
  },
  // Vara (Week day)
  vara: {
    type: String,
    enum: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    required: true
  },
  // Nakshatra (Lunar mansion)
  nakshatra: {
    name: {
      type: String,
      enum: ['Ashwini', 'Bharani', 'Krittika', 'Rohini', 'Mrigashira', 'Ardra', 'Punarvasu', 'Pushya', 'Ashlesha', 'Magha', 'Purva Phalguni', 'Uttara Phalguni', 'Hasta', 'Chitra', 'Swati', 'Vishakha', 'Anuradha', 'Jyeshtha', 'Mula', 'Purva Ashadha', 'Uttara Ashadha', 'Shravana', 'Dhanishta', 'Shatabhisha', 'Purva Bhadrapada', 'Uttara Bhadrapada', 'Revati'],
      required: true
    },
    number: {
      type: Number,
      min: 1,
      max: 27
    },
    startTime: Date,
    endTime: Date
  },
  // Yoga (Sun-Moon combination)
  yoga: {
    name: {
      type: String,
      enum: ['Vishkumbha', 'Priti', 'Ayushman', 'Saubhagya', 'Shobhana', 'Atiganda', 'Sukarman', 'Dhriti', 'Shula', 'Ganda', 'Vriddhi', 'Dhruva', 'Vyaghata', 'Harshana', 'Vajra', 'Siddhi', 'Vyatipata', 'Variyan', 'Parigha', 'Shiva', 'Siddha', 'Sadhya', 'Shubha', 'Shukla', 'Brahma', 'Indra', 'Vaidhriti'],
      required: true
    },
    number: {
      type: Number,
      min: 1,
      max: 27
    }
  },
  // Karana (Half of Tithi)
  karana: {
    name: {
      type: String,
      enum: ['Bava', 'Balava', 'Kaulava', 'Taitila', 'Garija', 'Vanija', 'Vishti', 'Shakuni', 'Chatushpada', 'Naga'],
      required: true
    },
    number: {
      type: Number,
      min: 1,
      max: 11
    }
  },
  // Auspicious timings (Muhurat)
  muhurat: {
    sunrise: Date,
    sunset: Date,
    brahmaMuhurat: {
      start: Date,
      end: Date
    },
    abhijitMuhurat: {
      start: Date,
      end: Date
    },
    godhuliMuhurat: {
      start: Date,
      end: Date
    },
    amritKaal: {
      start: Date,
      end: Date
    },
    rahuKaal: {
      start: Date,
      end: Date
    },
    gulikaKaal: {
      start: Date,
      end: Date
    },
    yamagandaKaal: {
      start: Date,
      end: Date
    }
  },
  // Festivals and special days
  festivals: [{
    name: String,
    description: String,
    isAuspicious: Boolean
  }],
  // Dosha and remedies
  dosha: {
    type: String,
    enum: ['None', 'Mild', 'Moderate', 'Severe']
  },
  remedies: [String],
  // General recommendations
  recommendations: {
    goodFor: [String],
    avoid: [String],
    generalAdvice: String
  },
  // Language
  language: {
    type: String,
    default: 'English'
  }
}, {
  timestamps: true
});

// Index for better query performance
panchangSchema.index({ date: 1 });
panchangSchema.index({ 'location.name': 1, date: 1 });
panchangSchema.index({ tithi: 1, nakshatra: 1 });

module.exports = mongoose.model('Panchang', panchangSchema); 