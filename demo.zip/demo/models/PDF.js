const mongoose = require('mongoose');

const pdfSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'PDF title is required'],
    trim: true,
    maxlength: [200, 'Title cannot be more than 200 characters']
  },
  description: {
    type: String,
    trim: true,
    maxlength: [1000, 'Description cannot be more than 1000 characters']
  },
  category: {
    type: String,
    required: [true, 'Category is required'],
    enum: ['horoscope', 'matching', 'numerology', 'panchang', 'general', 'kundli'],
    default: 'general'
  },
  pdfUrl: {
    type: String,
    required: [true, 'PDF URL is required'],
    trim: true
  },
  fileName: {
    type: String,
    required: [true, 'File name is required'],
    trim: true
  },
  fileSize: {
    type: Number, // Size in bytes
    default: 0
  },
  pdfLanguage: {
    type: String,
    enum: ['hi', 'eng', 'both'],
    default: 'eng',
    validate: {
      validator: function(v) {
        return ['hi', 'eng', 'both'].includes(v);
      },
      message: props => `${props.value} is not a valid language. Must be 'hi', 'eng', or 'both'`
    }
  },
  isActive: {
    type: Boolean,
    default: true
  },
  isFeatured: {
    type: Boolean,
    default: false
  },
  downloadCount: {
    type: Number,
    default: 0
  },
  viewCount: {
    type: Number,
    default: 0
  },
  tags: [{
    type: String,
    trim: true
  }],
  thumbnailUrl: {
    type: String,
    trim: true
  },
  addedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  lastUpdatedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, {
  timestamps: true
});

// Method to get formatted data
pdfSchema.methods.getFormattedData = function() {
  return {
    id: this._id,
    title: this.title,
    description: this.description,
    category: this.category,
    pdfUrl: this.pdfUrl,
    fileName: this.fileName,
    fileSize: this.fileSize,
    language: this.pdfLanguage, // Keep 'language' in API response for compatibility
    isActive: this.isActive,
    isFeatured: this.isFeatured,
    downloadCount: this.downloadCount,
    viewCount: this.viewCount,
    tags: this.tags,
    thumbnailUrl: this.thumbnailUrl,
    addedBy: this.addedBy,
    lastUpdatedBy: this.lastUpdatedBy,
    createdAt: this.createdAt,
    updatedAt: this.updatedAt
  };
};

// Method to increment download count
pdfSchema.methods.incrementDownloadCount = function() {
  this.downloadCount += 1;
  return this.save();
};

// Method to increment view count
pdfSchema.methods.incrementViewCount = function() {
  this.viewCount += 1;
  return this.save();
};

// Indexes for better query performance
pdfSchema.index({ category: 1, isActive: 1 });
pdfSchema.index({ isFeatured: 1, isActive: 1 });
pdfSchema.index({ pdfLanguage: 1, isActive: 1 });
pdfSchema.index({ title: 'text', description: 'text' });
pdfSchema.index({ tags: 1 });
pdfSchema.index({ downloadCount: -1 });
pdfSchema.index({ createdAt: -1 });

module.exports = mongoose.model('PDF', pdfSchema); 