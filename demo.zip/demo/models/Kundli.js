const mongoose = require('mongoose');

const kundliSchema = new mongoose.Schema({
  // User reference
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  
  // Basic Kundli Information
  name: {
    type: String,
    required: [true, 'Please provide a name for the kundli'],
    trim: true,
    maxlength: [100, 'Name cannot be more than 100 characters']
  },
  
  // Birth Details
  dateOfBirth: {
    type: Date,
    required: [true, 'Date of birth is required']
  },
  
  timeOfBirth: {
    type: String,
    required: [true, 'Time of birth is required'],
    trim: true
  },
  
  placeOfBirth: {
    type: String,
    required: [true, 'Place of birth is required'],
    trim: true
  },
  
  // Astrological Details
  sunSign: {
    type: String,
    enum: ['Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo', 'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces', 'Unknown'],
    default: 'Unknown'
  },
  
  moonSign: {
    type: String,
    enum: ['Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo', 'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces', 'Unknown'],
    default: 'Unknown'
  },
  
  ascendant: {
    type: String,
    enum: ['Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo', 'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces', 'Unknown'],
    default: 'Unknown'
  },
  
  // Planetary Positions
  planetaryPositions: {
    sun: { type: String, default: null },
    moon: { type: String, default: null },
    mars: { type: String, default: null },
    mercury: { type: String, default: null },
    jupiter: { type: String, default: null },
    venus: { type: String, default: null },
    saturn: { type: String, default: null },
    rahu: { type: String, default: null },
    ketu: { type: String, default: null }
  },
  
  // House Positions
  housePositions: {
    house1: { type: String, default: null },
    house2: { type: String, default: null },
    house3: { type: String, default: null },
    house4: { type: String, default: null },
    house5: { type: String, default: null },
    house6: { type: String, default: null },
    house7: { type: String, default: null },
    house8: { type: String, default: null },
    house9: { type: String, default: null },
    house10: { type: String, default: null },
    house11: { type: String, default: null },
    house12: { type: String, default: null }
  },
  
  // Additional Details
  gender: {
    type: String,
    enum: ['Male', 'Female', 'Other'],
    required: true
  },
  
  // Kundli Type
  kundliType: {
    type: String,
    enum: ['Personal', 'Family', 'Business', 'Marriage', 'Career', 'Health'],
    default: 'Personal'
  },
  

  
  // Status
  isActive: {
    type: Boolean,
    default: true
  },
  
  // Analysis Results (computed)
  analysis: {
    overallScore: { type: Number, default: 0 },
    strengths: [{ type: String }],
    weaknesses: [{ type: String }],
    recommendations: [{ type: String }],
    lastAnalyzed: { type: Date, default: null }
  },
  
  // Notes
  notes: {
    type: String,
    maxlength: [1000, 'Notes cannot be more than 1000 characters']
  }
}, {
  timestamps: true
});

// Index for better performance
kundliSchema.index({ user: 1, createdAt: -1 });
kundliSchema.index({ sunSign: 1 });
kundliSchema.index({ moonSign: 1 });

// Virtual for age calculation
kundliSchema.virtual('age').get(function() {
  if (!this.dateOfBirth) return null;
  const today = new Date();
  const birthDate = new Date(this.dateOfBirth);
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  
  return age;
});

// Method to get formatted kundli data
kundliSchema.methods.getFormattedData = function() {
  return {
    id: this._id,
    name: this.name,
    dateOfBirth: this.dateOfBirth,
    timeOfBirth: this.timeOfBirth,
    placeOfBirth: this.placeOfBirth,
    age: this.age,
    sunSign: this.sunSign,
    moonSign: this.moonSign,
    ascendant: this.ascendant,
    gender: this.gender,
    kundliType: this.kundliType,
    planetaryPositions: this.planetaryPositions,
    housePositions: this.housePositions,
    analysis: this.analysis,
    notes: this.notes,
    isActive: this.isActive,
    createdAt: this.createdAt,
    updatedAt: this.updatedAt
  };
};

module.exports = mongoose.model('Kundli', kundliSchema); 