const mongoose = require('mongoose');

const pricingConfigSchema = new mongoose.Schema({
  serviceName: {
    type: String,
    required: [true, 'Service name is required'],
    unique: true,
    default: 'Paid Kundli Calculation'
  },
  basePrice: {
    type: Number,
    required: [true, 'Base price is required'],
    default: 299,
    min: [0, 'Base price cannot be negative']
  },
  gstPercentage: {
    type: Number,
    required: [true, 'GST percentage is required'],
    default: 18,
    min: [0, 'GST percentage cannot be negative'],
    max: [100, 'GST percentage cannot exceed 100']
  },
  pdfTypes: {
    small: {
      price: {
        type: Number,
        default: 199,
        min: [0, 'Price cannot be negative']
      },
      description: {
        type: String,
        default: 'Basic PDF Report'
      }
    },
    medium: {
      price: {
        type: Number,
        default: 399,
        min: [0, 'Price cannot be negative']
      },
      description: {
        type: String,
        default: 'Standard PDF Report'
      }
    },
    large: {
      price: {
        type: Number,
        default: 599,
        min: [0, 'Price cannot be negative']
      },
      description: {
        type: String,
        default: 'Premium PDF Report'
      }
    }
  },
  isActive: {
    type: Boolean,
    default: true
  },
  description: {
    type: String,
    trim: true,
    maxlength: [500, 'Description cannot be more than 500 characters']
  },
  updatedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, {
  timestamps: true
});

// Method to get formatted data
pricingConfigSchema.methods.getFormattedData = function() {
  const gstAmount = Math.round((this.basePrice * this.gstPercentage) / 100);
  const totalAmount = this.basePrice + gstAmount;
  
  return {
    id: this._id,
    serviceName: this.serviceName,
    basePrice: this.basePrice,
    gstPercentage: this.gstPercentage,
    gstAmount: gstAmount,
    totalAmount: totalAmount,
    pdfTypes: this.pdfTypes,
    isActive: this.isActive,
    description: this.description,
    updatedBy: this.updatedBy,
    updatedAt: this.updatedAt
  };
};

// Indexes
pricingConfigSchema.index({ serviceName: 1 });
pricingConfigSchema.index({ isActive: 1 });

module.exports = mongoose.model('PricingConfig', pricingConfigSchema); 