const mongoose = require('mongoose');

const paidKundliSchema = new mongoose.Schema({
  orderId: {
    type: String,
    unique: true,
    sparse: true, // Allow multiple null values
    required: false // Make it optional initially
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  name: {
    type: String,
    required: [true, 'Name is required'],
    trim: true,
    maxlength: [100, 'Name cannot be more than 100 characters']
  },
  dateOfBirth: {
    type: Date,
    required: [true, 'Date of birth is required']
  },
  timeOfBirth: {
    type: String,
    required: [true, 'Time of birth is required']
  },
  placeOfBirth: {
    type: String,
    required: [true, 'Place of birth is required']
  },
  gender: {
    type: String,
    enum: ['Male', 'Female', 'Other'],
    required: [true, 'Gender is required']
  },
  // Order details
  order_for: {
    type: String,
    enum: ['horoscope', 'matching'],
    required: [true, 'Order type is required']
  },
  payment_method: {
    type: String,
    default: 'razorpay',
    enum: ['razorpay', 'paytm', 'stripe', 'cod']
  },
  // Customization fields
  language: {
    type: String,
    enum: ['hi', 'eng'],
    default: 'eng'
  },
  style: {
    type: String,
    enum: ['north', 'south'],
    default: 'north'
  },
  color: {
    type: String,
    default: '140'
  },
  pdf_type: {
    type: String,
    enum: ['large', 'medium', 'small'],
    default: 'medium'
  },
  orderDetails: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  // URL field for order
  orderUrl: {
    type: String,
    default: null,
    trim: true
  },
  // Pricing information
  basePrice: {
    type: Number,
    default: 299,
    min: [0, 'Base price cannot be negative']
  },
  pdfTypePrice: {
    type: Number,
    required: [true, 'PDF type price is required'],
    min: [0, 'PDF type price cannot be negative']
  },
  gstPercentage: {
    type: Number,
    default: 18,
    min: [0, 'GST percentage cannot be negative'],
    max: [100, 'GST percentage cannot exceed 100']
  },
  gstAmount: {
    type: Number,
    default: function() {
      return Math.round((this.pdfTypePrice * this.gstPercentage) / 100);
    }
  },
  totalAmount: {
    type: Number,
    default: function() {
      return this.pdfTypePrice + this.gstAmount;
    }
  },
  // Payment status
  paymentStatus: {
    type: String,
    enum: ['Pending', 'Completed', 'Failed', 'Refunded'],
    default: 'Pending'
  },
  // Calculation results
  calculationData: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  // Additional details
  notes: {
    type: String,
    trim: true,
    maxlength: [1000, 'Notes cannot be more than 1000 characters']
  },
  status: {
    type: String,
    enum: ['Pending', 'Processing', 'Completed', 'Failed'],
    default: 'Pending'
  }
}, {
  timestamps: true
});

// Generate unique order ID and calculate GST before saving
paidKundliSchema.pre('save', async function(next) {
  // Only generate order ID if it doesn't exist AND payment is completed
  // Note: This is now primarily handled in the controller for better control
  if (!this.orderId && this.paymentStatus === 'Completed') {
    try {
      // Get current date for prefix
      const now = new Date();
      const datePrefix = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
      
      // Get count of orders for today
      const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const endOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
      
      const todayOrdersCount = await this.constructor.countDocuments({
        createdAt: { $gte: startOfDay, $lt: endOfDay }
      });
      
      // Generate order ID with date prefix and sequential number
      const sequenceNumber = (todayOrdersCount + 1).toString().padStart(4, '0');
      const randomSuffix = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
      const extraRandom = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
      
      this.orderId = `ORD${datePrefix}${sequenceNumber}${randomSuffix}${extraRandom}`;
      
      // Double-check uniqueness
      const existingOrder = await this.constructor.findOne({ orderId: this.orderId });
      if (existingOrder) {
        // If collision, add more randomness
        const extraRandom2 = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
        this.orderId = `ORD${datePrefix}${sequenceNumber}${randomSuffix}${extraRandom}${extraRandom2}`;
      }
    } catch (error) {
      return next(new Error('Failed to generate unique order ID: ' + error.message));
    }
  }
  
  // Calculate GST and total amount
  this.gstAmount = Math.round((this.pdfTypePrice * this.gstPercentage) / 100);
  this.totalAmount = this.pdfTypePrice + this.gstAmount;
  next();
});

// Comment out the restrictive duplicate detection since orderId generation already ensures uniqueness
// This was causing issues by blocking orders before orderId generation
/*
paidKundliSchema.pre('save', async function(next) {
  if (this.isNew) {
    try {
      const oneMinuteAgo = new Date(Date.now() - 60 * 1000);
      const existingOrder = await this.constructor.findOne({
        user: this.user,
        order_for: this.order_for,
        pdf_type: this.pdf_type,
        orderId: { $exists: true, $ne: null },
        createdAt: { $gte: oneMinuteAgo }
      });
      
      if (existingOrder) {
        return next(new Error('Duplicate order detected. Please wait before creating another order.'));
      }
    } catch (error) {
      return next(new Error('Error checking for duplicates: ' + error.message));
    }
  }
  next();
});
*/

// Add unique indexes to prevent duplicates
// Make orderId index sparse to allow multiple null values (pending orders)
paidKundliSchema.index({ orderId: 1 }, { unique: true, sparse: true }); // Ensure unique orderId only for non-null values
// Comment out the restrictive index that was causing issues
// paidKundliSchema.index({ user: 1, order_for: 1, createdAt: 1 }, { 
//   unique: true,
//   partialFilterExpression: {
//     createdAt: { $gte: new Date(Date.now() - 60000) } // Within 1 minute
//   }
// });

// Add a method to clean duplicates for a user
paidKundliSchema.statics.cleanDuplicatesForUser = async function(userId, orderFor) {
  const query = { user: userId, order_for: orderFor };
  const allOrders = await this.find(query).sort({ createdAt: -1 });
  
  // Group by creation time (within 1 minute)
  const orderGroups = {};
  allOrders.forEach(order => {
    const timeKey = Math.floor(new Date(order.createdAt).getTime() / 60000);
    if (!orderGroups[timeKey]) {
      orderGroups[timeKey] = [];
    }
    orderGroups[timeKey].push(order);
  });
  
  // Remove duplicates
  let removedCount = 0;
  for (const [timeKey, orders] of Object.entries(orderGroups)) {
    if (orders.length > 1) {
      orders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      const [newestOrder, ...duplicates] = orders;
      
      for (const duplicate of duplicates) {
        await this.findByIdAndDelete(duplicate._id);
        removedCount++;
      }
    }
  }
  
  return removedCount;
};

// Method to get formatted data
paidKundliSchema.methods.getFormattedData = function() {
      return {
      id: this._id,
      order_id: this.orderId || null,
      name: this.name,
      dateOfBirth: this.dateOfBirth,
      timeOfBirth: this.timeOfBirth,
      placeOfBirth: this.placeOfBirth,
      gender: this.gender,
      order_for: this.order_for,
      payment_method: this.payment_method,
      language: this.language,
      style: this.style,
      color: this.color,
      pdf_type: this.pdf_type,
      orderDetails: this.orderDetails,
      orderUrl: this.orderUrl,
      pricing: {
        basePrice: this.basePrice,
        pdfTypePrice: this.pdfTypePrice,
        gstPercentage: this.gstPercentage,
        gstAmount: this.gstAmount,
        totalAmount: this.totalAmount
      },
      paymentStatus: this.paymentStatus,
      status: this.status,
      calculationData: this.calculationData,
      notes: this.notes,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt
    };
};

// Indexes for better query performance
paidKundliSchema.index({ user: 1, createdAt: -1 });
paidKundliSchema.index({ paymentStatus: 1 });
paidKundliSchema.index({ status: 1 });
paidKundliSchema.index({ name: 1 });
// Prevent duplicate orders for same user and order type within 1 minute
paidKundliSchema.index({ user: 1, order_for: 1, createdAt: -1 });

module.exports = mongoose.model('PaidKundli', paidKundliSchema); 