const mongoose = require('mongoose');

const matchingSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  // Person 1 details (Boy)
  person1: {
    name: {
      type: String,
      required: true
    },
    dateOfBirth: {
      type: Date,
      required: true
    },
    timeOfBirth: {
      type: String,
      required: true
    },
    placeOfBirth: {
      type: String,
      required: true
    },
    gender: {
      type: String,
      enum: ['Male', 'Female', 'Other'],
      required: true
    },
    zodiacSign: {
      type: String,
      enum: ['Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo', 'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces']
    },
    nakshatra: String,
    rashi: String
  },
  // Person 2 details (Girl)
  person2: {
    name: {
      type: String,
      required: true
    },
    dateOfBirth: {
      type: Date,
      required: true
    },
    timeOfBirth: {
      type: String,
      required: true
    },
    placeOfBirth: {
      type: String,
      required: true
    },
    gender: {
      type: String,
      enum: ['Male', 'Female', 'Other'],
      required: true
    },
    zodiacSign: {
      type: String,
      enum: ['Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo', 'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces']
    },
    nakshatra: String,
    rashi: String
  },
  // Relationship type
  relationshipType: {
    type: String,
    enum: ['Marriage', 'Business', 'Friendship', 'Love', 'General'],
    required: true
  },
  // Compatibility scores
  scores: {
    overall: {
      type: Number,
      min: 0,
      max: 100
    },
    mental: {
      type: Number,
      min: 0,
      max: 100
    },
    physical: {
      type: Number,
      min: 0,
      max: 100
    },
    spiritual: {
      type: Number,
      min: 0,
      max: 100
    },
    emotional: {
      type: Number,
      min: 0,
      max: 100
    }
  },
  // Gun Milan details
  gunMilan: {
    totalGun: {
      type: Number,
      min: 0,
      max: 36
    },
    compatibility: {
      type: String,
      enum: ['Excellent', 'Very Good', 'Good', 'Average', 'Poor', 'Very Poor']
    },
    details: {
      varna: { type: Number },
      vashya: { type: Number },
      tara: { type: Number },
      yoni: { type: Number },
      grahaMaitri: { type: Number },
      gana: { type: Number },
      bhakoot: { type: Number },
      nadi: { type: Number }
    }
  },
  // Detailed analysis
  analysis: {
    summary: String,
    strengths: [String],
    challenges: [String],
    recommendations: [String],
    planetaryInfluences: {
      sun: String,
      moon: String,
      mars: String,
      mercury: String,
      jupiter: String,
      venus: String,
      saturn: String
    }
  },
  // Matching status
  status: {
    type: String,
    enum: ['Pending', 'Completed', 'Failed'],
    default: 'Pending'
  },
  // Additional notes
  notes: String,
  // Language
  language: {
    type: String,
    default: 'English'
  }
}, {
  timestamps: true
});

// Index for better query performance
matchingSchema.index({ user: 1, createdAt: -1 });
matchingSchema.index({ "person1.name": 1, "person2.name": 1 });

module.exports = mongoose.model('Matching', matchingSchema); 