const mongoose = require('mongoose');

const kundaliSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  name: {
    type: String,
    required: [true, 'Please provide a name'],
    trim: true
  },
  dateOfBirth: {
    type: Date,
    required: [true, 'Please provide date of birth']
  },
  timeOfBirth: {
    type: String,
    required: [true, 'Please provide time of birth']
  },
  placeOfBirth: {
    type: String,
    required: [true, 'Please provide place of birth']
  },
  latitude: {
    type: Number
  },
  longitude: {
    type: Number
  },
  // Planetary positions
  sunSign: {
    type: String,
    enum: ['Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo', 'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces']
  },
  moonSign: {
    type: String,
    enum: ['Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo', 'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces']
  },
  ascendant: {
    type: String,
    enum: ['Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo', 'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces']
  },
  // Planetary positions in houses
  planetaryPositions: {
    sun: { sign: String, house: Number, degree: Number },
    moon: { sign: String, house: Number, degree: Number },
    mars: { sign: String, house: Number, degree: Number },
    mercury: { sign: String, house: Number, degree: Number },
    jupiter: { sign: String, house: Number, degree: Number },
    venus: { sign: String, house: Number, degree: Number },
    saturn: { sign: String, house: Number, degree: Number },
    rahu: { sign: String, house: Number, degree: Number },
    ketu: { sign: String, house: Number, degree: Number }
  },
  // House positions
  houses: [{
    houseNumber: Number,
    sign: String,
    degree: Number
  }],
  // Generated PDF URL
  generatedPdfUrl: {
    type: String
  },
  // Analysis and predictions
  analysis: {
    type: String
  },
  isPublic: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: true
});

// Index for better query performance
kundaliSchema.index({ user: 1, dateOfBirth: 1 });
kundaliSchema.index({ sunSign: 1, moonSign: 1 });

module.exports = mongoose.model('Kundali', kundaliSchema); 