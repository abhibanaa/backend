const mongoose = require('mongoose');

const numerologySchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  // Personal details
  name: {
    type: String,
    required: true
  },
  dateOfBirth: {
    type: Date,
    required: true
  },
  // Core numbers
  lifePathNumber: {
    type: Number,
    min: 1,
    max: 9,
    required: true
  },
  destinyNumber: {
    type: Number,
    min: 1,
    max: 9,
    required: true
  },
  soulNumber: {
    type: Number,
    min: 1,
    max: 9,
    required: true
  },
  personalityNumber: {
    type: Number,
    min: 1,
    max: 9,
    required: true
  },
  maturityNumber: {
    type: Number,
    min: 1,
    max: 9
  },
  // Name analysis
  nameAnalysis: {
    vowels: [String],
    consonants: [String],
    totalVowels: Number,
    totalConsonants: Number,
    nameNumber: Number
  },
  // Birth date analysis
  birthDateAnalysis: {
    day: Number,
    month: Number,
    year: Number,
    dayNumber: Number,
    monthNumber: Number,
    yearNumber: Number
  },
  // Personal year number
  personalYearNumber: {
    type: Number,
    min: 1,
    max: 9
  },
  // Lucky numbers
  luckyNumbers: [Number],
  // Unlucky numbers
  unluckyNumbers: [Number],
  // Lucky colors
  luckyColors: [String],
  // Lucky days
  luckyDays: [String],
  // Detailed analysis
  analysis: {
    lifePath: {
      description: String,
      strengths: [String],
      challenges: [String],
      career: String,
      relationships: String,
      health: String
    },
    destiny: {
      description: String,
      purpose: String,
      talents: [String]
    },
    soul: {
      description: String,
      innerDesires: [String],
      spiritualPath: String
    },
    personality: {
      description: String,
      howOthersSeeYou: String,
      socialStyle: String
    }
  },
  // Compatibility
  compatibility: {
    bestNumbers: [Number],
    goodNumbers: [Number],
    avoidNumbers: [Number]
  },
  // Predictions
  predictions: {
    currentYear: String,
    nextYear: String,
    longTerm: String
  },
  // Remedies and suggestions
  remedies: [String],
  suggestions: [String],
  // Is this a detailed report
  isDetailed: {
    type: Boolean,
    default: false
  },
  // Generated PDF URL
  generatedPdfUrl: String
}, {
  timestamps: true
});

// Index for better query performance
numerologySchema.index({ user: 1, createdAt: -1 });
numerologySchema.index({ lifePathNumber: 1, destinyNumber: 1 });
numerologySchema.index({ name: 1 });

module.exports = mongoose.model('Numerology', numerologySchema); 