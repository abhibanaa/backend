const mongoose = require('mongoose');
const PaidKundli = require('./models/PaidKundli');
const User = require('./models/User');

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/astrology_app', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

async function cleanDuplicateOrders() {
  try {
    console.log('🔍 Starting duplicate order cleanup...');
    
    // Find all orders
    const allOrders = await PaidKundli.find({}).populate('user', 'user_uni_id');
    console.log(`📊 Total orders found: ${allOrders.length}`);
    
    // Group orders by user and order_for
    const orderGroups = {};
    
    allOrders.forEach(order => {
      const key = `${order.user.user_uni_id}_${order.order_for}`;
      if (!orderGroups[key]) {
        orderGroups[key] = [];
      }
      orderGroups[key].push(order);
    });
    
    let totalDuplicates = 0;
    let removedDuplicates = 0;
    
    // Process each group
    for (const [key, orders] of Object.entries(orderGroups)) {
      if (orders.length > 1) {
        console.log(`\n🔴 Found ${orders.length} orders for ${key}:`);
        
        // Sort by creation time (newest first)
        orders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        
        // Keep the newest order, remove the rest
        const [newestOrder, ...duplicates] = orders;
        
        console.log(`✅ Keeping newest order: ${newestOrder._id} (${newestOrder.createdAt})`);
        
        for (const duplicate of duplicates) {
          console.log(`🗑️  Removing duplicate: ${duplicate._id} (${duplicate.createdAt})`);
          await PaidKundli.findByIdAndDelete(duplicate._id);
          removedDuplicates++;
        }
        
        totalDuplicates += duplicates.length;
      }
    }
    
    console.log(`\n📈 Duplicate cleanup summary:`);
    console.log(`- Total duplicate orders found: ${totalDuplicates}`);
    console.log(`- Duplicate orders removed: ${removedDuplicates}`);
    
    // Now regenerate unique order IDs for remaining orders
    console.log('\n🔄 Regenerating unique order IDs...');
    
    const remainingOrders = await PaidKundli.find({});
    let updatedCount = 0;
    
    for (const order of remainingOrders) {
      // Generate new unique order ID
      const now = new Date();
      const datePrefix = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
      const sequenceNumber = (updatedCount + 1).toString().padStart(4, '0');
      const randomSuffix = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
      
      const newOrderId = `ORD${datePrefix}${sequenceNumber}${randomSuffix}`;
      
      // Update order with new orderId
      await PaidKundli.findByIdAndUpdate(order._id, { orderId: newOrderId });
      console.log(`✅ Updated order ${order._id} with new orderId: ${newOrderId}`);
      updatedCount++;
    }
    
    console.log(`\n🎉 Final summary:`);
    console.log(`- Remaining orders: ${remainingOrders.length}`);
    console.log(`- Orders with new unique IDs: ${updatedCount}`);
    
  } catch (error) {
    console.error('❌ Error:', error);
  } finally {
    mongoose.connection.close();
  }
}

cleanDuplicateOrders(); 