# Payment Flow Update: Order ID Generation with Payment ID

## Overview

The `/api/paidKundli/createCalculation` endpoint has been updated to implement a more secure payment flow where **order_id** is only generated when a **payment_id** is provided and the payment status is 'Completed'.

## Key Changes

### 1. New Payment Flow

**Before:**
- Order ID was generated immediately when payment_status = 'Completed'
- No payment verification required

**After:**
- Order ID is only generated when both conditions are met:
  - `payment_id` is provided
  - `payment_status` = 'Completed'

### 2. Updated API Parameters

#### POST `/api/paidKundli/createCalculation`

**New Parameters:**
- `payment_id` (optional): Payment ID from Razorpay or other payment gateway

**Example Request:**
```json
{
  "user_uni_id": "user123",
  "api_key": "api_key_123",
  "order_for": "horoscope",
  "pdf_type": "medium",
  "payment_status": "Completed",
  "payment_id": "pay_123456789"
}
```

**Response when payment_id is provided:**
```json
{
  "success": true,
  "message": "Order created successfully",
  "data": {
    "order_id": "ORD202412011234567890",
    "payment_id": "pay_123456789",
    "orderUrl": null,
    "pdf_type": "medium",
    "paymentStatus": "Completed",
    "totalAmount": 471
  }
}
```

**Response when payment_id is NOT provided:**
```json
{
  "success": true,
  "message": "Payment intent created successfully",
  "data": {
    "order_id": null,
    "payment_id": null,
    "orderUrl": null,
    "pdf_type": "medium",
    "paymentStatus": "Pending",
    "totalAmount": 471
  }
}
```

### 3. Updated Payment Status Update

#### PUT `/api/paidKundli/updatePaymentStatus/:id`

**New Validation:**
- `payment_id` is **required** when `payment_status` = 'Completed'
- Returns error if payment_id is missing for completed payments

**Example Request:**
```json
{
  "user_uni_id": "user123",
  "api_key": "api_key_123",
  "payment_status": "Completed",
  "payment_id": "pay_123456789"
}
```

**Error Response (missing payment_id):**
```json
{
  "success": false,
  "error": "payment_id is required when payment_status is \"Completed\""
}
```

## Implementation Details

### Code Changes

1. **createCalculation Function:**
   ```javascript
   // Only generate orderId if payment_id is provided AND payment_status is 'Completed'
   if (payment_id && payment_status === 'Completed') {
     // Generate unique orderId
     // Update record with orderId
   }
   ```

2. **updatePaymentStatus Function:**
   ```javascript
   // Require payment_id when status is 'Completed'
   if (payment_status === 'Completed' && !payment_id) {
     return next(new ErrorResponse('payment_id is required when payment_status is "Completed"', 400));
   }
   
   // Generate orderId if payment is completed, payment_id is provided, and orderId doesn't exist
   if (payment_status === 'Completed' && payment_id && !calculation.orderId) {
     // Generate unique orderId
   }
   ```

## Payment Flow Scenarios

### Scenario 1: Create Pending Payment
1. Call `/api/paidKundli/createCalculation` with `payment_status: 'Pending'`
2. No `order_id` is generated
3. Payment intent is created successfully

### Scenario 2: Complete Payment with Payment ID
1. Process payment through Razorpay
2. Get `payment_id` from Razorpay response
3. Call `/api/paidKundli/updatePaymentStatus/:id` with:
   - `payment_status: 'Completed'`
   - `payment_id: 'pay_123456789'`
4. `order_id` is automatically generated

### Scenario 3: Create Completed Order Directly
1. Call `/api/paidKundli/createCalculation` with:
   - `payment_status: 'Completed'`
   - `payment_id: 'pay_123456789'`
2. `order_id` is generated immediately

### Scenario 4: Invalid Completion (Missing Payment ID)
1. Call `/api/paidKundli/updatePaymentStatus/:id` with:
   - `payment_status: 'Completed'`
   - No `payment_id`
2. Returns error: "payment_id is required when payment_status is 'Completed'"

## Benefits

1. **Security:** Prevents order creation without proper payment verification
2. **Audit Trail:** Payment ID provides traceability to payment gateway
3. **Data Integrity:** Ensures orders are only created after successful payments
4. **Flexibility:** Supports both pending and completed payment flows

## Testing

Use the provided test file `test-paid-kundli-payment-flow.html` to test all scenarios:

1. **Test 1:** Create pending calculation (no order_id)
2. **Test 2:** Try to complete without payment_id (should fail)
3. **Test 3:** Complete with payment_id (should succeed and generate order_id)
4. **Test 4:** Create completed calculation directly with payment_id

## Migration Notes

- Existing pending orders will continue to work
- Orders without payment_id will need to be updated with payment_id to generate order_id
- No breaking changes for existing completed orders

## API Documentation Updates

### Required Parameters for Order ID Generation

| Parameter | Required | Description |
|-----------|----------|-------------|
| `payment_id` | Yes (for completed payments) | Payment ID from payment gateway |
| `payment_status` | Yes | Must be 'Completed' for order_id generation |

### Response Format Changes

All responses now include `payment_id` field:
```json
{
  "data": {
    "order_id": "ORD202412011234567890",
    "payment_id": "pay_123456789",
    "paymentStatus": "Completed",
    // ... other fields
  }
}
``` 