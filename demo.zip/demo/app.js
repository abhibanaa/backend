const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const dotenv = require('dotenv');

// Load env vars
dotenv.config();

// Import routes
const authRoutes = require('./routes/authRoutes');
const kundaliRoutes = require('./routes/kundaliRoutes');

const horoscopeRoutes = require('./routes/horoscopeRoutes');
const panchangRoutes = require('./routes/panchangRoutes');
const numerologyRoutes = require('./routes/numerologyRoutes');

// Import error handler
const errorHandler = require('./middlewares/errorHandler');

const app = express();

// Security middleware
app.use(helmet());

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: {
    success: false,
    message: 'Too many requests from this IP, please try again later.'
  }
});
app.use('/api/', limiter);

// Body parser
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// CORS
app.use(cors({
  origin: process.env.NODE_ENV === 'production' 
    ? ['https://yourdomain.com', 'https://www.yourdomain.com']
    : ['http://localhost:3000', 'http://localhost:3001', 'http://127.0.0.1:5500', 'http://localhost:5500'],
  credentials: true
}));

// Logging middleware
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
}

// Serve static files for admin panel
app.use('/admin-panel', express.static('admin-panel'));
app.get('/admin-panel', (req, res) => {
  res.sendFile(__dirname + '/admin-panel/index.html');
});
app.get('/admin-panel/', (req, res) => {
  res.sendFile(__dirname + '/admin-panel/index.html');
});

// Serve uploaded files
app.use('/uploads', express.static('uploads'));

// Health check route
app.get('/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Astrology App API is running',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV
  });
});

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/kundali', kundaliRoutes);
app.use('/api/kundli', require('./apis/kundli/kundliRoutes'));
app.use('/api/matching', require('./apis/matching/matchingRoutes'));
app.use('/api/paidKundli', require('./apis/paidKundli/paidKundliRoutes'));

app.use('/api/pdf', require('./apis/pdf/pdfRoutes'));

app.use('/api/horoscope', horoscopeRoutes);
app.use('/api/panchang', panchangRoutes);
app.use('/api/numerology', numerologyRoutes);
// App Razorpay routes (public)
app.use('/api/app/razorpay', require('./apis/razorpay/appRazorpayRoutes'));

// Admin Razorpay routes (protected)
app.use('/api/admin/razorpay', require('./apis/razorpay/adminRazorpayRoutes'));

// API documentation route
app.get('/api', (req, res) => {
  res.json({
    success: true,
    message: 'Astrology App API',
    version: '1.0.0',
    endpoints: {
      auth: {
        register: 'POST /api/auth/register',
        login: 'POST /api/auth/login',
        logout: 'POST /api/auth/logout',
        getMe: 'GET /api/auth/me',
        updateDetails: 'PUT /api/auth/updatedetails',
        deleteAccount: 'DELETE /api/auth/delete-account',
        sendOTP: 'POST /api/auth/send-otp',

        adminLogin: 'POST /api/auth/admin/login'
      },
       kundli: {
          saveKundliData: 'POST /api/kundli/saveKundliData',
          userKundaliRequest: 'GET /api/kundli/userKundaliRequest',
          getKundliById: 'GET /api/kundli/:id',
          editKundliData: 'PUT /api/kundli/editKundliData/:id',
          deleteKundali: 'DELETE /api/kundli/deleteKundali/:id',
          
          analyzeKundli: 'POST /api/kundli/:id/analyze',
          getKundlisByZodiac: 'GET /api/kundli/zodiac/:sign (Admin)',
          getAllKundlis: 'GET /api/kundli/admin/all (Admin)'
        },
        matching: {
          saveMatching: 'POST /api/matching/saveMatching',
          userKundaliMatchingRequest: 'GET /api/matching/userKundaliMatchingRequest',
          getMatchingById: 'GET /api/matching/:id',
          editKundaliMatching: 'PUT /api/matching/editKundaliMatching/:id',
          deleteKundaliMatching: 'DELETE /api/matching/deleteKundaliMatching/:id'
        },
        paidKundli: { 
          createCalculation: 'POST /api/paidKundli/createCalculation',
          getAllPricing: 'GET /api/paidKundli/getAllPricing',
          getOrderList: 'GET /api/paidKundli/order-list?user_uni_id=xxx&api_key=xxx&order_id=xxx (optional)&orderUrl=xxx (optional)',
          getPricing: 'GET /api/paidKundli/pricing',
          updatePricing: 'PUT /api/paidKundli/updatePricing (Admin)'
        },

        pdf: {
          getAllPDFs: 'GET /api/pdf',
          getPDFById: 'GET /api/pdf/:id',
          downloadPDF: 'GET /api/pdf/:id/download',
          createPDF: 'POST /api/pdf (Admin - Bearer Token)',
          updatePDF: 'PUT /api/pdf/:id (Admin - Bearer Token)',
          deletePDF: 'DELETE /api/pdf/:id (Admin - Bearer Token)',
          getPDFStats: 'GET /api/pdf/stats (Admin - Bearer Token)'
        },

      horoscope: {
        getAll: 'GET /api/horoscope',
        getOne: 'GET /api/horoscope/:id',
        daily: 'GET /api/horoscope/daily',
        weekly: 'GET /api/horoscope/weekly',
        byZodiacType: 'GET /api/horoscope/:zodiacSign/:type',
        personalized: 'POST /api/horoscope/personalized',
        getPersonalized: 'GET /api/horoscope/personalized'
      },
      panchang: {
        getAll: 'GET /api/panchang',
        getOne: 'GET /api/panchang/:id',
        byDate: 'GET /api/panchang/date/:date',
        byLocation: 'GET /api/panchang/location/:location',
        muhurat: 'GET /api/panchang/muhurat/:date',
        festivals: 'GET /api/panchang/festivals',
        today: 'GET /api/panchang/today'
      },
      numerology: {
        create: 'POST /api/numerology',
        getAll: 'GET /api/numerology',
        getOne: 'GET /api/numerology/:id',
        update: 'PUT /api/numerology/:id',
        delete: 'DELETE /api/numerology/:id',
        detailed: 'POST /api/numerology/:id/detailed',
        byLifePath: 'GET /api/numerology/life-path/:number'
      },
      razorpay: {
        // App API (Public) - For main application
        getActiveConfig: 'GET /api/app/razorpay/config/:environment - Get config for payments',
        // Admin API (Protected) - For managing Razorpay configurations
        adminCreate: 'POST /api/admin/razorpay/config (Admin - Bearer Token) - Create new config',
        adminUpdate: 'PUT /api/admin/razorpay/config/:id (Admin - Bearer Token) - Update Razorpay ID, Key, Account',
        adminToggle: 'PATCH /api/admin/razorpay/config/:id/toggle (Admin - Bearer Token) - Toggle active status',
        adminGetAll: 'GET /api/admin/razorpay/config (Admin - Bearer Token) - View all configs',
        adminGetById: 'GET /api/admin/razorpay/config/:id (Admin - Bearer Token) - View specific config',
        adminDelete: 'DELETE /api/admin/razorpay/config/:id (Admin - Bearer Token) - Delete config'
      }
    },
    authentication: 'Use Bearer token in Authorization header for protected routes'
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    success: false,
    message: `Route ${req.originalUrl} not found`
  });
});

// Error handler middleware
app.use(errorHandler);

module.exports = app; 