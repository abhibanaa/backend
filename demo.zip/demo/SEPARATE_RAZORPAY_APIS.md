# Separate Razorpay APIs Documentation

## Overview
This system now has **two separate Razorpay APIs** - one for the main application (public) and one for the admin panel (protected). This separation ensures better security and access control.

## 🏗️ Architecture

### 📱 App API (`/api/app/razorpay`)
- **Access:** Public (no authentication required)
- **Purpose:** For main application to get Razorpay configurations
- **Security:** Returns masked sensitive data
- **Use Case:** Payment processing, client-side integration

### ⚙️ Admin API (`/api/admin/razorpay`)
- **Access:** Protected (admin authentication required)
- **Purpose:** For admin panel to manage Razorpay configurations
- **Security:** Returns full data with admin authentication
- **Use Case:** Configuration management, admin operations

## 📱 App API Endpoints

### 1. Get Active Configuration by Environment
**GET** `/api/app/razorpay/config/:environment`

**Access:** Public

**Parameters:**
- `environment` (path): `test` or `live`

**Response:**
```json
{
  "success": true,
  "message": "Active Razorpay configuration retrieved successfully",
  "data": {
    "id": "64f8a1b2c3d4e5f6a7b8c9d0",
    "razorpayId": "rzp_test_xxxxxxxxxxxxx",
    "razorpayKey": "***xxxx",
    "razorpayXAccount": "xxxxxxxxxxxxxxxxxxxxxxxx",
    "isActive": true,
    "environment": "test",
    "description": "Test environment configuration",
    "updatedAt": "2023-09-06T10:30:00.000Z",
    "createdAt": "2023-09-06T10:30:00.000Z"
  }
}
```

### 2. Get All Active Configurations
**GET** `/api/app/razorpay/configs`

**Access:** Public

**Response:**
```json
{
  "success": true,
  "message": "Active Razorpay configurations retrieved successfully",
  "data": [
    {
      "id": "64f8a1b2c3d4e5f6a7b8c9d0",
      "razorpayId": "rzp_test_xxxxxxxxxxxxx",
      "razorpayKey": "***xxxx",
      "razorpayXAccount": "xxxxxxxxxxxxxxxxxxxxxxxx",
      "isActive": true,
      "environment": "test",
      "description": "Test environment configuration"
    }
  ]
}
```

### 3. Check Configuration Status
**GET** `/api/app/razorpay/status`

**Access:** Public

**Response:**
```json
{
  "success": true,
  "message": "Razorpay configuration status retrieved successfully",
  "data": {
    "test": {
      "available": true,
      "environment": "test"
    },
    "live": {
      "available": false,
      "environment": "live"
    }
  }
}
```

## ⚙️ Admin API Endpoints

### 1. Create Configuration
**POST** `/api/admin/razorpay/config`

**Access:** Admin only

**Request Body:**
```json
{
  "razorpayId": "rzp_test_xxxxxxxxxxxxx",
  "razorpayKey": "xxxxxxxxxxxxxxxxxxxxxxxx",
  "razorpayXAccount": "xxxxxxxxxxxxxxxxxxxxxxxx",
  "environment": "test",
  "description": "Test environment configuration"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Razorpay configuration created successfully",
  "data": {
    "id": "64f8a1b2c3d4e5f6a7b8c9d0",
    "razorpayId": "rzp_test_xxxxxxxxxxxxx",
    "razorpayKey": "xxxxxxxxxxxxxxxxxxxxxxxx",
    "razorpayXAccount": "xxxxxxxxxxxxxxxxxxxxxxxx",
    "isActive": true,
    "environment": "test",
    "description": "Test environment configuration",
    "updatedBy": "64f8a1b2c3d4e5f6a7b8c9d1",
    "updatedAt": "2023-09-06T10:30:00.000Z",
    "createdAt": "2023-09-06T10:30:00.000Z"
  }
}
```

### 2. Get All Configurations
**GET** `/api/admin/razorpay/config`

**Access:** Admin only

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10)
- `environment` (optional): Filter by environment
- `isActive` (optional): Filter by status

**Response:**
```json
{
  "success": true,
  "message": "Razorpay configurations retrieved successfully",
  "data": {
    "docs": [
      {
        "id": "64f8a1b2c3d4e5f6a7b8c9d0",
        "razorpayId": "rzp_test_xxxxxxxxxxxxx",
        "razorpayKey": "xxxxxxxxxxxxxxxxxxxxxxxx",
        "razorpayXAccount": "xxxxxxxxxxxxxxxxxxxxxxxx",
        "isActive": true,
        "environment": "test",
        "description": "Test environment configuration",
        "updatedBy": {
          "id": "64f8a1b2c3d4e5f6a7b8c9d1",
          "name": "Admin User",
          "email": "admin@example.com"
        },
        "updatedAt": "2023-09-06T10:30:00.000Z",
        "createdAt": "2023-09-06T10:30:00.000Z"
      }
    ],
    "totalDocs": 1,
    "limit": 10,
    "page": 1,
    "totalPages": 1,
    "hasNextPage": false,
    "hasPrevPage": false
  }
}
```

### 3. Get Configuration by ID
**GET** `/api/admin/razorpay/config/:id`

**Access:** Admin only

### 4. Update Configuration
**PUT** `/api/admin/razorpay/config/:id`

**Access:** Admin only

### 5. Delete Configuration
**DELETE** `/api/admin/razorpay/config/:id`

**Access:** Admin only

### 6. Toggle Configuration Status
**PATCH** `/api/admin/razorpay/config/:id/toggle`

**Access:** Admin only

### 7. Get Configuration Statistics
**GET** `/api/admin/razorpay/stats`

**Access:** Admin only

**Response:**
```json
{
  "success": true,
  "message": "Razorpay configuration statistics retrieved successfully",
  "data": {
    "total": 2,
    "active": 1,
    "inactive": 1,
    "test": 1,
    "live": 1
  }
}
```

## 🔐 Authentication

### App API
- **No authentication required**
- **Public access**
- **Safe for client-side use**

### Admin API
- **Bearer token authentication required**
- **Admin role required**
- **Headers:** `Authorization: Bearer YOUR_ADMIN_TOKEN`

## 🛡️ Security Features

### App API Security
- ✅ **Masked sensitive data** (razorpayKey shows only last 4 characters)
- ✅ **Read-only access**
- ✅ **No authentication required**
- ✅ **Safe for public use**

### Admin API Security
- ✅ **Full authentication required**
- ✅ **Admin role verification**
- ✅ **Complete data access**
- ✅ **Full CRUD operations**
- ✅ **Audit trail tracking**

## 📊 Data Comparison

| Feature | App API | Admin API |
|---------|---------|-----------|
| **Authentication** | ❌ None | ✅ Required |
| **Razorpay Key** | 🔒 Masked | 🔓 Full |
| **Operations** | 📖 Read Only | ✏️ Full CRUD |
| **Access** | 🌐 Public | 🔐 Admin Only |
| **Use Case** | 💳 Payments | ⚙️ Management |

## 🚀 Usage Examples

### App API Usage (Client-side)
```javascript
// Get active test configuration for payments
const getPaymentConfig = async () => {
  const response = await fetch('/api/app/razorpay/config/test');
  const data = await response.json();
  
  if (data.success) {
    // Use data.data.razorpayId and data.data.razorpayXAccount
    // Note: razorpayKey is masked for security
    console.log('Payment config loaded:', data.data);
  }
};

// Check if configurations are available
const checkConfigStatus = async () => {
  const response = await fetch('/api/app/razorpay/status');
  const data = await response.json();
  
  if (data.data.test.available) {
    console.log('Test environment is ready');
  }
};
```

### Admin API Usage (Server-side)
```javascript
// Create new configuration
const createConfig = async (configData) => {
  const response = await fetch('/api/admin/razorpay/config', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${adminToken}`
    },
    body: JSON.stringify(configData)
  });
  
  return await response.json();
};

// Get all configurations for admin panel
const getAllConfigs = async () => {
  const response = await fetch('/api/admin/razorpay/config', {
    headers: {
      'Authorization': `Bearer ${adminToken}`
    }
  });
  
  return await response.json();
};
```

## 🔄 Migration from Single API

If you were using the old single API (`/api/razorpay`), here's how to migrate:

### Old API → New API
- `GET /api/razorpay/config/active/:environment` → `GET /api/app/razorpay/config/:environment`
- `GET /api/razorpay/config` → `GET /api/admin/razorpay/config`
- `POST /api/razorpay/config` → `POST /api/admin/razorpay/config`
- `PUT /api/razorpay/config/:id` → `PUT /api/admin/razorpay/config/:id`
- `DELETE /api/razorpay/config/:id` → `DELETE /api/admin/razorpay/config/:id`

## 📝 Notes

- **App API** is designed for public use and payment processing
- **Admin API** is designed for configuration management
- Both APIs use the same database model but different access levels
- Admin panel automatically uses the Admin API
- Main application should use the App API for payment integration
- The separation ensures better security and access control 