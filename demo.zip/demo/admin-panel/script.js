// Global Variables
let authToken = localStorage.getItem('adminToken');
let currentUser = null;
let charts = {};

// API Configuration
const API_BASE_URL = 'http://localhost:5000/api';

// Admin Credentials
const ADMIN_USERNAME = 'admin123';
const ADMIN_PASSWORD = 'admin@123';

// Initialize Admin Panel
document.addEventListener('DOMContentLoaded', function() {
    // Clear any old invalid tokens on page load
    const oldToken = localStorage.getItem('adminToken');
    if (oldToken && oldToken.includes('admin-token-')) {
        localStorage.removeItem('adminToken');
        localStorage.removeItem('adminUser');
        authToken = null;
        currentUser = null;
    }
    
    initializeApp();
});

function initializeApp() {
    // Hide loading screen after 2 seconds
    setTimeout(() => {
        document.getElementById('loadingScreen').style.display = 'none';
        
        if (authToken) {
            // Check if token is valid
            checkAuthStatus();
        } else {
            showLoginScreen();
        }
    }, 2000);

    // Event Listeners
    setupEventListeners();
}

function setupEventListeners() {
    // Login Form
    document.getElementById('loginForm').addEventListener('submit', handleLogin);
    
    // Navigation
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', () => switchSection(item.dataset.section));
    });
    
    // Logout
    document.getElementById('logoutBtn').addEventListener('click', handleLogout);
    
    // Edit User Form
    document.getElementById('editUserForm').addEventListener('submit', handleEditUser);
    
    // Add User Form
    document.getElementById('addUserForm').addEventListener('submit', handleAddUser);
    
    // Add PDF Form
    document.getElementById('addPDFForm').addEventListener('submit', handleAddPDF);
    
    // Update Pricing Form
    document.getElementById('updatePricingForm').addEventListener('submit', handleUpdatePricing);
    
    // Razorpay Configuration Form
    document.getElementById('razorpayForm').addEventListener('submit', handleRazorpayForm);
    
    // PDF Filters
    document.getElementById('pdfSearchInput').addEventListener('input', debounce(filterPDFs, 300));
    document.getElementById('pdfCategoryFilter').addEventListener('change', filterPDFs);
    document.getElementById('pdfLanguageFilter').addEventListener('change', filterPDFs);
    
    // Order Filters
    document.getElementById('orderTypeFilter').addEventListener('change', filterOrders);
    document.getElementById('orderStatusFilter').addEventListener('change', filterOrders);
}

// Authentication Functions
async function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('usernameInput').value;
    const password = document.getElementById('passwordInput').value;
    
    if (!username || !password) {
        showToast('Please enter username and password', 'error');
        return;
    }
    
    try {
        showLoading('Logging in...');
        console.log('Attempting admin login with:', { username });
        
                // Use the admin login API endpoint
        const response = await fetch(`${API_BASE_URL}/auth/admin/login`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        console.log('Admin login response:', data);
        
        if (data.success) {
          authToken = data.token;
          currentUser = data.user;
          
          console.log('Admin login successful:', currentUser);
          
          // Clear any old tokens and set new ones
          localStorage.removeItem('adminToken');
          localStorage.removeItem('adminUser');
          localStorage.setItem('adminToken', authToken);
          localStorage.setItem('adminUser', JSON.stringify(currentUser));
          
          hideLoginScreen();
          showDashboard();
          loadDashboardData();
          
          showToast('Admin login successful!', 'success');
        } else {
          throw new Error(data.message || 'Invalid admin credentials');
        }
    } catch (error) {
        console.error('Login error:', error);
        showToast(error.message || 'Login failed. Please check your credentials.', 'error');
    } finally {
        hideLoading();
    }
}

// Admin authentication functions removed - using local admin credentials instead

async function checkAuthStatus() {
    try {
        // For admin panel, check if we have admin token
        if (authToken) {
            // Verify token with backend
            const response = await fetch(`${API_BASE_URL}/auth/me`, {
                headers: {
                    'Authorization': `Bearer ${authToken}`
                }
            });
            
            const data = await response.json();
            
            if (data.success) {
                currentUser = data.data;
                showDashboard();
                loadDashboardData();
                return;
            }
        }
        
        // If no valid admin token, show login
        throw new Error('Not authorized');
    } catch (error) {
        console.error('Auth check error:', error);
        localStorage.removeItem('adminToken');
        localStorage.removeItem('adminUser');
        showLoginScreen();
    }
}

function handleLogout() {
    localStorage.removeItem('adminToken');
    localStorage.removeItem('adminUser');
    authToken = null;
    currentUser = null;
    showLoginScreen();
    showToast('Logged out successfully', 'success');
}

// UI Functions
function showLoginScreen() {
    document.getElementById('loginScreen').style.display = 'flex';
    document.getElementById('dashboard').classList.add('hidden');
}

function hideLoginScreen() {
    document.getElementById('loginScreen').style.display = 'none';
}

function showDashboard() {
    document.getElementById('dashboard').classList.remove('hidden');
    document.getElementById('adminName').textContent = currentUser?.name || 'Admin';
}

function switchSection(sectionName) {
    // Update navigation
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    document.querySelector(`[data-section="${sectionName}"]`).classList.add('active');
    
    // Update content
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(sectionName).classList.add('active');
    
    // Update page title
    const titles = {
        overview: 'Dashboard Overview',
        users: 'User Management',
        horoscopes: 'Horoscope Management',
        kundali: 'Kundali Management',
        matching: 'Compatibility Matching',
        panchang: 'Panchang Management',
        numerology: 'Numerology Management'
    };
    document.getElementById('pageTitle').textContent = titles[sectionName] || 'Dashboard';
    
    // Load section data
    switch(sectionName) {
        case 'overview':
            loadDashboardData();
            break;
        case 'users':
            loadUsers();
            break;
        case 'horoscopes':
            loadHoroscopes();
            break;
        case 'kundali':
            loadKundaliStats();
            break;
        case 'matching':
            loadMatchingStats();
            break;
        case 'panchang':
            loadPanchangData();
            break;
        case 'numerology':
            loadNumerologyStats();
            break;
        case 'paidKundli':
            loadPaidKundliStats();
            loadRecentOrders();
            break;
        case 'pdf':
            loadPDFStats();
            loadPDFs();
            break;
        case 'pricing':
            loadPricingConfig();
            break;
        case 'razorpay':
            loadRazorpayConfigs();
            break;
    }
}

// Dashboard Data Loading
async function loadDashboardData() {
    try {
        // Fetch real dashboard stats from API
        const response = await fetch(`${API_BASE_URL}/auth/admin/dashboard`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        console.log('Dashboard data:', data);
        
        if (data.success) {
            const stats = data.data;
            updateDashboardStats(stats);
            createCharts(stats);
            showToast('Dashboard loaded successfully', 'success');
        } else {
            throw new Error(data.message || 'Failed to load dashboard data');
        }
    } catch (error) {
        console.error('Dashboard error:', error);
        showToast('Failed to load dashboard data', 'error');
    }
}

function updateDashboardStats(stats) {
    const elements = {
        'totalUsers': stats.totalUsers,
        'activeUsers': stats.activeUsers,
        'completeProfiles': stats.completeProfiles,
        'incompleteProfiles': stats.incompleteProfiles,
        'newUsersWeek': stats.newUsersThisWeek,
        'adminUsers': stats.adminUsers,
        'completionRate': `${stats.completionRate}%`
    };
    
    Object.keys(elements).forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = elements[id];
        } else {
            console.warn(`Element with id '${id}' not found`);
        }
    });
}

function createCharts(stats) {
    // User Growth Chart
    const userGrowthCtx = document.getElementById('userGrowthChart').getContext('2d');
    if (charts.userGrowth) {
        charts.userGrowth.destroy();
    }
    
    charts.userGrowth = new Chart(userGrowthCtx, {
        type: 'line',
        data: {
            labels: ['Total Users', 'Active Users', 'Complete Profiles'],
            datasets: [{
                label: 'User Statistics',
                data: [stats.totalUsers, stats.activeUsers, stats.completeProfiles],
                borderColor: '#667eea',
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    
    // Profile Completion Chart
    const profileCompletionCtx = document.getElementById('profileCompletionChart').getContext('2d');
    if (charts.profileCompletion) {
        charts.profileCompletion.destroy();
    }
    
    charts.profileCompletion = new Chart(profileCompletionCtx, {
        type: 'doughnut',
        data: {
            labels: ['Complete', 'Incomplete'],
            datasets: [{
                data: [stats.completeProfiles, stats.incompleteProfiles],
                backgroundColor: ['#10b981', '#f59e0b']
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

// User Management
async function loadUsers() {
    try {
        // Fetch real users from API
        const response = await fetch(`${API_BASE_URL}/auth/admin/users`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        console.log('Users data:', data);
        
        if (data.success) {
            renderUsersTable(data.data);
            showToast(`Loaded ${data.count} users`, 'success');
        } else {
            throw new Error(data.message || 'Failed to load users');
        }
    } catch (error) {
        console.error('Load users error:', error);
        showToast('Failed to load users', 'error');
    }
}

function renderUsersTable(users) {
    const userList = document.getElementById('userList');
    userList.innerHTML = '';
    
    users.forEach(user => {
        // Format date of birth
        const dateOfBirth = user.dateOfBirth ? new Date(user.dateOfBirth).toLocaleDateString() : 'N/A';
        
        // Format registration date
        const registrationDate = user.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'N/A';
        
        // Get first letter of name for avatar
        const avatarLetter = user.name ? user.name.charAt(0).toUpperCase() : 'U';
        
        const userCard = document.createElement('div');
        userCard.className = 'user-card';
        userCard.dataset.userId = user._id;
        userCard.onclick = () => selectUser(user);
        
        userCard.innerHTML = `
            <div class="user-card-header">
                <div class="user-avatar">${avatarLetter}</div>
                <div class="user-info">
                    <h4>${user.name || 'Unknown User'}</h4>
                    <p>${user.email || user.phone}</p>
                </div>
            </div>
            <div class="user-card-footer">
                <div class="user-status">
                    <div class="status-dot ${user.isActive ? 'active' : 'inactive'}"></div>
                    <span class="status-text">${user.isActive ? 'Active' : 'Inactive'}</span>
                </div>
                <span class="role-badge role-${user.role}">${user.role}</span>
            </div>
        `;
        
        userList.appendChild(userCard);
    });
    
    // Store users data globally for access
    window.usersData = users;
}

async function editUser(userId) {
    try {
        // Fetch real user data from API
        const response = await fetch(`${API_BASE_URL}/auth/admin/users/${userId}`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        console.log('User data:', data);
        
        if (data.success) {
            const user = data.data;
            
            document.getElementById('editUserName').value = user.name || '';
            document.getElementById('editUserEmail').value = user.email || '';
            
            // Handle phone number with country code
            if (user.phone) {
                const phoneParts = parsePhoneNumber(user.phone);
                document.getElementById('editUserCountryCode').value = phoneParts.countryCode;
                document.getElementById('editUserPhone').value = phoneParts.number;
            } else {
                document.getElementById('editUserCountryCode').value = '+91';
                document.getElementById('editUserPhone').value = '';
            }
            
            // Format date for input field
            const dateOfBirth = user.dateOfBirth ? new Date(user.dateOfBirth).toISOString().split('T')[0] : '';
            document.getElementById('editUserDateOfBirth').value = dateOfBirth;
            
            document.getElementById('editUserTimeOfBirth').value = user.timeOfBirth || '';
            document.getElementById('editUserPlaceOfBirth').value = user.placeOfBirth || '';
            
            document.getElementById('editUserRole').value = user.role || 'user';
            document.getElementById('editUserStatus').value = user.isActive.toString();
            
            document.getElementById('editUserForm').dataset.userId = userId;
            showModal('userModal');
            
            // Reinitialize places autocomplete for the modal
            setTimeout(() => {
                const editUserPlaceInput = document.getElementById('editUserPlaceOfBirth');
                const editUserDropdown = document.getElementById('editUserPlacesDropdown');
                if (editUserPlaceInput && editUserDropdown) {
                    setupPlacesAutocomplete(editUserPlaceInput, editUserDropdown);
                }
            }, 100);
        } else {
            throw new Error(data.message || 'Failed to load user data');
        }
    } catch (error) {
        console.error('Edit user error:', error);
        showToast('Failed to load user data', 'error');
    }
}

async function handleEditUser(e) {
    e.preventDefault();
    
    const userId = e.target.dataset.userId;
    
    try {
        showLoading('Updating user...');
        
        console.log('Updating user data');
        const countryCode = document.getElementById('editUserCountryCode').value;
        const phoneNumber = document.getElementById('editUserPhone').value;
        const fullPhone = countryCode + phoneNumber;
        
        const formData = {
            name: document.getElementById('editUserName').value,
            email: document.getElementById('editUserEmail').value,
            phone: fullPhone,
            dateOfBirth: document.getElementById('editUserDateOfBirth').value,
            timeOfBirth: document.getElementById('editUserTimeOfBirth').value,
            placeOfBirth: document.getElementById('editUserPlaceOfBirth').value,
            role: document.getElementById('editUserRole').value,
            isActive: document.getElementById('editUserStatus').value === 'true'
        };
        
        const response = await fetch(`${API_BASE_URL}/auth/admin/users/${userId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(formData)
        });
        
        console.log('Response status:', response.status);
        const responseText = await response.text();
        console.log('Response text:', responseText);
        
        let data;
        try {
            data = JSON.parse(responseText);
        } catch (parseError) {
            console.error('Failed to parse JSON:', parseError);
            throw new Error('Invalid response from server');
        }
        
        console.log('Update user response:', data);
        
        if (data.success) {
            showToast('User updated successfully', 'success');
            closeModal('userModal');
            loadUsers(); // Refresh the users list
        } else {
            throw new Error(data.message || 'Failed to update user');
        }
    } catch (error) {
        console.error('Update user error:', error);
        showToast('Failed to update user: ' + error.message, 'error');
    } finally {
        hideLoading();
    }
}

async function deleteUser(userId) {
    if (!confirm('Are you sure you want to delete this user?')) {
        return;
    }
    
    try {
        // Delete user via API
        const response = await fetch(`${API_BASE_URL}/auth/admin/users/${userId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        console.log('Delete user response:', data);
        
        if (data.success) {
            showToast('User deleted successfully', 'success');
            loadUsers(); // Refresh the users list
        } else {
            throw new Error(data.message || 'Failed to delete user');
        }
    } catch (error) {
        console.error('Delete user error:', error);
        showToast('Failed to delete user', 'error');
    }
}

function refreshUsers() {
    loadUsers();
    showToast('Users refreshed', 'success');
}

// New functions for vertical slider
let selectedUserId = null;

function selectUser(user) {
    // Remove previous selection
    document.querySelectorAll('.user-card').forEach(card => {
        card.classList.remove('selected');
    });
    
    // Add selection to clicked card
    const userCard = document.querySelector(`[data-user-id="${user._id}"]`);
    if (userCard) {
        userCard.classList.add('selected');
    }
    
    selectedUserId = user._id;
    displayUserDetails(user);
}

function displayUserDetails(user) {
    const userDetails = document.getElementById('userDetails');
    
    // Format dates
    const dateOfBirth = user.dateOfBirth ? new Date(user.dateOfBirth).toLocaleDateString() : 'N/A';
    const createdAt = user.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'N/A';
    
    // Get first letter of name for avatar
    const avatarLetter = user.name ? user.name.charAt(0).toUpperCase() : 'U';
    
    userDetails.innerHTML = `
        <div class="user-details-content">
            <div class="user-profile-header">
                <div class="user-avatar-large">${avatarLetter}</div>
                <div class="user-basic-info">
                    <h3>${user.name || 'Unknown User'}</h3>
                    <p class="user-email">${user.email || 'No email'}</p>
                    <p class="user-phone">${user.phone || 'No phone'}</p>
                </div>
                <div class="user-status-info">
                    <div class="status-badge ${user.isActive ? 'active' : 'inactive'}">
                        ${user.isActive ? 'Active' : 'Inactive'}
                    </div>
                    <div class="role-badge role-${user.role}">
                        ${user.role}
                    </div>
                </div>
            </div>
            
            <div class="user-details-grid">
                <div class="detail-section">
                    <h4>Personal Information</h4>
                    <div class="detail-item">
                        <span class="detail-label">User ID:</span>
                        <span class="detail-value">${user._id || 'N/A'}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Name:</span>
                        <span class="detail-value">${user.name || 'N/A'}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Email:</span>
                        <span class="detail-value">${user.email || 'N/A'}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Phone:</span>
                        <span class="detail-value">${user.phone || 'N/A'}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Date of Birth:</span>
                        <span class="detail-value">${dateOfBirth}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Time of Birth:</span>
                        <span class="detail-value">${user.timeOfBirth || 'N/A'}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Place of Birth:</span>
                        <span class="detail-value">${user.placeOfBirth || 'N/A'}</span>
                    </div>
                </div>
                
                <div class="detail-section">
                    <h4>Account Information</h4>
                    <div class="detail-item">
                        <span class="detail-label">Role:</span>
                        <span class="detail-value">
                            <span class="role-badge role-${user.role}">${user.role}</span>
                        </span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Status:</span>
                        <span class="detail-value">
                            <span class="status-badge ${user.isActive ? 'active' : 'inactive'}">
                                ${user.isActive ? 'Active' : 'Inactive'}
                            </span>
                        </span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Profile Complete:</span>
                        <span class="detail-value">
                            <span class="status-badge ${user.isProfileComplete ? 'active' : 'inactive'}">
                                ${user.isProfileComplete ? 'Yes' : 'No'}
                            </span>
                        </span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Created:</span>
                        <span class="detail-value">${createdAt}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Last Updated:</span>
                        <span class="detail-value">${user.updatedAt ? new Date(user.updatedAt).toLocaleDateString() : 'N/A'}</span>
                    </div>
                </div>
            </div>
            
            ${user.profileImage ? `
                <div class="user-profile-image">
                    <h4>Profile Image</h4>
                    <img src="${user.profileImage}" alt="Profile" class="profile-image">
                </div>
            ` : ''}
        </div>
    `;
}

function editSelectedUser() {
    if (selectedUserId) {
        editUser(selectedUserId);
    } else {
        showToast('Please select a user first', 'error');
    }
}

function deleteSelectedUser() {
    if (selectedUserId) {
        deleteUser(selectedUserId);
    } else {
        showToast('Please select a user first', 'error');
    }
}

// Add User Functions
function showAddUserModal() {
    // Clear the form
    document.getElementById('addUserForm').reset();
    showModal('addUserModal');
    
    // Reinitialize places autocomplete for the modal
    setTimeout(() => {
        const addUserPlaceInput = document.getElementById('addUserPlaceOfBirth');
        const addUserDropdown = document.getElementById('addUserPlacesDropdown');
        if (addUserPlaceInput && addUserDropdown) {
            setupPlacesAutocomplete(addUserPlaceInput, addUserDropdown);
        }
    }, 100);
}

async function handleAddUser(e) {
    e.preventDefault();
    
    try {
        showLoading('Creating user...');
        
        const countryCode = document.getElementById('addUserCountryCode').value;
        const phoneNumber = document.getElementById('addUserPhone').value;
        const fullPhone = countryCode + phoneNumber;
        
        const userData = {
            name: document.getElementById('addUserName').value,
            email: document.getElementById('addUserEmail').value,
            phone: fullPhone,
            dateOfBirth: document.getElementById('addUserDateOfBirth').value || null,
            timeOfBirth: document.getElementById('addUserTimeOfBirth').value || null,
            placeOfBirth: document.getElementById('addUserPlaceOfBirth').value || null,
            role: document.getElementById('addUserRole').value,
            isActive: document.getElementById('addUserStatus').value === 'true'
        };
        
        console.log('Creating user with data:', userData);
        
        const response = await fetch(`${API_BASE_URL}/auth/admin/users`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(userData)
        });
        
        console.log('Response status:', response.status);
        const responseText = await response.text();
        console.log('Response text:', responseText);
        
        let data;
        try {
            data = JSON.parse(responseText);
        } catch (parseError) {
            console.error('Failed to parse JSON:', parseError);
            throw new Error('Invalid response from server');
        }
        
        console.log('Create user response:', data);
        
        if (data.success) {
            showToast('User created successfully', 'success');
            closeModal('addUserModal');
            loadUsers(); // Refresh the users list
        } else {
            throw new Error(data.message || 'Failed to create user');
        }
    } catch (error) {
        console.error('Create user error:', error);
        showToast(error.message || 'Failed to create user', 'error');
    } finally {
        hideLoading();
    }
}

// Search functionality
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('userSearchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const userCards = document.querySelectorAll('.user-card');
            
            userCards.forEach(card => {
                const userName = card.querySelector('h4').textContent.toLowerCase();
                const userEmail = card.querySelector('p').textContent.toLowerCase();
                
                if (userName.includes(searchTerm) || userEmail.includes(searchTerm)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    }
});

// Other Section Data Loading
async function loadHoroscopes() {
    try {
        const grid = document.getElementById('horoscopeGrid');
        grid.innerHTML = '<p>Horoscope management features coming soon...</p>';
        showToast('Horoscope section loaded', 'info');
    } catch (error) {
        showToast('Failed to load horoscopes', 'error');
    }
}

async function loadKundaliStats() {
    try {
        // TODO: Add real kundali API endpoints
        document.getElementById('totalKundalis').textContent = '0';
        document.getElementById('recentAnalysis').textContent = '0';
        showToast('Kundali stats loaded', 'info');
    } catch (error) {
        showToast('Failed to load kundali stats', 'error');
    }
}

async function loadMatchingStats() {
    try {
        // TODO: Add real matching API endpoints
        document.getElementById('totalMatchings').textContent = '0';
        document.getElementById('marriageMatchings').textContent = '0';
        showToast('Matching stats loaded', 'info');
    } catch (error) {
        showToast('Failed to load matching stats', 'error');
    }
}

async function loadPanchangData() {
    try {
        // TODO: Add real panchang API endpoints
        document.getElementById('todayPanchang').innerHTML = '<p>Panchang management features coming soon...</p>';
        showToast('Panchang section loaded', 'info');
    } catch (error) {
        document.getElementById('todayPanchang').innerHTML = '<p>Failed to load panchang data</p>';
    }
}

async function loadNumerologyStats() {
    try {
        // TODO: Add real numerology API endpoints
        document.getElementById('totalNumerology').textContent = '0';
        document.getElementById('lifePathAnalysis').textContent = '0';
        showToast('Numerology stats loaded', 'info');
    } catch (error) {
        showToast('Failed to load numerology stats', 'error');
    }
}

// Utility Functions
function showModal(modalId) {
    document.getElementById(modalId).classList.add('active');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'exclamation-triangle'}"></i>
        <span>${message}</span>
    `;
    
    document.getElementById('toastContainer').appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 5000);
}

function showLoading(message = 'Loading...') {
    console.log('Loading:', message);
}

function hideLoading() {
    console.log('Loading complete');
}

// Close modals when clicking outside
window.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('active');
    }
});

// Auto-fill admin credentials for development
document.getElementById('usernameInput').addEventListener('focus', function() {
    if (!this.value) {
        this.value = ADMIN_USERNAME;
    }
});

document.getElementById('passwordInput').addEventListener('focus', function() {
    if (!this.value) {
        this.value = ADMIN_PASSWORD;
    }
});

// Google Places API Integration
let placesAutocomplete = null;
let currentDropdown = null;
let selectedIndex = -1;

function initializePlacesAutocomplete() {
    // Initialize for Add User modal
    const addUserPlaceInput = document.getElementById('addUserPlaceOfBirth');
    const addUserDropdown = document.getElementById('addUserPlacesDropdown');
    
    if (addUserPlaceInput && addUserDropdown) {
        setupPlacesAutocomplete(addUserPlaceInput, addUserDropdown);
    }
    
    // Initialize for Edit User modal
    const editUserPlaceInput = document.getElementById('editUserPlaceOfBirth');
    const editUserDropdown = document.getElementById('editUserPlacesDropdown');
    
    if (editUserPlaceInput && editUserDropdown) {
        setupPlacesAutocomplete(editUserPlaceInput, editUserDropdown);
    }
}

function setupPlacesAutocomplete(input, dropdown) {
    let autocomplete = new google.maps.places.Autocomplete(input, {
        types: ['(cities)'],
        componentRestrictions: { country: 'IN' } // Restrict to India
    });
    
    // Override the default autocomplete behavior
    input.addEventListener('input', function() {
        const query = this.value.trim();
        if (query.length >= 2) {
            searchPlaces(query, dropdown, input);
        } else {
            hideDropdown(dropdown);
        }
    });
    
    // Handle keyboard navigation
    input.addEventListener('keydown', function(e) {
        handlePlacesKeyboard(e, dropdown, input);
    });
    
    // Handle focus/blur
    input.addEventListener('focus', function() {
        if (this.value.trim().length >= 2) {
            const query = this.value.trim();
            searchPlaces(query, dropdown, input);
        }
    });
    
    input.addEventListener('blur', function() {
        setTimeout(() => hideDropdown(dropdown), 200);
    });
}

function searchPlaces(query, dropdown, input) {
    const service = new google.maps.places.PlacesService(document.createElement('div'));
    
    const request = {
        query: query,
        types: ['(cities)'],
        componentRestrictions: { country: 'IN' }
    };
    
    service.textSearch(request, function(results, status) {
        if (status === google.maps.places.PlacesServiceStatus.OK && results) {
            displayPlacesResults(results, dropdown, input);
        } else {
            hideDropdown(dropdown);
        }
    });
}

function displayPlacesResults(results, dropdown, input) {
    dropdown.innerHTML = '';
    selectedIndex = -1;
    
    results.slice(0, 5).forEach((place, index) => {
        const item = document.createElement('div');
        item.className = 'places-dropdown-item';
        item.dataset.index = index;
        
        const name = place.name || 'Unknown Place';
        const address = place.formatted_address || '';
        
        item.innerHTML = `
            <div class="place-name">${name}</div>
            <div class="place-address">${address}</div>
        `;
        
        item.addEventListener('click', function() {
            selectPlace(place, input, dropdown);
        });
        
        item.addEventListener('mouseenter', function() {
            selectedIndex = index;
            updateSelectedItem(dropdown);
        });
        
        dropdown.appendChild(item);
    });
    
    if (results.length > 0) {
        showDropdown(dropdown);
    } else {
        hideDropdown(dropdown);
    }
}

function selectPlace(place, input, dropdown) {
    input.value = place.name;
    hideDropdown(dropdown);
    selectedIndex = -1;
    
    // Store additional place data if needed
    input.dataset.placeId = place.place_id;
    input.dataset.placeAddress = place.formatted_address;
}

function handlePlacesKeyboard(e, dropdown, input) {
    const items = dropdown.querySelectorAll('.places-dropdown-item');
    
    switch(e.key) {
        case 'ArrowDown':
            e.preventDefault();
            selectedIndex = Math.min(selectedIndex + 1, items.length - 1);
            updateSelectedItem(dropdown);
            break;
        case 'ArrowUp':
            e.preventDefault();
            selectedIndex = Math.max(selectedIndex - 1, -1);
            updateSelectedItem(dropdown);
            break;
        case 'Enter':
            e.preventDefault();
            if (selectedIndex >= 0 && items[selectedIndex]) {
                const placeData = {
                    name: items[selectedIndex].querySelector('.place-name').textContent,
                    place_id: items[selectedIndex].dataset.placeId,
                    formatted_address: items[selectedIndex].querySelector('.place-address').textContent
                };
                selectPlace(placeData, input, dropdown);
            }
            break;
        case 'Escape':
            hideDropdown(dropdown);
            selectedIndex = -1;
            break;
    }
}

function updateSelectedItem(dropdown) {
    const items = dropdown.querySelectorAll('.places-dropdown-item');
    items.forEach((item, index) => {
        if (index === selectedIndex) {
            item.classList.add('selected');
            item.scrollIntoView({ block: 'nearest' });
        } else {
            item.classList.remove('selected');
        }
    });
}

function showDropdown(dropdown) {
    dropdown.classList.add('active');
    currentDropdown = dropdown;
}

function hideDropdown(dropdown) {
    dropdown.classList.remove('active');
    if (currentDropdown === dropdown) {
        currentDropdown = null;
    }
}

// Phone number parsing function
function parsePhoneNumber(phoneString) {
    // Common country codes
    const countryCodes = [
        '+91', '+1', '+44', '+61', '+86', '+81', '+49', '+33', '+39', '+34',
        '+31', '+46', '+47', '+45', '+358', '+41', '+43', '+32', '+351', '+353',
        '+30', '+48', '+36', '+420', '+421', '+385', '+386', '+371', '+372', '+370',
        '+375', '+380', '+7', '+90', '+972', '+971', '+966', '+974', '+973', '+965',
        '+968', '+967', '+962', '+961', '+963', '+964', '+98', '+93', '+92', '+880',
        '+94', '+977', '+975', '+95', '+856', '+855', '+84', '+66', '+60', '+65',
        '+62', '+63', '+82', '+852', '+853', '+886'
    ];
    
    for (const code of countryCodes) {
        if (phoneString.startsWith(code)) {
            return {
                countryCode: code,
                number: phoneString.substring(code.length)
            };
        }
    }
    
    // Default to India if no country code found
    return {
        countryCode: '+91',
        number: phoneString
    };
}

// Initialize places autocomplete when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Wait for Google Maps API to load
    if (typeof google !== 'undefined' && google.maps && google.maps.places) {
        initializePlacesAutocomplete();
    } else {
        // If Google Maps API is not loaded yet, wait for it
        window.addEventListener('load', function() {
            if (typeof google !== 'undefined' && google.maps && google.maps.places) {
                initializePlacesAutocomplete();
            }
        });
    }
});

// Fix health check endpoint
window.addEventListener('load', function() {
    console.log('Testing API connection...');
    fetch('http://localhost:5000/health')
        .then(response => response.json())
        .then(data => {
            console.log('API Health Check:', data);
        })
        .catch(error => {
            console.error('API Health Check Failed:', error);
        });
});



// PDF Management Functions
async function loadPDFStats() {
    try {
        const response = await fetch(`${API_BASE_URL}/pdf/stats`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        const data = await response.json();
        
        if (data.success) {
            const stats = data.data.overview;
            document.getElementById('totalPDFs').textContent = stats.totalPDFs || 0;
            document.getElementById('activePDFs').textContent = stats.activePDFs || 0;
            document.getElementById('featuredPDFs').textContent = stats.featuredPDFs || 0;
            document.getElementById('totalDownloads').textContent = stats.totalDownloads || 0;
            document.getElementById('totalViews').textContent = stats.totalViews || 0;
        }
    } catch (error) {
        console.error('Error loading PDF stats:', error);
    }
}

async function loadPDFs() {
    try {
        const response = await fetch(`${API_BASE_URL}/pdf?limit=50`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        const data = await response.json();
        
        if (data.success) {
            renderPDFsList(data.data.pdfs);
        }
    } catch (error) {
        console.error('Error loading PDFs:', error);
    }
}

function renderPDFsList(pdfs) {
    const container = document.getElementById('pdfList');
    if (!pdfs || pdfs.length === 0) {
        container.innerHTML = '<p class="no-data">No PDFs found</p>';
        return;
    }
    
    container.innerHTML = pdfs.map(pdf => `
        <div class="pdf-card">
            <div class="pdf-header">
                <h4>${pdf.title}</h4>
                <div class="pdf-actions">
                    <button class="btn btn-sm btn-primary" onclick="editPDF('${pdf.id}')">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deletePDF('${pdf.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
            <div class="pdf-details">
                <p><strong>Category:</strong> ${pdf.category}</p>
                <p><strong>Language:</strong> ${pdf.language}</p>
                <p><strong>Downloads:</strong> ${pdf.downloadCount}</p>
                <p><strong>Views:</strong> ${pdf.viewCount}</p>
                <p><strong>Status:</strong> <span class="status ${pdf.isActive ? 'active' : 'inactive'}">${pdf.isActive ? 'Active' : 'Inactive'}</span></p>
                ${pdf.isFeatured ? '<span class="featured-badge">Featured</span>' : ''}
            </div>
        </div>
    `).join('');
}

// Pricing Functions
async function loadPricingConfig() {
    try {
        const response = await fetch(`${API_BASE_URL}/paidKundli/pricing`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        const data = await response.json();
        
        if (data.success) {
            const pricing = data.data;
            document.getElementById('currentServiceName').textContent = pricing.serviceName;
            document.getElementById('currentBasePrice').textContent = `₹${pricing.basePrice}`;
            document.getElementById('currentGSTPercentage').textContent = `${pricing.gstPercentage}%`;
            
            const totalPrice = pricing.basePrice + (pricing.basePrice * pricing.gstPercentage / 100);
            document.getElementById('currentTotalPrice').textContent = `₹${totalPrice.toFixed(2)}`;
            document.getElementById('currentPricingStatus').textContent = pricing.isActive ? 'Active' : 'Inactive';
            
            // Load PDF types pricing
            if (pricing.pdfTypes) {
                renderPDFTypesGrid(pricing.pdfTypes, pricing.gstPercentage);
            }
        }
    } catch (error) {
        console.error('Error loading pricing config:', error);
    }
}

// Render PDF Types Grid
function renderPDFTypesGrid(pdfTypes, gstPercentage) {
    const gridContainer = document.getElementById('pdfTypesGrid');
    if (!gridContainer) return;
    
    gridContainer.innerHTML = '';
    
    Object.entries(pdfTypes).forEach(([type, config]) => {
        const gstAmount = Math.round((config.price * gstPercentage) / 100);
        const totalAmount = config.price + gstAmount;
        
        const card = document.createElement('div');
        card.className = 'pdf-type-card';
        card.innerHTML = `
            <h4>${type} PDF</h4>
            <div class="pdf-type-details">
                <div class="pdf-type-detail">
                    <span class="label">Description:</span>
                    <span class="value">${config.description}</span>
                </div>
                <div class="pdf-type-detail">
                    <span class="label">Base Price:</span>
                    <span class="value pdf-type-price">₹${config.price}</span>
                </div>
                <div class="pdf-type-detail">
                    <span class="label">GST (${gstPercentage}%):</span>
                    <span class="value">₹${gstAmount}</span>
                </div>
                <div class="pdf-type-detail">
                    <span class="label">Total Amount:</span>
                    <span class="value pdf-type-total">₹${totalAmount}</span>
                </div>
            </div>
        `;
        
        gridContainer.appendChild(card);
    });
}

// Modal Functions
function showAddPDFModal() {
    // Reset form to add mode
    const form = document.getElementById('addPDFForm');
    const modalTitle = document.querySelector('#addPDFModal .modal-header h3');
    const submitBtn = form.querySelector('button[type="submit"]');
    
    modalTitle.textContent = 'Add New PDF';
    submitBtn.textContent = 'Add PDF';
    form.dataset.editMode = 'false';
    delete form.dataset.pdfId;
    
    // Clear form fields
    form.reset();
    
    showModal('addPDFModal');
}

async function showUpdatePricingModal() {
    try {
        // Load current pricing data to pre-fill the form
        const response = await fetch(`${API_BASE_URL}/paidKundli/pricing`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        const data = await response.json();
        
        if (data.success) {
            const pricing = data.data;
            
            // Pre-fill basic pricing data
            document.getElementById('updateServiceName').value = pricing.serviceName;
            document.getElementById('updateBasePrice').value = pricing.basePrice;
            document.getElementById('updateGSTPercentage').value = pricing.gstPercentage;
            document.getElementById('updatePricingDescription').value = pricing.description || '';
            
            // Pre-fill PDF types data
            if (pricing.pdfTypes) {
                Object.entries(pricing.pdfTypes).forEach(([type, config]) => {
                    const priceInput = document.getElementById(`update${type.charAt(0).toUpperCase() + type.slice(1)}Price`);
                    const descInput = document.getElementById(`update${type.charAt(0).toUpperCase() + type.slice(1)}Description`);
                    
                    if (priceInput) priceInput.value = config.price;
                    if (descInput) descInput.value = config.description;
                });
            }
        }
        
        showModal('updatePricingModal');
    } catch (error) {
        console.error('Error loading pricing data for modal:', error);
        showToast('Error loading pricing data', 'error');
    }
}

// Form Handlers
async function handleAddPDF(e) {
    e.preventDefault();
    
    const form = e.target;
    const isEditMode = form.dataset.editMode === 'true';
    const pdfId = form.dataset.pdfId;
    
    const formData = {
        title: document.getElementById('addPDFTitle').value,
        description: document.getElementById('addPDFDescription').value,
        category: document.getElementById('addPDFCategory').value,
        pdfUrl: document.getElementById('addPDFUrl').value,
        fileName: document.getElementById('addPDFFileName').value,
        fileSize: parseInt(document.getElementById('addPDFFileSize').value) || 0,
        language: document.getElementById('addPDFLanguage').value || 'eng',
        isFeatured: document.getElementById('addPDFFeatured').value === 'true',
        tags: document.getElementById('addPDFTags').value.split(',').map(tag => tag.trim()).filter(tag => tag),
        thumbnailUrl: document.getElementById('addPDFThumbnailUrl').value
    };
    
    try {
        const url = isEditMode ? `${API_BASE_URL}/pdf/${pdfId}` : `${API_BASE_URL}/pdf`;
        const method = isEditMode ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(formData)
        });
        
        const data = await response.json();
        
        if (data.success) {
            showToast(isEditMode ? 'PDF updated successfully!' : 'PDF added successfully!', 'success');
            closeModal('addPDFModal');
            
            // Reset form to add mode
            const modalTitle = document.querySelector('#addPDFModal .modal-header h3');
            const submitBtn = form.querySelector('button[type="submit"]');
            modalTitle.textContent = 'Add New PDF';
            submitBtn.textContent = 'Add PDF';
            form.dataset.editMode = 'false';
            delete form.dataset.pdfId;
            
            loadPDFs();
            loadPDFStats();
        } else {
            showToast(data.error || (isEditMode ? 'Failed to update PDF' : 'Failed to add PDF'), 'error');
        }
    } catch (error) {
        console.error('Error with PDF operation:', error);
        showToast('Network error occurred', 'error');
    }
}

// PDF Edit and Delete Functions
async function editPDF(pdfId) {
    try {
        const response = await fetch(`${API_BASE_URL}/pdf/${pdfId}`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        const data = await response.json();
        
        if (data.success) {
            const pdf = data.data;
            // Pre-fill the add PDF form with existing data
            document.getElementById('addPDFTitle').value = pdf.title;
            document.getElementById('addPDFDescription').value = pdf.description || '';
            document.getElementById('addPDFCategory').value = pdf.category;
            document.getElementById('addPDFUrl').value = pdf.pdfUrl;
            document.getElementById('addPDFFileName').value = pdf.fileName;
            document.getElementById('addPDFFileSize').value = pdf.fileSize || '';
            document.getElementById('addPDFLanguage').value = pdf.language || pdf.pdfLanguage || 'eng';
            document.getElementById('addPDFFeatured').value = pdf.isFeatured.toString();
            document.getElementById('addPDFTags').value = pdf.tags ? pdf.tags.join(', ') : '';
            document.getElementById('addPDFThumbnailUrl').value = pdf.thumbnailUrl || '';
            
            // Change form to update mode
            const form = document.getElementById('addPDFForm');
            const submitBtn = form.querySelector('button[type="submit"]');
            const modalTitle = document.querySelector('#addPDFModal .modal-header h3');
            
            modalTitle.textContent = 'Edit PDF';
            submitBtn.textContent = 'Update PDF';
            form.dataset.editMode = 'true';
            form.dataset.pdfId = pdfId;
            
            showModal('addPDFModal');
        } else {
            showToast('Failed to load PDF details', 'error');
        }
    } catch (error) {
        console.error('Error loading PDF details:', error);
        showToast('Network error occurred', 'error');
    }
}

async function deletePDF(pdfId) {
    if (!confirm('Are you sure you want to delete this PDF? This action cannot be undone.')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/pdf/${pdfId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        
        const data = await response.json();
        
        if (data.success) {
            showToast('PDF deleted successfully!', 'success');
            loadPDFs();
            loadPDFStats();
        } else {
            showToast(data.error || 'Failed to delete PDF', 'error');
        }
    } catch (error) {
        console.error('Error deleting PDF:', error);
        showToast('Network error occurred', 'error');
    }
}

async function handleUpdatePricing(e) {
    e.preventDefault();
    
    // Get PDF types data
    const pdfTypes = {
        small: {
            price: parseFloat(document.getElementById('updateSmallPrice').value),
            description: document.getElementById('updateSmallDescription').value
        },
        medium: {
            price: parseFloat(document.getElementById('updateMediumPrice').value),
            description: document.getElementById('updateMediumDescription').value
        },
        large: {
            price: parseFloat(document.getElementById('updateLargePrice').value),
            description: document.getElementById('updateLargeDescription').value
        }
    };
    
    const formData = {
        serviceName: document.getElementById('updateServiceName').value,
        basePrice: parseFloat(document.getElementById('updateBasePrice').value),
        gstPercentage: parseFloat(document.getElementById('updateGSTPercentage').value),
        description: document.getElementById('updatePricingDescription').value,
        pdfTypes: pdfTypes
    };
    
    console.log('Submitting updatePricing payload:', formData);
    
    try {
        const response = await fetch(`${API_BASE_URL}/paidKundli/updatePricing`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(formData)
        });
        
        const data = await response.json();
        
        if (data.success) {
            showToast('Pricing updated successfully!', 'success');
            closeModal('updatePricingModal');
            loadPricingConfig();
        } else {
            showToast(data.error || data.message || 'Failed to update pricing', 'error');
            console.error('Update pricing error:', data);
        }
    } catch (error) {
        console.error('Error updating pricing:', error);
        showToast('Network error occurred', 'error');
    }
}

// Filter Functions
function filterPDFs() {
    const search = document.getElementById('pdfSearchInput').value;
    const category = document.getElementById('pdfCategoryFilter').value;
    const language = document.getElementById('pdfLanguageFilter').value;
    
    // Implement filtering logic here
    console.log('Filtering PDFs:', { search, category, language });
    loadPDFs(); // Reload with filters
}

function filterOrders() {
    const orderType = document.getElementById('orderTypeFilter').value;
    const orderStatus = document.getElementById('orderStatusFilter').value;
    
    // Implement filtering logic here
    console.log('Filtering orders:', { orderType, orderStatus });
    loadRecentOrders(); // Reload with filters
}

// Utility Functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Refresh Functions
function refreshPaidKundliStats() {
    loadPaidKundliStats();
    loadRecentOrders();
}

function refreshPDFStats() {
    loadPDFStats();
    loadPDFs();
}

// Razorpay Configuration Functions
async function loadRazorpayConfigs() {
    try {
        const response = await fetch(`${API_BASE_URL}/admin/razorpay/config`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });

        if (!response.ok) {
            throw new Error('Failed to load Razorpay configurations');
        }

        const data = await response.json();
        renderRazorpayConfigs(data.data.docs || []);
    } catch (error) {
        console.error('Error loading Razorpay configurations:', error);
        showToast('Failed to load Razorpay configurations', 'error');
    }
}

function renderRazorpayConfigs(configs) {
    const grid = document.getElementById('razorpayConfigsGrid');
    
    // Update overview cards
    updateRazorpayOverview(configs);
    
    if (!configs || configs.length === 0) {
        grid.innerHTML = `
            <div class="no-data">
                <i class="fas fa-credit-card"></i>
                <p>No Razorpay configurations found</p>
                <button class="btn btn-primary" onclick="showCreateRazorpayModal()">
                    <i class="fas fa-plus"></i>
                    Add First Configuration
                </button>
            </div>
        `;
        return;
    }

    grid.innerHTML = configs.map(config => `
        <div class="config-card">
            <div class="config-header">
                <div class="config-title">
                    <i class="fas fa-credit-card"></i>
                    <span>Razorpay ${config.environment.toUpperCase()}</span>
                    <span class="config-environment ${config.environment}">${config.environment}</span>
                </div>
                <div class="config-status">
                    <div class="status-dot ${config.isActive ? 'active' : 'inactive'}"></div>
                    <span>${config.isActive ? 'Active' : 'Inactive'}</span>
                </div>
            </div>
            
            <div class="config-details">
                <div class="config-item">
                    <span class="config-label">Razorpay ID:</span>
                    <span class="config-value">${config.razorpayId}</span>
                </div>
                <div class="config-item">
                    <span class="config-label">Razorpay Key:</span>
                    <span class="config-value masked">${config.razorpayKey}</span>
                </div>
                <div class="config-item">
                    <span class="config-label">RazorpayX Account:</span>
                    <span class="config-value">${config.razorpayXAccount}</span>
                </div>
            </div>
            
            ${config.description ? `
                <div class="config-description">
                    <i class="fas fa-info-circle"></i>
                    ${config.description}
                </div>
            ` : ''}
            
            <div class="config-actions">
                <button class="btn btn-primary" onclick="editRazorpayConfig('${config.id}')">
                    <i class="fas fa-edit"></i>
                    Edit
                </button>
                <button class="btn btn-secondary" onclick="toggleRazorpayConfig('${config.id}')">
                    <i class="fas fa-toggle-on"></i>
                    ${config.isActive ? 'Deactivate' : 'Activate'}
                </button>
                <button class="btn btn-danger" onclick="deleteRazorpayConfig('${config.id}')">
                    <i class="fas fa-trash"></i>
                    Delete
                </button>
            </div>
            
            <div class="config-meta">
                <div class="config-updated">
                    <i class="fas fa-clock"></i>
                    <span>Updated: ${new Date(config.updatedAt).toLocaleDateString()}</span>
                </div>
                ${config.updatedBy ? `
                    <div class="config-updated-by">
                        <i class="fas fa-user"></i>
                        <span>${config.updatedBy.name || config.updatedBy.email}</span>
                    </div>
                ` : ''}
            </div>
        </div>
    `).join('');
}

function showCreateRazorpayModal() {
    document.getElementById('razorpayModalTitle').textContent = 'Add Razorpay Configuration';
    document.getElementById('razorpaySubmitBtn').textContent = 'Add Configuration';
    document.getElementById('razorpayForm').reset();
    document.getElementById('razorpayConfigId').value = '';
    showModal('razorpayModal');
}

function showEditRazorpayModal(config) {
    document.getElementById('razorpayModalTitle').textContent = 'Edit Razorpay Configuration';
    document.getElementById('razorpaySubmitBtn').textContent = 'Update Configuration';
    document.getElementById('razorpayConfigId').value = config.id;
    document.getElementById('razorpayId').value = config.razorpayId;
    document.getElementById('razorpayKey').value = config.razorpayKey;
    document.getElementById('razorpayXAccount').value = config.razorpayXAccount;
    document.getElementById('razorpayEnvironment').value = config.environment;
    document.getElementById('razorpayDescription').value = config.description || '';
    document.getElementById('razorpayIsActive').value = config.isActive.toString();
    showModal('razorpayModal');
}

async function editRazorpayConfig(configId) {
    try {
        const response = await fetch(`${API_BASE_URL}/admin/razorpay/config/${configId}`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });

        if (!response.ok) {
            throw new Error('Failed to load configuration details');
        }

        const data = await response.json();
        showEditRazorpayModal(data.data);
    } catch (error) {
        console.error('Error loading configuration details:', error);
        showToast('Failed to load configuration details', 'error');
    }
}

async function handleRazorpayForm(e) {
    e.preventDefault();
    
    const configId = document.getElementById('razorpayConfigId').value;
    const isEdit = configId !== '';
    
    const formData = {
        razorpayId: document.getElementById('razorpayId').value,
        razorpayKey: document.getElementById('razorpayKey').value,
        razorpayXAccount: document.getElementById('razorpayXAccount').value,
        environment: document.getElementById('razorpayEnvironment').value,
        description: document.getElementById('razorpayDescription').value,
        isActive: document.getElementById('razorpayIsActive').value === 'true'
    };

    try {
        showLoading(isEdit ? 'Updating configuration...' : 'Creating configuration...');
        
        const url = isEdit 
            ? `${API_BASE_URL}/admin/razorpay/config/${configId}`
            : `${API_BASE_URL}/admin/razorpay/config`;
        
        const method = isEdit ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(formData)
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Operation failed');
        }

        const data = await response.json();
        showToast(data.message, 'success');
        closeModal('razorpayModal');
        loadRazorpayConfigs();
    } catch (error) {
        console.error('Error saving configuration:', error);
        showToast(error.message, 'error');
    } finally {
        hideLoading();
    }
}

async function toggleRazorpayConfig(configId) {
    if (!confirm('Are you sure you want to toggle this configuration status?')) {
        return;
    }

    try {
        showLoading('Updating status...');
        
        const response = await fetch(`${API_BASE_URL}/admin/razorpay/config/${configId}/toggle`, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Failed to toggle status');
        }

        const data = await response.json();
        showToast(data.message, 'success');
        loadRazorpayConfigs();
    } catch (error) {
        console.error('Error toggling configuration:', error);
        showToast(error.message, 'error');
    } finally {
        hideLoading();
    }
}

async function deleteRazorpayConfig(configId) {
    if (!confirm('Are you sure you want to delete this configuration? This action cannot be undone.')) {
        return;
    }

    try {
        showLoading('Deleting configuration...');
        
        const response = await fetch(`${API_BASE_URL}/admin/razorpay/config/${configId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Failed to delete configuration');
        }

        const data = await response.json();
        showToast(data.message, 'success');
        loadRazorpayConfigs();
    } catch (error) {
        console.error('Error deleting configuration:', error);
        showToast(error.message, 'error');
    } finally {
        hideLoading();
    }
}

function refreshRazorpayConfigs() {
    loadRazorpayConfigs();
}

// Update Razorpay overview cards
function updateRazorpayOverview(configs) {
    const testConfig = configs.find(c => c.environment === 'test' && c.isActive);
    const liveConfig = configs.find(c => c.environment === 'live' && c.isActive);
    
    // Update Test Environment Card
    const testStatusDot = document.getElementById('testStatusDot');
    const testStatusText = document.getElementById('testStatusText');
    const testConfigDetails = document.getElementById('testConfigDetails');
    
    if (testConfig) {
        testStatusDot.className = 'status-dot active';
        testStatusText.textContent = 'Active';
        testConfigDetails.innerHTML = `
            <div class="config-detail-item">
                <strong>Razorpay ID:</strong> ${testConfig.razorpayId}
            </div>
            <div class="config-detail-item">
                <strong>RazorpayX Account:</strong> ${testConfig.razorpayXAccount}
            </div>
            ${testConfig.description ? `<div class="config-detail-item"><strong>Description:</strong> ${testConfig.description}</div>` : ''}
        `;
    } else {
        testStatusDot.className = 'status-dot inactive';
        testStatusText.textContent = 'Not Configured';
        testConfigDetails.innerHTML = '<p>No active test configuration found</p>';
    }
    
    // Update Live Environment Card
    const liveStatusDot = document.getElementById('liveStatusDot');
    const liveStatusText = document.getElementById('liveStatusText');
    const liveConfigDetails = document.getElementById('liveConfigDetails');
    
    if (liveConfig) {
        liveStatusDot.className = 'status-dot active';
        liveStatusText.textContent = 'Active';
        liveConfigDetails.innerHTML = `
            <div class="config-detail-item">
                <strong>Razorpay ID:</strong> ${liveConfig.razorpayId}
            </div>
            <div class="config-detail-item">
                <strong>RazorpayX Account:</strong> ${liveConfig.razorpayXAccount}
            </div>
            ${liveConfig.description ? `<div class="config-detail-item"><strong>Description:</strong> ${liveConfig.description}</div>` : ''}
        `;
    } else {
        liveStatusDot.className = 'status-dot inactive';
        liveStatusText.textContent = 'Not Configured';
        liveConfigDetails.innerHTML = '<p>No active live configuration found</p>';
    }
}

 